memory.limit(size=56000)
library(raster)
library(rpart)
library(maptools)
library(data.table)
library(rgdal)
library(dplyr)
library(blockCV)
library(sp)
library(dismo)
library(ggplot2)
my.theme <- theme_classic() +
  theme(text=element_text(size=24, family="Arial"),
        axis.text.x=element_text(size=24),
        axis.text.y=element_text(size=24),
        axis.title.x=element_text(margin=margin(10,0,0,0)),
        axis.title.y=element_text(margin=margin(0,10,0,0)),
        axis.line.x=element_line(linetype=1),
        axis.line.y=element_line(linetype=1))

#There is one baseline scenario

# Population size from density predictions ####
#load mean density layer for whole Ontario range Year 2010 (IRL, 2020)

meanDens2010<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Year 2010 Simulation 1/mean_WOTH_Ontario.tif")

# Multiplying density values by 4 (hectares in a 200x200 pixel) to get abundance for each cell and overall population size

density_brt_2010_200m<-meanDens2010*4
popsize2010<-cellStats(density_brt_2010_200m,stat=sum,na.rm=T) # THIS IS ESTIMATED POPULATION SIZE
#[1] 547548.3

# Same procedure for upper and lower CI predictions 
upperDens2010<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Year 2010 Simulation 1/confint_upper_Ontario.tif")
upper_brt_2010_200m<-upperDens2010*4
popsize2010.upper<-cellStats(upper_brt_2010_200m,stat=sum,na.rm=T) # THIS IS ESTIMATED POPULATION SIZE'S UPPER 90% B.C.I. LIMIT
#719013.6

lowerDens2010<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Year 2010 Simulation 1/confint_lower_Ontario.tif")
lower_brt_2010_200m<-lowerDens2010*4
popsize2010.lower<-cellStats(lower_brt_2010_200m,stat=sum,na.rm=T) # THIS IS ESTIMATED POPULATION SIZE'S LOWER 90% B.C.I. LIMIT
#407613.7

#Now repeat for the other time steps in this scenario in simulation run 1
#2020
meanDens2020<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Year 2020 Simulation 1/mean_WOTH_Ontario.tif")
density_brt_2020_200m<-meanDens2020*4
popsize2020<-cellStats(density_brt_2020_200m,stat=sum,na.rm=T) # THIS IS ESTIMATED POPULATION SIZE
#554658.4

upperDens2020<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Year 2020 Simulation 1/confint_upper_Ontario.tif")
upper_brt_2020_200m<-upperDens2020*4
popsize2020.upper<-cellStats(upper_brt_2020_200m,stat=sum,na.rm=T) # THIS IS ESTIMATED POPULATION SIZE'S UPPER 90% B.C.I. LIMIT
#731026.5

lowerDens2020<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Year 2020 Simulation 1/confint_lower_Ontario.tif")
lower_brt_2020_200m<-lowerDens2020*4
popsize2020.lower<-cellStats(lower_brt_2020_200m,stat=sum,na.rm=T) # THIS IS ESTIMATED POPULATION SIZE'S LOWER 90% B.C.I. LIMIT
#412006.1

#2030
meanDens2030<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Year 2030 Simulation 1/mean_WOTH_Ontario.tif")
density_brt_2030_200m<-meanDens2030*4
popsize2030<-cellStats(density_brt_2030_200m,stat=sum,na.rm=T) # THIS IS ESTIMATED POPULATION SIZE
#613994.4

upperDens2030<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Year 2030 Simulation 1/confint_upper_Ontario.tif")
upper_brt_2030_200m<-upperDens2030*4
popsize2030.upper<-cellStats(upper_brt_2030_200m,stat=sum,na.rm=T) # THIS IS ESTIMATED POPULATION SIZE'S UPPER 90% B.C.I. LIMIT
#820297.8

lowerDens2030<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Year 2030 Simulation 1/confint_lower_Ontario.tif")
lower_brt_2030_200m<-lowerDens2030*4
popsize2030.lower<-cellStats(lower_brt_2030_200m,stat=sum,na.rm=T) # THIS IS ESTIMATED POPULATION SIZE'S LOWER 90% B.C.I. LIMIT
#450111.6

#2040
meanDens2040<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Year 2040 Simulation 1/mean_WOTH_Ontario.tif")
density_brt_2040_200m<-meanDens2040*4
popsize2040<-cellStats(density_brt_2040_200m,stat=sum,na.rm=T) # THIS IS ESTIMATED POPULATION SIZE
#628889.9

upperDens2040<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Year 2040 Simulation 1/confint_upper_Ontario.tif")
upper_brt_2040_200m<-upperDens2040*4
popsize2040.upper<-cellStats(upper_brt_2040_200m,stat=sum,na.rm=T) # THIS IS ESTIMATED POPULATION SIZE'S UPPER 90% B.C.I. LIMIT
#850101.9

lowerDens2040<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Year 2040 Simulation 1/confint_lower_Ontario.tif")
lower_brt_2040_200m<-lowerDens2040*4
popsize2040.lower<-cellStats(lower_brt_2040_200m,stat=sum,na.rm=T) # THIS IS ESTIMATED POPULATION SIZE'S LOWER 90% B.C.I. LIMIT
#457675.2

#2050
meanDens2050<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Year 2050 Simulation 1/mean_WOTH_Ontario.tif")
density_brt_2050_200m<-meanDens2050*4
popsize2050<-cellStats(density_brt_2050_200m,stat=sum,na.rm=T) # THIS IS ESTIMATED POPULATION SIZE
#647776.3

upperDens2050<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Year 2050 Simulation 1/confint_upper_Ontario.tif")
upper_brt_2050_200m<-upperDens2050*4
popsize2050.upper<-cellStats(upper_brt_2050_200m,stat=sum,na.rm=T) # THIS IS ESTIMATED POPULATION SIZE'S UPPER 90% B.C.I. LIMIT
#893707.2

lowerDens2050<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Year 2050 Simulation 1/confint_lower_Ontario.tif")
lower_brt_2050_200m<-lowerDens2050*4
popsize2050.lower<-cellStats(lower_brt_2050_200m,stat=sum,na.rm=T) # THIS IS ESTIMATED POPULATION SIZE'S LOWER 90% B.C.I. LIMIT
#465001.7

#2060
meanDens2060<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Year 2060 Simulation 1/mean_WOTH_Ontario.tif")
density_brt_2060_200m<-meanDens2060*4
popsize2060<-cellStats(density_brt_2060_200m,stat=sum,na.rm=T) # THIS IS ESTIMATED POPULATION SIZE
#669437.5

upperDens2060<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Year 2060 Simulation 1/confint_upper_Ontario.tif")
upper_brt_2060_200m<-upperDens2060*4
popsize2060.upper<-cellStats(upper_brt_2060_200m,stat=sum,na.rm=T) # THIS IS ESTIMATED POPULATION SIZE'S UPPER 90% B.C.I. LIMIT
#958398.2

lowerDens2060<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Year 2060 Simulation 1/confint_lower_Ontario.tif")
lower_brt_2060_200m<-lowerDens2060*4
popsize2060.lower<-cellStats(lower_brt_2060_200m,stat=sum,na.rm=T) # THIS IS ESTIMATED POPULATION SIZE'S LOWER 90% B.C.I. LIMIT
#470137.2

Popn<-c(popsize2010,
        popsize2020,
        popsize2030,
        popsize2040,
        popsize2050,
        popsize2060)
PopnLower<-c(popsize2010.lower,
             popsize2020.lower,
             popsize2030.lower,
             popsize2040.lower,
             popsize2050.lower,
             popsize2060.lower)
PopnUpper<-c(popsize2010.upper,
             popsize2020.upper,
             popsize2030.upper,
             popsize2040.upper,
             popsize2050.upper,
             popsize2060.upper)
Year<-c(2020,2030,2040,2050,2060,2070)

library(ggplot2)
df<-data.frame(Year,Popn,PopnLower,PopnUpper)
p1<-ggplot(df) + 
  geom_point(aes(x = Year, y = Popn))+ 
  #geom_errorbar(aes(x=Year, ymin=PopnLower, ymax=PopnUpper),color="#F8766D")+
  geom_line(aes(x = Year, y = Popn))+
  geom_line(aes(x = Year, y = PopnLower), col="red", linetype="dashed")+
  geom_line(aes(x = Year, y = PopnUpper), col="red", linetype="dashed")+
  ylab("Predicted Wood Thrush Population (all Ontario) + \nBootstrap 90 % C.I.")+
  xlab("Year")+my.theme

png("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/WOTHOntario_2020_2070_ALCESBaseline.png",width=1080,height=700)
p1
dev.off()
#The resulting line plot is based off a single simulation run of the Baseline Scenario.
#I don't expect large differences in results among the other simulation runs, which will 
#take a long time to obtain

#Now do mean forest age: Note that 2010 is Year 0 in ALCES Online 
#but forest age at Year 0 is from 2020 (10 years ahead)
meanForestAge2020<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/ForestAge2010WOTHxFMU.tif")
forestage2020<-cellStats(meanForestAge2020,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN FOREST AGE IN EACH PIXEL
#52.34994 (same initial forest age in simulation runs 1-5)
meanForestAge2030.1<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2020 Simulation 1/ForestAge2020WOTHxFMU.tif")
forestage2030.1<-cellStats(meanForestAge2030.1,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN FOREST AGE IN EACH PIXEL
#56.53031
meanForestAge2030.2<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2020 Simulation 2/ForestAge2020WOTHxFMU.tif")
forestage2030.2<-cellStats(meanForestAge2030.2,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN FOREST AGE IN EACH PIXEL
#56.44815
meanForestAge2030.3<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2020 Simulation 3/ForestAge2020WOTHxFMU.tif")
forestage2030.3<-cellStats(meanForestAge2030.3,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN FOREST AGE IN EACH PIXEL
#56.42573
meanForestAge2030.4<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2020 Simulation 4/ForestAge2020WOTHxFMU.tif")
forestage2030.4<-cellStats(meanForestAge2030.4,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN FOREST AGE IN EACH PIXEL
#56.45955
meanForestAge2030.5<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2020 Simulation 5/ForestAge2020WOTHxFMU.tif")
forestage2030.5<-cellStats(meanForestAge2030.5,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN FOREST AGE IN EACH PIXEL
#56.43209
meanForestAge2040.1<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2030 Simulation 1/ForestAge2030WOTHxFMU.tif")
forestage2040.1<-cellStats(meanForestAge2040.1,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN FOREST AGE IN EACH PIXEL
#60.5747
meanForestAge2040.2<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2030 Simulation 2/ForestAge2030WOTHxFMU.tif")
forestage2040.2<-cellStats(meanForestAge2040.2,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN FOREST AGE IN EACH PIXEL
#60.75066
meanForestAge2040.3<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2030 Simulation 3/ForestAge2030WOTHxFMU.tif")
forestage2040.3<-cellStats(meanForestAge2040.3,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN FOREST AGE IN EACH PIXEL
#60.75327
meanForestAge2040.4<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2030 Simulation 4/ForestAge2030WOTHxFMU.tif")
forestage2040.4<-cellStats(meanForestAge2040.4,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN FOREST AGE IN EACH PIXEL
#60.77726
meanForestAge2040.5<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2030 Simulation 5/ForestAge2030WOTHxFMU.tif")
forestage2040.5<-cellStats(meanForestAge2040.5,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN FOREST AGE IN EACH PIXEL
#60.75377
meanForestAge2050.1<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2040 Simulation 1/ForestAge2040WOTHxFMU.tif")
forestage2050.1<-cellStats(meanForestAge2050.1,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN FOREST AGE IN EACH PIXEL
#64.92679
meanForestAge2050.2<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2040 Simulation 2/ForestAge2040WOTHxFMU.tif")
forestage2050.2<-cellStats(meanForestAge2050.2,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN FOREST AGE IN EACH PIXEL
#65.19241
meanForestAge2050.3<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2040 Simulation 3/ForestAge2040WOTHxFMU.tif")
forestage2050.3<-cellStats(meanForestAge2050.3,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN FOREST AGE IN EACH PIXEL
#65.18993
meanForestAge2050.4<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2040 Simulation 4/ForestAge2040WOTHxFMU.tif")
forestage2050.4<-cellStats(meanForestAge2050.4,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN FOREST AGE IN EACH PIXEL
#65.21645
meanForestAge2050.5<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2040 Simulation 5/ForestAge2040WOTHxFMU.tif")
forestage2050.5<-cellStats(meanForestAge2050.5,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN FOREST AGE IN EACH PIXEL
#65.19328
meanForestAge2060.1<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2050 Simulation 1/ForestAge2050WOTHxFMU.tif")
forestage2060.1<-cellStats(meanForestAge2060.1,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN FOREST AGE IN EACH PIXEL
#69.27023
meanForestAge2060.2<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2050 Simulation 2/ForestAge2050WOTHxFMU.tif")
forestage2060.2<-cellStats(meanForestAge2060.2,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN FOREST AGE IN EACH PIXEL
#69.72045
meanForestAge2060.3<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2050 Simulation 3/ForestAge2050WOTHxFMU.tif")
forestage2060.3<-cellStats(meanForestAge2060.3,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN FOREST AGE IN EACH PIXEL
#69.7203
meanForestAge2060.4<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2050 Simulation 4/ForestAge2050WOTHxFMU.tif")
forestage2060.4<-cellStats(meanForestAge2060.4,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN FOREST AGE IN EACH PIXEL
#69.71111
meanForestAge2060.5<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2050 Simulation 5/ForestAge2050WOTHxFMU.tif")
forestage2060.5<-cellStats(meanForestAge2060.5,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN FOREST AGE IN EACH PIXEL
#69.72621
meanForestAge2070.1<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2060 Simulation 1/ForestAge2060WOTHxFMU.tif")
forestage2070.1<-cellStats(meanForestAge2070.1,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN FOREST AGE IN EACH PIXEL
#73.74264
meanForestAge2070.2<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2060 Simulation 2/ForestAge2060WOTHxFMU.tif")
forestage2070.2<-cellStats(meanForestAge2070.2,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN FOREST AGE IN EACH PIXEL
#74.38507
meanForestAge2070.3<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2060 Simulation 3/ForestAge2060WOTHxFMU.tif")
forestage2070.3<-cellStats(meanForestAge2070.3,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN FOREST AGE IN EACH PIXEL
#74.38862
meanForestAge2070.4<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2060 Simulation 4/ForestAge2060WOTHxFMU.tif")
forestage2070.4<-cellStats(meanForestAge2070.4,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN FOREST AGE IN EACH PIXEL
#74.37815
meanForestAge2070.5<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2060 Simulation 5/ForestAge2060WOTHxFMU.tif")
forestage2070.5<-cellStats(meanForestAge2070.5,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN FOREST AGE IN EACH PIXEL
#74.38883

MeanForestAge<-c(forestage2020,forestage2020,forestage2020,forestage2020,forestage2020,
        forestage2030.1,forestage2030.2,forestage2030.3,forestage2030.4,forestage2030.5,
        forestage2040.1,forestage2040.2,forestage2040.3,forestage2040.4,forestage2040.5,
        forestage2050.1,forestage2050.2,forestage2050.3,forestage2050.4,forestage2050.5,
        forestage2060.1,forestage2060.2,forestage2060.3,forestage2060.4,forestage2060.5,
        forestage2070.1,forestage2070.2,forestage2070.3,forestage2070.4,forestage2070.5)
Year<-c(rep(2020,5), rep(2030,5), rep(2040,5), rep(2050,5), rep(2060,5), rep(2070,5))
Lower<-c(rep(forestage2020,5),
         rep(min(forestage2030.1,forestage2030.2,forestage2030.3,forestage2030.4,forestage2030.5),5),
         rep(min(forestage2040.1,forestage2040.2,forestage2040.3,forestage2040.4,forestage2040.5),5),
         rep(min(forestage2050.1,forestage2050.2,forestage2050.3,forestage2050.4,forestage2050.5),5),
         rep(min(forestage2060.1,forestage2060.2,forestage2060.3,forestage2060.4,forestage2060.5),5),
         rep(min(forestage2070.1,forestage2070.2,forestage2070.3,forestage2070.4,forestage2070.5),5))
Upper<-c(rep(forestage2020,5),
         rep(max(forestage2030.1,forestage2030.2,forestage2030.3,forestage2030.4,forestage2030.5),5),
         rep(max(forestage2040.1,forestage2040.2,forestage2040.3,forestage2040.4,forestage2040.5),5),
         rep(max(forestage2050.1,forestage2050.2,forestage2050.3,forestage2050.4,forestage2050.5),5),
         rep(max(forestage2060.1,forestage2060.2,forestage2060.3,forestage2060.4,forestage2060.5),5),
         rep(max(forestage2070.1,forestage2070.2,forestage2070.3,forestage2070.4,forestage2070.5),5))
library(ggplot2)
df.fa<-data.frame(Year,MeanForestAge,Lower,Upper)
p1.fa<-ggplot(df.fa) + 
  geom_point(aes(x = Year, y = MeanForestAge))+ 
  geom_ribbon(aes(x=Year, ymin = Lower, ymax = Upper), fill = "grey70") +
  geom_line(aes(x = Year, y = MeanForestAge))+
  ylab("Mean Forest Age (all Ontario) \nALCES Online Baseline Scenario")+
  xlab("Year")+my.theme

png("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/MeanForestAgeOntario_2020_2070_ALCESBaseline.png",width=1080,height=700)
p1.fa
dev.off()

#Change in shrubland area over time Note that 2010 is Year 0 in ALCES Online 
#but forest age at Year 0 is from 2020 (10 years ahead)
meanShrubland2020<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/shrub.2000m.tif")
shrubamount2020<-cellStats(meanShrubland2020,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN SHRUBLAND AMOUNT WITHIN 2000 M IN EACH PIXEL
#0.04997658 (same initial mean shrub amount within 2000 m of each pixel in simulation runs 1-5)
meanShrubland2030.1<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2020 Simulation 1/shrub.2000m.tif")
shrubamount2030.1<-cellStats(meanShrubland2030.1,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN SHRUBLAND AMOUNT WITHIN 2000 M IN EACH PIXEL
#0.06952415
meanShrubland2030.2<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2020 Simulation 2/shrub.2000m.tif")
shrubamount2030.2<-cellStats(meanShrubland2030.2,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN SHRUBLAND AMOUNT WITHIN 2000 M IN EACH PIXEL
#0.07051223
meanShrubland2030.3<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2020 Simulation 3/shrub.2000m.tif")
shrubamount2030.3<-cellStats(meanShrubland2030.3,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN SHRUBLAND AMOUNT WITHIN 2000 M IN EACH PIXEL
#0.07065141
meanShrubland2030.4<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2020 Simulation 4/shrub.2000m.tif")
shrubamount2030.4<-cellStats(meanShrubland2030.4,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN SHRUBLAND AMOUNT WITHIN 2000 M IN EACH PIXEL
#0.07029321
meanShrubland2030.5<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2020 Simulation 5/shrub.2000m.tif")
shrubamount2030.5<-cellStats(meanShrubland2030.5,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN SHRUBLAND AMOUNT WITHIN 2000 M IN EACH PIXEL
#0.07064128
meanShrubland2040.1<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2030 Simulation 1/shrub.2000m.tif")
shrubamount2040.1<-cellStats(meanShrubland2040.1,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN SHRUBLAND AMOUNT WITHIN 2000 M IN EACH PIXEL
#60.5747
meanShrubland2040.2<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2030 Simulation 2/shrub.2000m.tif")
shrubamount2040.2<-cellStats(meanShrubland2040.2,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN SHRUBLAND AMOUNT WITHIN 2000 M IN EACH PIXEL
#60.75066
meanShrubland2040.3<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2030 Simulation 3/shrub.2000m.tif")
shrubamount2040.3<-cellStats(meanShrubland2040.3,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN SHRUBLAND AMOUNT WITHIN 2000 M IN EACH PIXEL
#60.75327
meanShrubland2040.4<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2030 Simulation 4/shrub.2000m.tif")
shrubamount2040.4<-cellStats(meanShrubland2040.4,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN SHRUBLAND AMOUNT WITHIN 2000 M IN EACH PIXEL
#60.77726
meanShrubland2040.5<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2030 Simulation 5/shrub.2000m.tif")
shrubamount2040.5<-cellStats(meanShrubland2040.5,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN SHRUBLAND AMOUNT WITHIN 2000 M IN EACH PIXEL
#60.75377
meanShrubland2050.1<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2040 Simulation 1/shrub.2000m.tif")
shrubamount2050.1<-cellStats(meanShrubland2050.1,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN SHRUBLAND AMOUNT WITHIN 2000 M IN EACH PIXEL
#64.92679
meanShrubland2050.2<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2040 Simulation 2/shrub.2000m.tif")
shrubamount2050.2<-cellStats(meanShrubland2050.2,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN SHRUBLAND AMOUNT WITHIN 2000 M IN EACH PIXEL
#65.19241
meanShrubland2050.3<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2040 Simulation 3/shrub.2000m.tif")
shrubamount2050.3<-cellStats(meanShrubland2050.3,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN SHRUBLAND AMOUNT WITHIN 2000 M IN EACH PIXEL
#65.18993
meanShrubland2050.4<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2040 Simulation 4/shrub.2000m.tif")
shrubamount2050.4<-cellStats(meanShrubland2050.4,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN SHRUBLAND AMOUNT WITHIN 2000 M IN EACH PIXEL
#65.21645
meanShrubland2050.5<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2040 Simulation 5/shrub.2000m.tif")
shrubamount2050.5<-cellStats(meanShrubland2050.5,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN SHRUBLAND AMOUNT WITHIN 2000 M IN EACH PIXEL
#65.19328
meanShrubland2060.1<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2050 Simulation 1/shrub.2000m.tif")
shrubamount2060.1<-cellStats(meanShrubland2060.1,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN SHRUBLAND AMOUNT WITHIN 2000 M IN EACH PIXEL
#69.27023
meanShrubland2060.2<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2050 Simulation 2/shrub.2000m.tif")
shrubamount2060.2<-cellStats(meanShrubland2060.2,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN SHRUBLAND AMOUNT WITHIN 2000 M IN EACH PIXEL
#69.72045
meanShrubland2060.3<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2050 Simulation 3/shrub.2000m.tif")
shrubamount2060.3<-cellStats(meanShrubland2060.3,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN SHRUBLAND AMOUNT WITHIN 2000 M IN EACH PIXEL
#69.7203
meanShrubland2060.4<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2050 Simulation 4/shrub.2000m.tif")
shrubamount2060.4<-cellStats(meanShrubland2060.4,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN SHRUBLAND AMOUNT WITHIN 2000 M IN EACH PIXEL
#69.71111
meanShrubland2060.5<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2050 Simulation 5/shrub.2000m.tif")
shrubamount2060.5<-cellStats(meanShrubland2060.5,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN SHRUBLAND AMOUNT WITHIN 2000 M IN EACH PIXEL
#69.72621
meanShrubland2070.1<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2060 Simulation 1/shrub.2000m.tif")
shrubamount2070.1<-cellStats(meanShrubland2070.1,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN SHRUBLAND AMOUNT WITHIN 2000 M IN EACH PIXEL
#73.74264
meanShrubland2070.2<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2060 Simulation 2/shrub.2000m.tif")
shrubamount2070.2<-cellStats(meanShrubland2070.2,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN SHRUBLAND AMOUNT WITHIN 2000 M IN EACH PIXEL
#74.38507
meanShrubland2070.3<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2060 Simulation 3/shrub.2000m.tif")
shrubamount2070.3<-cellStats(meanShrubland2070.3,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN SHRUBLAND AMOUNT WITHIN 2000 M IN EACH PIXEL
#74.38862
meanShrubland2070.4<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2060 Simulation 4/shrub.2000m.tif")
shrubamount2070.4<-cellStats(meanShrubland2070.4,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN SHRUBLAND AMOUNT WITHIN 2000 M IN EACH PIXEL
#74.37815
meanShrubland2070.5<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2060 Simulation 5/shrub.2000m.tif")
shrubamount2070.5<-cellStats(meanShrubland2070.5,stat=mean,na.rm=T) # THIS IS ESTIMATED MEAN SHRUBLAND AMOUNT WITHIN 2000 M IN EACH PIXEL
#74.38883

Meanshrubamount<-c(shrubamount2020,shrubamount2020,shrubamount2020,shrubamount2020,shrubamount2020,
                 shrubamount2030.1,shrubamount2030.2,shrubamount2030.3,shrubamount2030.4,shrubamount2030.5,
                 shrubamount2040.1,shrubamount2040.2,shrubamount2040.3,shrubamount2040.4,shrubamount2040.5,
                 shrubamount2050.1,shrubamount2050.2,shrubamount2050.3,shrubamount2050.4,shrubamount2050.5,
                 shrubamount2060.1,shrubamount2060.2,shrubamount2060.3,shrubamount2060.4,shrubamount2060.5,
                 shrubamount2070.1,shrubamount2070.2,shrubamount2070.3,shrubamount2070.4,shrubamount2070.5)
YearB<-c(rep(2020,5), rep(2030,5), rep(2040,5), rep(2050,5), rep(2060,5), rep(2070,5))
LowerB<-c(rep(shrubamount2020,5),
         rep(min(shrubamount2030.1,shrubamount2030.2,shrubamount2030.3,shrubamount2030.4,shrubamount2030.5),5),
         rep(min(shrubamount2040.1,shrubamount2040.2,shrubamount2040.3,shrubamount2040.4,shrubamount2040.5),5),
         rep(min(shrubamount2050.1,shrubamount2050.2,shrubamount2050.3,shrubamount2050.4,shrubamount2050.5),5),
         rep(min(shrubamount2060.1,shrubamount2060.2,shrubamount2060.3,shrubamount2060.4,shrubamount2060.5),5),
         rep(min(shrubamount2070.1,shrubamount2070.2,shrubamount2070.3,shrubamount2070.4,shrubamount2070.5),5))
UpperB<-c(rep(shrubamount2020,5),
         rep(max(shrubamount2030.1,shrubamount2030.2,shrubamount2030.3,shrubamount2030.4,shrubamount2030.5),5),
         rep(max(shrubamount2040.1,shrubamount2040.2,shrubamount2040.3,shrubamount2040.4,shrubamount2040.5),5),
         rep(max(shrubamount2050.1,shrubamount2050.2,shrubamount2050.3,shrubamount2050.4,shrubamount2050.5),5),
         rep(max(shrubamount2060.1,shrubamount2060.2,shrubamount2060.3,shrubamount2060.4,shrubamount2060.5),5),
         rep(max(shrubamount2070.1,shrubamount2070.2,shrubamount2070.3,shrubamount2070.4,shrubamount2070.5),5))
library(ggplot2)
df.sh<-data.frame(YearB,Meanshrubamount,LowerB,UpperB)
p1.sh<-ggplot(df.sh) + 
  geom_point(aes(x = YearB, y = Meanshrubamount))+ 
  geom_ribbon(aes(x=YearB, ymin = LowerB, ymax = UpperB), fill = "grey70") +
  geom_line(aes(x = YearB, y = Meanshrubamount))+
  ylab("Proportion of Land Within 2 km (all Ontario) \nConsisting of Shrubland (Wooded Land < 20 y.o.)\nin ALCES Online Baseline Scenario")+
  xlab("Year")+my.theme

png("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/ShrublandOntario_2020_2070_ALCESBaseline.png",width=1080,height=700)
p1.sh
dev.off()



#Get for a smaller area, e.g. Bird Conservation Region 13, where Wood Thrush are predicted
#to be most abundant

########################################
#                                      #
#                                      #
#               BCR 13                 #
#                                      #
#                                      #
########################################

BCR13<-raster("3_ALCES Online Outputs/Baseline Scenario/BCR 13/year 2010/simulation 1/AO-forest-age-2020-2010.tif")
#use as a mask
#2010
meanDens2010B<-projectRaster(meanDens2010, BCR13)
meanDens2010.crop<-crop(meanDens2010B, BCR13)
meanDens2010.bcr13<-mask(meanDens2010.crop, BCR13)
density_brt_2010_200m.bcr13<-meanDens2010.bcr13*4
popsize2010.bcr13<-cellStats(density_brt_2010_200m.bcr13, stat=sum, na.rm=T) 
#399507.5 THIS IS ESTIMATED POPULATION SIZE IN BCR 13

# Same procedure for upper and lower CI predictions 
upperDens2010B<-projectRaster(upperDens2010, BCR13)
upperDens2010.crop<-crop(upperDens2010B, BCR13)
upperDens2010.bcr13<-mask(upperDens2010.crop, BCR13)
upper_brt_2010_200m.bcr13<-upperDens2010.bcr13*4
popsize2010.upper.bcr13<-cellStats(upper_brt_2010_200m.bcr13,stat=sum,na.rm=T) # THIS IS ESTIMATED POPULATION SIZE'S UPPER 90% B.C.I. LIMIT
#534702.8

lowerDens2010B<-projectRaster(lowerDens2010, BCR13)
lowerDens2010.crop<-crop(lowerDens2010B, BCR13)
lowerDens2010.bcr13<-mask(lowerDens2010.crop, BCR13)
lower_brt_2010_200m.bcr13<-lowerDens2010.bcr13*4
popsize2010.lower.bcr13<-cellStats(lower_brt_2010_200m.bcr13,stat=sum,na.rm=T) # THIS IS ESTIMATED POPULATION SIZE'S lower 90% B.C.I. LIMIT
#290390.7

#2020
meanDens2020B<-projectRaster(meanDens2020, BCR13)
meanDens2020.crop<-crop(meanDens2020B, BCR13)
meanDens2020.bcr13<-mask(meanDens2020.crop, BCR13)
density_brt_2020_200m.bcr13<-meanDens2020.bcr13*4
popsize2020.bcr13<-cellStats(density_brt_2020_200m.bcr13, stat=sum, na.rm=T) 
#405866.1 THIS IS ESTIMATED POPULATION SIZE IN BCR 13

# Same procedure for upper and lower CI predictions 
upperDens2020B<-projectRaster(upperDens2020, BCR13)
upperDens2020.crop<-crop(upperDens2020B, BCR13)
upperDens2020.bcr13<-mask(upperDens2020.crop, BCR13)
upper_brt_2020_200m.bcr13<-upperDens2020.bcr13*4
popsize2020.upper.bcr13<-cellStats(upper_brt_2020_200m.bcr13,stat=sum,na.rm=T) # THIS IS ESTIMATED POPULATION SIZE'S UPPER 90% B.C.I. LIMIT
#540197

lowerDens2020B<-projectRaster(lowerDens2020, BCR13)
lowerDens2020.crop<-crop(lowerDens2020B, BCR13)
lowerDens2020.bcr13<-mask(lowerDens2020.crop, BCR13)
lower_brt_2020_200m.bcr13<-lowerDens2020.bcr13*4
popsize2020.lower.bcr13<-cellStats(lower_brt_2020_200m.bcr13,stat=sum,na.rm=T) # THIS IS ESTIMATED POPULATION SIZE'S lower 90% B.C.I. LIMIT
#297991.7

#2030
meanDens2030B<-projectRaster(meanDens2030, BCR13)
meanDens2030.crop<-crop(meanDens2030B, BCR13)
meanDens2030.bcr13<-mask(meanDens2030.crop, BCR13)
density_brt_2030_200m.bcr13<-meanDens2030.bcr13*4
popsize2030.bcr13<-cellStats(density_brt_2030_200m.bcr13, stat=sum, na.rm=T) 
#476514.1 THIS IS ESTIMATED POPULATION SIZE IN BCR 13

# Same procedure for upper and lower CI predictions 
upperDens2030B<-projectRaster(upperDens2030, BCR13)
upperDens2030.crop<-crop(upperDens2030B, BCR13)
upperDens2030.bcr13<-mask(upperDens2030.crop, BCR13)
upper_brt_2030_200m.bcr13<-upperDens2030.bcr13*4
popsize2030.upper.bcr13<-cellStats(upper_brt_2030_200m.bcr13,stat=sum,na.rm=T) # THIS IS ESTIMATED POPULATION SIZE'S UPPER 90% B.C.I. LIMIT
#636975.5

lowerDens2030B<-projectRaster(lowerDens2030, BCR13)
lowerDens2030.crop<-crop(lowerDens2030B, BCR13)
lowerDens2030.bcr13<-mask(lowerDens2030.crop, BCR13)
lower_brt_2030_200m.bcr13<-lowerDens2030.bcr13*4
popsize2030.lower.bcr13<-cellStats(lower_brt_2030_200m.bcr13,stat=sum,na.rm=T) # THIS IS ESTIMATED POPULATION SIZE'S lower 90% B.C.I. LIMIT
#347540.2

#2040
meanDens2040B<-projectRaster(meanDens2040, BCR13)
meanDens2040.crop<-crop(meanDens2040B, BCR13)
meanDens2040.bcr13<-mask(meanDens2040.crop, BCR13)
density_brt_2040_200m.bcr13<-meanDens2040.bcr13*4
popsize2040.bcr13<-cellStats(density_brt_2040_200m.bcr13, stat=sum, na.rm=T) 
#460853.4 THIS IS ESTIMATED POPULATION SIZE IN BCR 13

# Same procedure for upper and lower CI predictions 
upperDens2040B<-projectRaster(upperDens2040, BCR13)
upperDens2040.crop<-crop(upperDens2040B, BCR13)
upperDens2040.bcr13<-mask(upperDens2040.crop, BCR13)
upper_brt_2040_200m.bcr13<-upperDens2040.bcr13*4
popsize2040.upper.bcr13<-cellStats(upper_brt_2040_200m.bcr13,stat=sum,na.rm=T) # THIS IS ESTIMATED POPULATION SIZE'S UPPER 90% B.C.I. LIMIT
#615065.5

lowerDens2040B<-projectRaster(lowerDens2040, BCR13)
lowerDens2040.crop<-crop(lowerDens2040B, BCR13)
lowerDens2040.bcr13<-mask(lowerDens2040.crop, BCR13)
lower_brt_2040_200m.bcr13<-lowerDens2040.bcr13*4
popsize2040.lower.bcr13<-cellStats(lower_brt_2040_200m.bcr13,stat=sum,na.rm=T) # THIS IS ESTIMATED POPULATION SIZE'S lower 90% B.C.I. LIMIT
#337128.8

#2050
meanDens2050B<-projectRaster(meanDens2050, BCR13)
meanDens2050.crop<-crop(meanDens2050B, BCR13)
meanDens2050.bcr13<-mask(meanDens2050.crop, BCR13)
density_brt_2050_200m.bcr13<-meanDens2050.bcr13*4
popsize2050.bcr13<-cellStats(density_brt_2050_200m.bcr13, stat=sum, na.rm=T) 
#460089 THIS IS ESTIMATED POPULATION SIZE IN BCR 13

# Same procedure for upper and lower CI predictions 
upperDens2050B<-projectRaster(upperDens2050, BCR13)
upperDens2050.crop<-crop(upperDens2050B, BCR13)
upperDens2050.bcr13<-mask(upperDens2050.crop, BCR13)
upper_brt_2050_200m.bcr13<-upperDens2050.bcr13*4
popsize2050.upper.bcr13<-cellStats(upper_brt_2050_200m.bcr13,stat=sum,na.rm=T) # THIS IS ESTIMATED POPULATION SIZE'S UPPER 90% B.C.I. LIMIT
#616407

lowerDens2050B<-projectRaster(lowerDens2050, BCR13)
lowerDens2050.crop<-crop(lowerDens2050B, BCR13)
lowerDens2050.bcr13<-mask(lowerDens2050.crop, BCR13)
lower_brt_2050_200m.bcr13<-lowerDens2050.bcr13*4
popsize2050.lower.bcr13<-cellStats(lower_brt_2050_200m.bcr13,stat=sum,na.rm=T) # THIS IS ESTIMATED POPULATION SIZE'S lower 90% B.C.I. LIMIT
#335932.2

#2060
meanDens2060B<-projectRaster(meanDens2060, BCR13)
meanDens2060.crop<-crop(meanDens2060B, BCR13)
meanDens2060.bcr13<-mask(meanDens2060.crop, BCR13)
density_brt_2060_200m.bcr13<-meanDens2060.bcr13*4
popsize2060.bcr13<-cellStats(density_brt_2060_200m.bcr13, stat=sum, na.rm=T) 
#462882.1 THIS IS ESTIMATED POPULATION SIZE IN BCR 13

# Same procedure for upper and lower CI predictions 
upperDens2060B<-projectRaster(upperDens2060, BCR13)
upperDens2060.crop<-crop(upperDens2060B, BCR13)
upperDens2060.bcr13<-mask(upperDens2060.crop, BCR13)
upper_brt_2060_200m.bcr13<-upperDens2060.bcr13*4
popsize2060.upper.bcr13<-cellStats(upper_brt_2060_200m.bcr13,stat=sum,na.rm=T) # THIS IS ESTIMATED POPULATION SIZE'S UPPER 90% B.C.I. LIMIT
#624012.7

lowerDens2060B<-projectRaster(lowerDens2060, BCR13)
lowerDens2060.crop<-crop(lowerDens2060B, BCR13)
lowerDens2060.bcr13<-mask(lowerDens2060.crop, BCR13)
lower_brt_2060_200m.bcr13<-lowerDens2060.bcr13*4
popsize2060.lower.bcr13<-cellStats(lower_brt_2060_200m.bcr13,stat=sum,na.rm=T) # THIS IS ESTIMATED POPULATION SIZE'S lower 90% B.C.I. LIMIT
#334840.8


Popn.bcr13<-c(popsize2010.bcr13,
              popsize2020.bcr13,
              popsize2030.bcr13,
              popsize2040.bcr13,
              popsize2050.bcr13,
              popsize2060.bcr13)
PopnLower.bcr13<-c(popsize2010.lower.bcr13,
                   popsize2020.lower.bcr13,
                   popsize2030.lower.bcr13,
                   popsize2040.lower.bcr13,
                   popsize2050.lower.bcr13,
                   popsize2060.lower.bcr13)
PopnUpper.bcr13<-c(popsize2010.upper.bcr13,
                   popsize2020.upper.bcr13,
                   popsize2030.upper.bcr13,
                   popsize2040.upper.bcr13,
                   popsize2050.upper.bcr13,
                   popsize2060.upper.bcr13)
Year.bcr13<-c(2020,2030,2040,2050,2060,2070)

df2<-data.frame(Year.bcr13,Popn.bcr13,PopnLower.bcr13,PopnUpper.bcr13)
p2<-ggplot(df2) + 
  geom_point(aes(x = Year.bcr13, y = Popn.bcr13))+ 
  #geom_errorbar(aes(x=Year, ymin=PopnLower, ymax=PopnUpper),color="#F8766D")+
  geom_line(aes(x = Year.bcr13, y = Popn.bcr13))+
  geom_line(aes(x = Year.bcr13, y = PopnLower.bcr13), col="red", linetype="dashed")+
  geom_line(aes(x = Year.bcr13, y = PopnUpper.bcr13), col="red", linetype="dashed")+
  ylab("Predicted BCR 13 Wood Thrush Population + \nBootstrap 90 % C.I.")+
  xlab("Year")+my.theme

png("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/WOTH.BCR13_2020_2070_ALCESBaseline.png",width=1080,height=700)
p2
dev.off()
#The resulting line plot is just for Wood Thrush populations in Bird
#Conservation Region 13


########################################
#                                      #
#                                      #
#               BCR 12                 #
#                                      #
#                                      #
########################################

library(maptools)
library(raster)
library(rgdal)
library(sp)

BCR12<-readOGR("2_GIS outputs for ALCES Online/BCR12WOTHOntario/BCR12WOTHOntario","BCR12WOTHOntario")
BCR12.rp<-spTransform(BCR12, CRSobj="+proj=lcc +lat_0=0 +lon_0=-85 +lat_1=44.5 +lat_2=53.5 +x_0=930000 +y_0=6430000 +datum=NAD83 +units=m +no_defs")
#use as a mask

#2010
meanDens2010.crop <- crop(meanDens2010, BCR12.rp)
meanDens2010.bcr12 <- mask(meanDens2010.crop, BCR12.rp)
density_brt_2010_200m.bcr12<-meanDens2010.bcr12*4
popsize2010.bcr12<-cellStats(density_brt_2010_200m.bcr12, stat=sum, na.rm=T) 
#254841.5

upperDens2010.crop <- crop(upperDens2010, BCR12.rp)
upperDens2010.bcr12 <- mask(upperDens2010.crop, BCR12.rp)
upper_density_brt_2010_200m.bcr12<-upperDens2010.bcr12*4
popsize2010.upper.bcr12<-cellStats(upper_density_brt_2010_200m.bcr12, stat=sum, na.rm=T) 
#328152.1

lowerDens2010.crop <- crop(lowerDens2010, BCR12.rp)
lowerDens2010.bcr12 <- mask(lowerDens2010.crop, BCR12.rp)
lower_density_brt_2010_200m.bcr12<-lowerDens2010.bcr12*4
popsize2010.lower.bcr12<-cellStats(lower_density_brt_2010_200m.bcr12, stat=sum, na.rm=T) 
#194312.6

#2020
meanDens2020.crop <- crop(meanDens2020, BCR12.rp)
meanDens2020.bcr12 <- mask(meanDens2020.crop, BCR12.rp)
density_brt_2020_200m.bcr12<-meanDens2020.bcr12*4
popsize2020.bcr12<-cellStats(density_brt_2020_200m.bcr12, stat=sum, na.rm=T) 
#258274.7

upperDens2020.crop <- crop(upperDens2020, BCR12.rp)
upperDens2020.bcr12 <- mask(upperDens2020.crop, BCR12.rp)
upper_density_brt_2020_200m.bcr12<-upperDens2020.bcr12*4
popsize2020.upper.bcr12<-cellStats(upper_density_brt_2020_200m.bcr12, stat=sum, na.rm=T) 
#336437.3

lowerDens2020.crop <- crop(lowerDens2020, BCR12.rp)
lowerDens2020.bcr12 <- mask(lowerDens2020.crop, BCR12.rp)
lower_density_brt_2020_200m.bcr12<-lowerDens2020.bcr12*4
popsize2020.lower.bcr12<-cellStats(lower_density_brt_2020_200m.bcr12, stat=sum, na.rm=T) 
#194464.8


#2030
meanDens2030.crop <- crop(meanDens2030, BCR12.rp)
meanDens2030.bcr12 <- mask(meanDens2030.crop, BCR12.rp)
density_brt_2030_200m.bcr12<-meanDens2030.bcr12*4
popsize2030.bcr12<-cellStats(density_brt_2030_200m.bcr12, stat=sum, na.rm=T) 
#272665.5

upperDens2030.crop <- crop(upperDens2030, BCR12.rp)
upperDens2030.bcr12 <- mask(upperDens2030.crop, BCR12.rp)
upper_density_brt_2030_200m.bcr12<-upperDens2030.bcr12*4
popsize2030.upper.bcr12<-cellStats(upper_density_brt_2030_200m.bcr12, stat=sum, na.rm=T) 
#362500.3

lowerDens2030.crop <- crop(lowerDens2030, BCR12.rp)
lowerDens2030.bcr12 <- mask(lowerDens2030.crop, BCR12.rp)
lower_density_brt_2030_200m.bcr12<-lowerDens2030.bcr12*4
popsize2030.lower.bcr12<-cellStats(lower_density_brt_2030_200m.bcr12, stat=sum, na.rm=T) 
#201761.4


#2040
meanDens2040.crop <- crop(meanDens2040, BCR12.rp)
meanDens2040.bcr12 <- mask(meanDens2040.crop, BCR12.rp)
density_brt_2040_200m.bcr12<-meanDens2040.bcr12*4
popsize2040.bcr12<-cellStats(density_brt_2040_200m.bcr12, stat=sum, na.rm=T) 
#295463.5

upperDens2040.crop <- crop(upperDens2040, BCR12.rp)
upperDens2040.bcr12 <- mask(upperDens2040.crop, BCR12.rp)
upper_density_brt_2040_200m.bcr12<-upperDens2040.bcr12*4
popsize2040.upper.bcr12<-cellStats(upper_density_brt_2040_200m.bcr12, stat=sum, na.rm=T) 
#403698.2

lowerDens2040.crop <- crop(lowerDens2040, BCR12.rp)
lowerDens2040.bcr12 <- mask(lowerDens2040.crop, BCR12.rp)
lower_density_brt_2040_200m.bcr12<-lowerDens2040.bcr12*4
popsize2040.lower.bcr12<-cellStats(lower_density_brt_2040_200m.bcr12, stat=sum, na.rm=T) 
#214269.6


#2050
meanDens2050.crop <- crop(meanDens2050, BCR12.rp)
meanDens2050.bcr12 <- mask(meanDens2050.crop, BCR12.rp)
density_brt_2050_200m.bcr12<-meanDens2050.bcr12*4
popsize2050.bcr12<-cellStats(density_brt_2050_200m.bcr12, stat=sum, na.rm=T) 
#313078.3

upperDens2050.crop <- crop(upperDens2050, BCR12.rp)
upperDens2050.bcr12 <- mask(upperDens2050.crop, BCR12.rp)
upper_density_brt_2050_200m.bcr12<-upperDens2050.bcr12*4
popsize2050.upper.bcr12<-cellStats(upper_density_brt_2050_200m.bcr12, stat=sum, na.rm=T) 
#443563.6

lowerDens2050.crop <- crop(lowerDens2050, BCR12.rp)
lowerDens2050.bcr12 <- mask(lowerDens2050.crop, BCR12.rp)
lower_density_brt_2050_200m.bcr12<-lowerDens2050.bcr12*4
popsize2050.lower.bcr12<-cellStats(lower_density_brt_2050_200m.bcr12, stat=sum, na.rm=T) 
#221147.3


#2060
meanDens2060.crop <- crop(meanDens2060, BCR12.rp)
meanDens2060.bcr12 <- mask(meanDens2060.crop, BCR12.rp)
density_brt_2060_200m.bcr12<-meanDens2060.bcr12*4
popsize2060.bcr12<-cellStats(density_brt_2060_200m.bcr12, stat=sum, na.rm=T) 
#330543.1

upperDens2060.crop <- crop(upperDens2060, BCR12.rp)
upperDens2060.bcr12 <- mask(upperDens2060.crop, BCR12.rp)
upper_density_brt_2060_200m.bcr12<-upperDens2060.bcr12*4
popsize2060.upper.bcr12<-cellStats(upper_density_brt_2060_200m.bcr12, stat=sum, na.rm=T) 
#498540.2

lowerDens2060.crop <- crop(lowerDens2060, BCR12.rp)
lowerDens2060.bcr12 <- mask(lowerDens2060.crop, BCR12.rp)
lower_density_brt_2060_200m.bcr12<-lowerDens2060.bcr12*4
popsize2060.lower.bcr12<-cellStats(lower_density_brt_2060_200m.bcr12, stat=sum, na.rm=T) 
#225611.8


Popn.bcr12<-c(popsize2010.bcr12,
              popsize2020.bcr12,
              popsize2030.bcr12,
              popsize2040.bcr12,
              popsize2050.bcr12,
              popsize2060.bcr12)
PopnLower.bcr12<-c(popsize2010.lower.bcr12,
                   popsize2020.lower.bcr12,
                   popsize2030.lower.bcr12,
                   popsize2040.lower.bcr12,
                   popsize2050.lower.bcr12,
                   popsize2060.lower.bcr12)
PopnUpper.bcr12<-c(popsize2010.upper.bcr12,
                   popsize2020.upper.bcr12,
                   popsize2030.upper.bcr12,
                   popsize2040.upper.bcr12,
                   popsize2050.upper.bcr12,
                   popsize2060.upper.bcr12)
Year.bcr12<-c(2020,2030,2040,2050,2060,2070)

df2<-data.frame(Year.bcr12,Popn.bcr12,PopnLower.bcr12,PopnUpper.bcr12)
p2<-ggplot(df2) + 
  geom_point(aes(x = Year.bcr12, y = Popn.bcr12))+ 
  #geom_errorbar(aes(x=Year, ymin=PopnLower, ymax=PopnUpper),color="#F8766D")+
  geom_line(aes(x = Year.bcr12, y = Popn.bcr12))+
  geom_line(aes(x = Year.bcr12, y = PopnLower.bcr12), col="red", linetype="dashed")+
  geom_line(aes(x = Year.bcr12, y = PopnUpper.bcr12), col="red", linetype="dashed")+
  ylab("Predicted BCR 12 Wood Thrush Population + \nBootstrap 90 % C.I.")+
  xlab("Year")+my.theme

png("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/WOTH.BCR12_2020_2070_ALCESBaseline.png",width=1080,height=700)
p2
dev.off()
#The resulting line plot is just for Wood Thrush populations in Bird
#Conservation Region 12
