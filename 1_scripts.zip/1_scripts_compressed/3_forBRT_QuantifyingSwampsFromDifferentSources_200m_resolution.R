#Note: This script is for processing the swamp land cover data to run the ALCES 
#200 BRT model. The ALCES 200 BRT model contains one spatial scale for the effect of 
#swamp cover - local or swamp.150m - so this script does not calculate swamp cover
#within 250 m, 1000 m or 2000 m.
memory.limit(size=500000)
library(raster)
library(dismo)
library(rpart)
library(maptools)
library(data.table)
library(rgdal)
library(dplyr)
library(ggplot2)
library(spatial)
library(rasterVis)
library(RColorBrewer)

#Ag Canada annual cover layers for individual provinces in 2011, 2015, 2019: 30-
#These data do not separate out swamp from other wetland types.
#Wood Thrush use swamps as habitat according to Karl Heide.
#Some Shrub pixels in Ag Can Landsat layers may actually be swamps

#Swamp layers must be compiled from separate sources since there are no 
#national layers.

#Once a 30-m raster is created for each province, process it the same way
#as the annual cover layers

#read in raster

#Ontario Swamp Layer
swamp<-c("OLCswamp30.tif")
for (i in 1:length(swamp)) { 
  swamp.i <- raster(paste0("0_data_for_BRT_models/raw/Wetlands/Ontario Land Cover/",swamp[i]))
  ## sigma = 150m
  fw150<-focalWeight(x=swamp.i,d=150,type="Gauss")
  swamp.i_Gauss150.local<-focal(swamp.i,w=fw150,na.rm=TRUE)
  names(swamp.i_Gauss150.local) <- gsub("swamp30","swamp.local_",names(swamp.i))
  writeRaster(swamp.i_Gauss150.local, filename=paste0("0_data_for_BRT_models/raw/Wetlands/Ontario Land Cover/",names(swamp.i_Gauss150.local),".tif"),overwrite=TRUE)
}

#Quebec Swamp Layer
swamp<-c("Quebecswamp30.tif")
for (i in 1:length(swamp)) { 
  swamp.i <- raster(paste0("0_data_for_BRT_models/raw/Wetlands/Quebec Wetland Inventory/",swamp[i]))
  ## sigma = 150m
  fw150<-focalWeight(x=swamp.i,d=150,type="Gauss")
  swamp.i_Gauss150.local<-focal(swamp.i,w=fw150,na.rm=TRUE)
  names(swamp.i_Gauss150.local) <- gsub("swamp30","swamp.local_",names(swamp.i))
  writeRaster(swamp.i_Gauss150.local, filename=paste0("0_data_for_BRT_models/raw/Wetlands/Quebec Wetland Inventory/",names(swamp.i_Gauss150.local),".tif"),overwrite=TRUE)
}

#New Brunswick Swamp Layer
swamp<-c("NewBrunswickswamp30.tif")
for (i in 1:length(swamp)) { 
  swamp.i <- raster(paste0("0_data_for_BRT_models/raw/Wetlands/Wetlands from New Brunswick Forest Inventory/",swamp[i]))
  ## sigma = 150m
  fw150<-focalWeight(x=swamp.i,d=150,type="Gauss")
  swamp.i_Gauss150.local<-focal(swamp.i,w=fw150,na.rm=TRUE)
  names(swamp.i_Gauss150.local) <- gsub("swamp30","swamp.local_",names(swamp.i))
  writeRaster(swamp.i_Gauss150.local, filename=paste0("0_data_for_BRT_models/raw/Wetlands/Wetlands from New Brunswick Forest Inventory/",names(swamp.i_Gauss150.local),".tif"),overwrite=TRUE)
}

#Nova Scotia Swamp Layer
swamp<-c("NovaScotiaswamp30.tif")
for (i in 1:length(swamp)) { 
  swamp.i <- raster(paste0("0_data_for_BRT_models/raw/Wetlands/Wetlands From Nova Scotia Forest Inventory/",swamp[i]))
  ## sigma = 150m
  fw150<-focalWeight(x=swamp.i,d=150,type="Gauss")
  swamp.i_Gauss150.local<-focal(swamp.i,w=fw150,na.rm=TRUE)
  names(swamp.i_Gauss150.local) <- gsub("swamp30","swamp.local_",names(swamp.i))
  writeRaster(swamp.i_Gauss150.local, filename=paste0("0_data_for_BRT_models/raw/Wetlands/Wetlands From Nova Scotia Forest Inventory/",names(swamp.i_Gauss150.local),".tif"),overwrite=TRUE)
}


#Aggregate (resample to coarser resolution to speed up processing)
#Ontario
rlist <- list.files("0_data_for_BRT_models/raw/Wetlands/Ontario Land Cover/",pattern="local.tif$")
for (i in rlist){
  ras<-raster(paste0("0_data_for_BRT_models/raw/Wetlands/Ontario Land Cover/",i))
  #change resolution from 30x30 to 150x150
  ras.aggregate <- aggregate(ras, fact=5)
  res(ras.aggregate)
  names(ras.aggregate) <- gsub("local","150m",names(ras))
  writeRaster(ras.aggregate, filename=paste0("0_data_for_BRT_models/raw/Wetlands/Ontario Land Cover/150 m/",names(ras.aggregate),".tif"),overwrite=TRUE)
}


#Quebec
rlist <- list.files("0_data_for_BRT_models/raw/Wetlands/Quebec Wetland Inventory/",pattern="local.tif$")
for (i in rlist){
  ras<-raster(paste0("0_data_for_BRT_models/raw/Wetlands/Quebec Wetland Inventory/",i))
  #change resolution from 30x30 to 150x150
  ras.aggregate <- aggregate(ras, fact=5)
  res(ras.aggregate)
  names(ras.aggregate) <- gsub("local","150m",names(ras))
  writeRaster(ras.aggregate, filename=paste0("0_data_for_BRT_models/raw/Wetlands/Quebec Wetland Inventory/150 m/",names(ras.aggregate),".tif"),overwrite=TRUE)
}


#New Brunswick
rlist <- list.files("0_data_for_BRT_models/raw/Wetlands/Wetlands from New Brunswick Forest Inventory/",pattern="local.tif$")
for (i in rlist){
  ras<-raster(paste0("0_data_for_BRT_models/raw/Wetlands/Wetlands from New Brunswick Forest Inventory/",i))
  #change resolution from 30x30 to 150x150
  ras.aggregate <- aggregate(ras, fact=5)
  res(ras.aggregate)
  names(ras.aggregate) <- gsub("local","150m",names(ras))
  writeRaster(ras.aggregate, filename=paste0("0_data_for_BRT_models/raw/Wetlands/Wetlands from New Brunswick Forest Inventory/150 m/",names(ras.aggregate),".tif"),overwrite=TRUE)
}


#Nova Scotia
rlist <- list.files("0_data_for_BRT_models/raw/Wetlands/Wetlands from Nova Scotia Forest Inventory/",pattern="local.tif$")
for (i in rlist){
  ras<-raster(paste0("0_data_for_BRT_models/raw/Wetlands/Wetlands from Nova Scotia Forest Inventory/",i))
  #change resolution from 30x30 to 150x150
  ras.aggregate <- aggregate(ras, fact=5)
  res(ras.aggregate)
  names(ras.aggregate) <- gsub("local","150m",names(ras))
  writeRaster(ras.aggregate, filename=paste0("0_data_for_BRT_models/raw/Wetlands/Wetlands from Nova Scotia Forest Inventory/150 m/",names(ras.aggregate),".tif"),overwrite=TRUE)
}

#Resampling to 200-m resolution for ALCES 200 model

rlist5 <- list.files("0_data_for_BRT_models/raw/Wetlands/150 m/",pattern=".tif$")
for (i in rlist5){
  ras<-raster(paste0("0_data_for_BRT_models/raw/Wetlands/150 m/",i))
  #change resolution from 150x150 to 200x200
  resampleFactor <- 200/150
  inCols <- ncol(ras)
  inRows <- nrow(ras)
  resampledRaster <- raster(ncol=(inCols / resampleFactor), nrow=(inRows / resampleFactor))
  extent(resampledRaster) <- extent(ras)
  res(resampledRaster)<-200#set to exactly 200 m before resampling occurs
  resampledRaster <- resample(ras,resampledRaster,datatype="INT1U",method='bilinear')
  writeRaster(resampledRaster, filename=paste0("0_data_for_BRT_models/raw/Wetlands/resampled to 200 m/",names(resampledRaster),".tif"),overwrite=TRUE)
}

