#The purpose of this script is to show how to obtain
#outputs from the baseline ALCES Online scenario run for 
#Wood Thrush in Ontario. The
#outputs we are interested in will serve as some of the 
#inputs for Zonation scenarios. 

#We are specifically interested in two items from each scenario. 
#First, we need rasters of mean predicted density in 2020 and 
#2070, the start and end years of the baseline scenario.
#(In ALCES Online, the start and end years are actually "2010" and
#"2060", but "2010" is initiated using land cover and forest age from 2020).
#Second, we need rasters of the uncertainty (standard
#deviation) in those years' estimates for each 250-m pixel.

#Uncertainty is due to both BRT sample uncertainty and due to
#simulation runs. So ideally, our mean predicted density is based on
#a mean of 5 means (1 per simulation run for each scenario in 2100)
#and our standard deviation is obtained as the square root of
#the sum of 5 standard deviations of 250 density predictions.
#There may not be time to get predicted densities for all 5 simulation
#runs, so for now 1 simulation run is used in this script. However,
#the raster stacks containing the variables necessary for getting
#predictions for all simulation runs are complete and will be 
#available.

#Once we have the necessary raster inputs, we set up a
#Zonation scenario outside of R and ran it. We then
#process some of the Zonation output inside R to generate
#plots the way we like.

#For now there is a single scenario for Wood Thrush in 
#ALCES Online.

#get rasters for the start and end years of the baseline scenario, 
#for both the mean density prediction out of 250 predictions for 
#simulation run 1, as well as the uncertainty in that mean density 
#estimate.

#Since the Zonation scenario will take longer to run for a larger area
#and larger number of pixels, the 200-m rasters will take longer to
#process than 250-m rasters of the same size. So I've split up the whole
#Wood Thrush area in Ontario into separate Zonation exercises for BCR 13
#and BCR 12.

########################################
#                                      #
#                                      #
#               BCR 13                 #
#                                      #
#                                      #
########################################
library(maptools)
library(raster)
library(rgdal)
library(sp)

#2010 (Year 0 in simulation: actually 2020 in real life)
meanDens2010<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Year 2010 Simulation 1/mean_WOTH_Ontario.tif")
sdDens2010<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Year 2010 Simulation 1/sd_WOTH_Ontario.tif")

#2060 (Year 50 in simulation: actually 2070 in real life)
#There are 5 mean density and SD rasters from simulation runs 1 to 5
#for 2060 (simulation year 50).
#Uncertainty is due to both BRT sample uncertainty and due to
#simulation runs. So our mean predicted density is based on
#a mean of 5 means (1 per simulation run for each scenario in 2100)
#and our standard deviation is obtained as the square root of
#the sum of 5 standard deviations of 250 density predictions.

meanDens1<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Year 2060 Simulation 1/mean_WOTH_Ontario.tif")
meanDens2<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Year 2060 Simulation 2/mean_WOTH_Ontario.tif")
meanDens3<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Year 2060 Simulation 3/mean_WOTH_Ontario.tif")
meanDens4<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Year 2060 Simulation 4/mean_WOTH_Ontario.tif")
meanDens5<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Year 2060 Simulation 5/mean_WOTH_Ontario.tif")
#get the mean of means
meanDens2060<-(meanDens1+meanDens2+meanDens3+meanDens4+meanDens5)/5

sdDens1<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Year 2060 Simulation 1/sd_WOTH_Ontario.tif")
sdDens2<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Year 2060 Simulation 2/sd_WOTH_Ontario.tif")
sdDens3<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Year 2060 Simulation 3/sd_WOTH_Ontario.tif")
sdDens4<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Year 2060 Simulation 4/sd_WOTH_Ontario.tif")
sdDens5<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Year 2060 Simulation 5/sd_WOTH_Ontario.tif")
#get the overall SD
sdDens2060<-sqrt(sdDens1^2+sdDens2^2+sdDens3^2+sdDens4^2+sdDens5^2)

#clip each of these rasters to a smaller area that will be used
#in Zonation scenarios

BCR13<-raster("3_ALCES Online Outputs/Baseline Scenario/BCR 13/year 2010/simulation 1/AO-forest-age-2020-2010.tif")
#use as a mask
#2010
meanDens2010B<-projectRaster(meanDens2010, BCR13)
meanDens2010.crop<-crop(meanDens2010B, BCR13)
meanDens2010.masked<-mask(meanDens2010.crop, BCR13)
meanDens2010.bcr13<-meanDens2010.masked
meanDens2010.bcr13[meanDens2010.masked>1]<-1

ncell(meanDens2010.bcr13)#8212674
ncell(meanDens2010.bcr13[!is.na(meanDens2010.bcr13)])#2022145
#Total area: 2022145*6.25 = 12,638,406 ha

#some density estimates are unusually high so adjust them to a threshold
#value more like observed maximum densities from individual studies. This
#threshold value can be changed.
density_brt_2010_200m.bcr13<-meanDens2010.bcr13*4
popsize2010.bcr13<-cellStats(density_brt_2010_200m.bcr13, stat=sum, na.rm=T) 
#255597.3 THIS IS ESTIMATED POPULATION SIZE IN BCR 13
#Knowing this size relative to the regional population size
#in 2060 will be needed for estimating and mapping how
#much land to prioritize to maintain different percentages
#of this current population.
plot(density_brt_2010_200m.bcr13)
#writeRaster(density_brt_2010_200m.bcr13, filename="4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Zonation Inputs/meandens_2010.bcr13.tif", format="GTiff",overwrite=TRUE)

sdDens2010B<-projectRaster(sdDens2010, BCR13)
sdDens2010.crop<-crop(sdDens2010B, BCR13)
sdDens2010.bcr13<-mask(sdDens2010.crop, BCR13)
#This layer represents the amount of uncertainty in the estimated
#density of Wood Thrush in each pixel. Pixels with high density and 
#low uncertainty (low standard deviation) are assigned higher 
#priority for conservation or management.
#writeRaster(sdDens2010.bcr13, filename="4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Zonation Inputs/SDdens_2010.bcr13.tif", format="GTiff",overwrite=TRUE)

#confidence interval estimates for population size
Dens2010.bcr13.95LCL<-meanDens2010.bcr13-1.96*sdDens2010.bcr13
density_brt_2010_200m.bcr13.95LCL<-Dens2010.bcr13.95LCL*4
popsize2010.bcr13.95LCL<-cellStats(density_brt_2010_200m.bcr13.95LCL, stat=sum, na.rm=T) 
#145201.8
Dens2010.bcr13.95UCL<-meanDens2010.bcr13+1.96*sdDens2010.bcr13
density_brt_2010_200m.bcr13.95UCL<-Dens2010.bcr13.95UCL*4
popsize2010.bcr13.95UCL<-cellStats(density_brt_2010_200m.bcr13.95UCL, stat=sum, na.rm=T) 
#365992.8

#2060
meanDens2060B<-projectRaster(meanDens2060, BCR13)
meanDens2060.crop<-crop(meanDens2060B, BCR13)
meanDens2060.masked<-mask(meanDens2060.crop, BCR13)
meanDens2060.bcr13<-meanDens2060.masked
meanDens2060.bcr13[meanDens2060.masked>1]<-1
#some density estimates are unusually high so adjust them to a threshold
#value more like observed maximum densities from individual studies. This
#threshold value can be changed.
density_brt_2060_200m.bcr13<-meanDens2060.bcr13*4
plot(density_brt_2060_200m.bcr13)
popsize2060.bcr13<-cellStats(density_brt_2060_200m.bcr13, stat=sum, na.rm=T) 
#296376.6 (mean from runs 1-5)
#The population in Year 0 is 86.24 % (all 5 runs) of what is expected in Year 50
#writeRaster(density_brt_2060_200m.bcr13, filename="4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Zonation Inputs/meandens_2060.bcr13.tif", format="GTiff",overwrite=TRUE)

sdDens2060B<-projectRaster(sdDens2060, BCR13)
sdDens2060.crop<-crop(sdDens2060B, BCR13)
sdDens2060.bcr13<-mask(sdDens2060.crop, BCR13)
#writeRaster(sdDens2060.bcr13, filename="4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Zonation Inputs/SDdens_2060.bcr13.tif", format="GTiff",overwrite=TRUE)

#confidence interval estimates for population size
Dens2060.bcr13.95LCL<-meanDens2060.bcr13-1.96*sdDens2060.bcr13
density_brt_2060_200m.bcr13.95LCL<-Dens2060.bcr13.95LCL*4
popsize2060.bcr13.95LCL<-cellStats(density_brt_2060_200m.bcr13.95LCL, stat=sum, na.rm=T) 
#12678.16
Dens2060.bcr13.95UCL<-meanDens2060.bcr13+1.96*sdDens2060.bcr13
density_brt_2060_200m.bcr13.95UCL<-Dens2060.bcr13.95UCL*4
popsize2060.bcr13.95UCL<-cellStats(density_brt_2060_200m.bcr13.95UCL, stat=sum, na.rm=T) 
#580075.1

#Extract the locations of known Wood Thrush occurrence within
#Bird Conservation Region 13, with the measured abundance at each location.
#These locations will increase the weight and prioritization
#of those locations for conservation or special management.

#Get WOTH point locations used in BRTs to create text file "SSI_WOTH_CH_BCR13"
WOTHcounts<-read.csv("0_data_for_BRT_models/raw/WOTH counts combined/WOTHcounts.studyregion.csv")
str(WOTHcounts)
#X=long, Y=lat, spp=Abundance. 
#We need coordinates in LCC (projection that the rasters are in)

library(sf)
lcc_crs <- "+proj=lcc +lat_0=0 +lon_0=-85 +lat_1=44.5 +lat_2=53.5 +x_0=930000 +y_0=6430000 +datum=NAD83 +units=m +no_defs"
WOTH.sf<-sf::st_as_sf(WOTHcounts, coords=c("X","Y"))
p1 <- st_set_crs(WOTH.sf, "+proj=longlat +datum=NAD83 +no_defs")
p1 <- st_transform(p1, lcc_crs)
st_write(p1, "4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Zonation Inputs/WOTHcounts_LCC.csv", layer_options = "GEOMETRY=AS_XY")

datcombo<-read.csv("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Zonation Inputs/WOTHcounts_LCC.csv", header=TRUE)
SSI_WOTH_CH<-datcombo[,c("X","Y","spp")]
str(SSI_WOTH_CH)#238954
SSI_WOTH_CH<-SSI_WOTH_CH[SSI_WOTH_CH$spp>0,]
str(SSI_WOTH_CH)#12358
#Now get rid of the points outside BCR 13
extent(BCR13)
#class      : Extent 
#xmin       : 1068457 
#xmax       : 1763857 
#ymin       : 11702630 
#ymax       : 12175030   

#remove WOTH occurrences outside of ALCES Online Ontario BCR 13 extent
SSI_WOTH_CH_BCR13<-SSI_WOTH_CH[SSI_WOTH_CH$X>1068457,]
SSI_WOTH_CH_BCR13<-SSI_WOTH_CH_BCR13[SSI_WOTH_CH_BCR13$X<1763857,]
SSI_WOTH_CH_BCR13<-SSI_WOTH_CH_BCR13[SSI_WOTH_CH_BCR13$Y>11702630,]
SSI_WOTH_CH_BCR13<-SSI_WOTH_CH_BCR13[SSI_WOTH_CH_BCR13$Y<12175030,]
write.csv(SSI_WOTH_CH_BCR13, file="4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Zonation Inputs/SSI_WOTH_CH_BCR13.csv")
#strip header from this file, add a fourth column of all zeros, then save as text file

########################################
#                                      #
#                                      #
#               BCR 12                 #
#                                      #
#                                      #
########################################

library(maptools)
library(raster)
library(rgdal)
library(sp)

#2010 (Year 0 in simulation: actually 2020 in real life)
meanDens2010<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Year 2010 Simulation 1/mean_WOTH_Ontario.tif")
sdDens2010<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Year 2010 Simulation 1/sd_WOTH_Ontario.tif")

#2060 (Year 50 in simulation: actually 2070 in real life)
#There are 5 mean density and SD rasters from simulation runs 1 to 5
#for 2060 (simulation year 50).
#Uncertainty is due to both BRT sample uncertainty and due to
#simulation runs. So our mean predicted density is based on
#a mean of 5 means (1 per simulation run for each scenario in 2100)
#and our standard deviation is obtained as the square root of
#the sum of 5 standard deviations of 250 density predictions.

meanDens1<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Year 2060 Simulation 1/mean_WOTH_Ontario.tif")
meanDens2<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Year 2060 Simulation 2/mean_WOTH_Ontario.tif")
meanDens3<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Year 2060 Simulation 3/mean_WOTH_Ontario.tif")
meanDens4<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Year 2060 Simulation 4/mean_WOTH_Ontario.tif")
meanDens5<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Year 2060 Simulation 5/mean_WOTH_Ontario.tif")
#get the mean of means
meanDens2060<-(meanDens1+meanDens2+meanDens3+meanDens4+meanDens5)/5

sdDens1<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Year 2060 Simulation 1/sd_WOTH_Ontario.tif")
sdDens2<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Year 2060 Simulation 2/sd_WOTH_Ontario.tif")
sdDens3<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Year 2060 Simulation 3/sd_WOTH_Ontario.tif")
sdDens4<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Year 2060 Simulation 4/sd_WOTH_Ontario.tif")
sdDens5<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Year 2060 Simulation 5/sd_WOTH_Ontario.tif")
#get the overall SD
sdDens2060<-sqrt(sdDens1^2+sdDens2^2+sdDens3^2+sdDens4^2+sdDens5^2)

#clip each of these rasters to a smaller area that will be used
#in Zonation scenarios

BCR12<-readOGR("2_GIS outputs for ALCES Online/BCR12WOTHOntario/BCR12WOTHOntario","BCR12WOTHOntario")
BCR12.rp<-spTransform(BCR12, CRSobj="+proj=lcc +lat_0=0 +lon_0=-85 +lat_1=44.5 +lat_2=53.5 +x_0=930000 +y_0=6430000 +datum=NAD83 +units=m +no_defs")
#use as a mask

meanDens2010.crop <- crop(meanDens2010, BCR12.rp)
meanDens2010.masked<-mask(meanDens2010.crop, BCR12.rp)
meanDens2010.bcr12<-meanDens2010.masked
meanDens2010.bcr12[meanDens2010.masked>1]<-1

ncell(meanDens2010.bcr12)#19635588
ncell(meanDens2010.bcr12[!is.na(meanDens2010.bcr12)])#2734071
#Total area: 2734071*6.25 = 17,087,944 ha

#some density estimates are unusually high so adjust them to a threshold
#value more like observed maximum densities from individual studies. This
#threshold value can be changed (Actually not necessary for BCR 12 in 2020 
#since max density was already < 1)
plot(meanDens2010.bcr12)
plot(meanDens2010)
plot(meanDens2010.bcr12)
#works!
density_brt_2010_200m.bcr12<-meanDens2010.bcr12*4
popsize2010.bcr12<-cellStats(density_brt_2010_200m.bcr12, stat=sum, na.rm=T) 
#254841.5 THIS IS ESTIMATED POPULATION SIZE IN BCR 12
#Knowing this size relative to the regional population size
#in 2060 will be needed for estimating and mapping how
#much land to prioritize to maintain different percentages
#of this current population.
#writeRaster(density_brt_2010_200m.bcr12, filename="4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Zonation Inputs/meandens_2010.bcr12.tif", format="GTiff",overwrite=TRUE)

sdDens2010.crop<-crop(sdDens2010, BCR12.rp)
sdDens2010.bcr12<-mask(sdDens2010.crop, BCR12.rp)
#This layer represents the amount of uncertainty in the estimated
#density of Wood Thrush in each pixel. Pixels with high density and 
#low uncertainty (low standard deviation) are assigned higher 
#priority for conservation or management.
#writeRaster(sdDens2010.bcr12, filename="4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Zonation Inputs/SDdens_2010.bcr12.tif", format="GTiff",overwrite=TRUE)

#confidence interval estimates for population size
Dens2010.bcr12.95LCL<-meanDens2010.bcr12-1.96*sdDens2010.bcr12
density_brt_2010_200m.bcr12.95LCL<-Dens2010.bcr12.95LCL*4
popsize2010.bcr12.95LCL<-cellStats(density_brt_2010_200m.bcr12.95LCL, stat=sum, na.rm=T) 
#154666.1
Dens2010.bcr12.95UCL<-meanDens2010.bcr12+1.96*sdDens2010.bcr12
density_brt_2010_200m.bcr12.95UCL<-Dens2010.bcr12.95UCL*4
popsize2010.bcr12.95UCL<-cellStats(density_brt_2010_200m.bcr12.95UCL, stat=sum, na.rm=T) 
#355017

#2060
meanDens2060.crop<-crop(meanDens2060, BCR12.rp)
meanDens2060.masked<-mask(meanDens2060.crop, BCR12.rp)
meanDens2060.bcr12<-meanDens2060.masked
meanDens2060.bcr12[meanDens2060.masked>1]<-1
#some density estimates are unusually high so adjust them to a threshold
#value more like observed maximum densities from individual studies. This
#threshold value can be changed (Actually not necessary for BCR 12 in 2070 
#since max density was already < 1)
density_brt_2060_200m.bcr12<-meanDens2060.bcr12*4
popsize2060.bcr12<-cellStats(density_brt_2060_200m.bcr12, stat=sum, na.rm=T) 
#330543.1 (just simulation run 1)
#330945.5 (simulation runs 1 to 5)
#The population in Year 0 is 77.1 % (simulation run 1) or
#77.0 % (all 5 simulation runs) of what is expected in Year 50
#writeRaster(density_brt_2060_200m.bcr12, filename="4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Zonation Inputs/meandens_2060.bcr12.tif", format="GTiff",overwrite=TRUE)

sdDens2060.crop<-crop(sdDens2060, BCR12.rp)
sdDens2060.bcr12<-mask(sdDens2060.crop, BCR12.rp)
#writeRaster(sdDens2060.bcr12, filename="4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Zonation Inputs/SDdens_2060.bcr12.tif", format="GTiff",overwrite=TRUE)

#confidence interval estimates for population size
Dens2060.bcr12.95LCL<-meanDens2060.bcr12-1.96*sdDens2060.bcr12
density_brt_2060_200m.bcr12.95LCL<-Dens2060.bcr12.95LCL*4
popsize2060.bcr12.95LCL<-cellStats(density_brt_2060_200m.bcr12.95LCL, stat=sum, na.rm=T) 
#-123886.2
Dens2060.bcr12.95UCL<-meanDens2060.bcr12+1.96*sdDens2060.bcr12
density_brt_2060_200m.bcr12.95UCL<-Dens2060.bcr12.95UCL*4
popsize2060.bcr12.95UCL<-cellStats(density_brt_2060_200m.bcr12.95UCL, stat=sum, na.rm=T) 
#785777.2

#Extract the locations of known Wood Thrush occurrence within
#Bird Conservation Region 12, with the measured abundance at each location.
#These locations will increase the weight and prioritization
#of those locations for conservation or special management.

#Get WOTH point locations used in BRTs to create text file "SSI_WOTH_CH_BCR12"
WOTHcounts<-read.csv("0_data/raw/WOTH counts combined/WOTHcounts.studyregion.csv")
str(WOTHcounts)
#X=long, Y=lat, spp=Abundance. 
#We need coordinates in LCC (projection that the rasters are in)

library(sf)
lcc_crs <- "+proj=lcc +lat_0=0 +lon_0=-85 +lat_1=44.5 +lat_2=53.5 +x_0=930000 +y_0=6430000 +datum=NAD83 +units=m +no_defs"
WOTH.sf<-sf::st_as_sf(WOTHcounts, coords=c("X","Y"))
p1 <- st_set_crs(WOTH.sf, "+proj=longlat +datum=NAD83 +no_defs")
p1 <- st_transform(p1, lcc_crs)
st_write(p1, "4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Zonation Inputs/WOTHcounts_LCC.csv", layer_options = "GEOMETRY=AS_XY")

datcombo<-read.csv("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Zonation Inputs/WOTHcounts_LCC.csv", header=TRUE)
SSI_WOTH_CH<-datcombo[,c("X","Y","spp")]
str(SSI_WOTH_CH)#238954
SSI_WOTH_CH<-SSI_WOTH_CH[SSI_WOTH_CH$spp>0,]
str(SSI_WOTH_CH)#12358
#Now get rid of the points outside BCR 12 (reprojected)
extent(BCR12.rp)
#class      : Extent 
#xmin       : 221370.7 
#xmax       : 1657859 
#ymin       : 12012311 
#ymax       : 12559152   

#remove WOTH occurrences outside of ALCES Online Ontario BCR 12 extent
SSI_WOTH_CH_BCR12<-SSI_WOTH_CH[SSI_WOTH_CH$X>221371,]
SSI_WOTH_CH_BCR12<-SSI_WOTH_CH_BCR12[SSI_WOTH_CH_BCR12$X<1657859,]
SSI_WOTH_CH_BCR12<-SSI_WOTH_CH_BCR12[SSI_WOTH_CH_BCR12$Y>12012311,]
SSI_WOTH_CH_BCR12<-SSI_WOTH_CH_BCR12[SSI_WOTH_CH_BCR12$Y<12559152,]
write.csv(SSI_WOTH_CH_BCR12, file="4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Zonation Inputs/SSI_WOTH_CH_BCR12.csv")
#strip header from this file, add a fourth column of all zeros, then save as text file

#Once we have the necessary raster inputs, we set up a
#Zonation scenario outside of R and ran it. We then
#process some of the Zonation output inside R to generate
#plots the way we like.

########################################
#                                      #
#                                      #
#            CREATE NICE               #
#                DENSITY PLOTS         #
#                                      #
########################################

library(sp)
library(sf)
library(viridis)
library(lattice)
library(latticeExtra)
library(rasterVis)
library(raster)
library(tmap)
library(rgdal)
library(ggplot2)

lcc_crs<-"+proj=lcc +lat_0=0 +lon_0=-95 +lat_1=49 +lat_2=77 +x_0=0 +y_0=0 +datum=NAD83 +units=m +no_defs"
#the projection used in Landis outputs 

current.ontario.bcr12<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Zonation Inputs/meandens_2010.bcr12.tif")
current.ontario.bcr12<-current.ontario.bcr12/4#convert density from per 250-m pixel to per ha
current.ontario.bcr12.rp<-projectRaster(current.ontario.bcr12, crs=lcc_crs)

current.ontario.bcr13<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Zonation Inputs/meandens_2010.bcr13.tif")
current.ontario.bcr13<-current.ontario.bcr13/4#convert density from per 250-m pixel to per ha
current.ontario.bcr13.rp<-projectRaster(current.ontario.bcr13, crs=lcc_crs)


provs <-  readOGR("0_data_for_BRT_models/raw/BCR_Terrestrial_master/BCR_Terrestrial_master.shp")
#need to be reprojected in Lambert Conformal Conic used in Zonation and Landis-II rasters
provsproj<-spTransform(provs, CRSobj = lcc_crs)
provsprojNOTNA<-provsproj[!is.na(provsproj$COUNTRY),]

lakes<-provsproj[provsproj$BCRNAME=="GREAT LAKES",]
canada<-provsprojNOTNA[provsprojNOTNA$COUNTRY=="CANADA",]
usa<-provsprojNOTNA[provsprojNOTNA$COUNTRY=="USA",]
ontario<-canada[canada$PROVINCE_S=="ONTARIO",]
newbrunswick<-canada[canada$PROVINCE_S=="NEW BRUNSWICK",]
novascotia<-canada[canada$PROVINCE_S=="NOVA SCOTIA",]
quebec<-canada[canada$PROVINCE_S=="QUEBEC",]
pei<-canada[canada$PROVINCE_S=="PRINCE EDWARD ISLAND",]


#colour ramp for raster
bluegreen.colors2 <- colorRampPalette(c("#FFFACD", 
                                        "#FFF68F", 
                                        "#ADFF2F", 
                                        "greenyellow", 
                                        "#00CD00", 
                                        "green3", 
                                        "mediumturquoise", 
                                        "#007FFF", 
                                        "blue", 
                                        "purple", 
                                        "red"), space="Lab")

LBDG<-colorRampPalette(c("white","darkgreen"))


#setting my trellis themes
#these will remain this way until you change them back
mytheme <- theme_classic() +
  theme(text=element_text(size=12, family="Arial"),
        axis.text.x=element_text(size=12),
        axis.text.y=element_text(size=12),
        axis.title.x=element_text(margin=margin(10,0,0,0)),
        axis.title.y=element_text(margin=margin(0,10,0,0)),
        axis.line.x=element_line(linetype=1),
        axis.line.y=element_line(linetype=1))

mytheme$panel.border = element_rect(colour = "black", fill = NA)
mytheme$panel.border$col = "black"
mytheme$strip.background$alpha = 0
mytheme <- trellis.par.set(mytheme)

tiff("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Zonation Inputs/CurrentDensityFigure_OntarioBCR12.tiff", units="in", width=12, height=8, res=300)
rasterVis::levelplot(current.ontario.bcr12.rp,
                     margin=FALSE, # removes the histograms at the margins                    
                     colorkey=list(
                       space='bottom', # location for legend bar              
                       #height=0.5, width=0.5,
                       labels=list(at=seq(0,1,0.2), font=20, cex=2), # tick labels on legend
                       axis.line=list(col='black') # border of legend bar and ticks
                     ),    
                     par.settings=list(
                       axis.line=list(col='black') # bounding box line color
                     ),
                     scales=list(draw=F, cex=2), # removes coordinates on XY axes        
                     col.regions=LBDG) + # color scheme
  latticeExtra::layer(sp.lines(provsproj, col="black",lwd = 1.5))+  
  latticeExtra::layer(sp.polygons(quebec, fill="orange"))+  
  latticeExtra::layer(sp.polygons(newbrunswick, fill="yellow"))+  
  latticeExtra::layer(sp.polygons(lakes, fill="blue"))+  
  latticeExtra::layer(sp.polygons(usa, fill="lightgrey"))
dev.off()

tiff("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Zonation Inputs/CurrentDensityFigure_OntarioBCR13.tiff", units="in", width=12, height=8, res=300)
rasterVis::levelplot(current.ontario.bcr13.rp,
                     margin=FALSE, # removes the histograms at the margins                    
                     colorkey=list(
                       space='bottom', # location for legend bar              
                       #height=0.5, width=0.5,
                       labels=list(at=seq(0,1,0.2), font=20, cex=2), # tick labels on legend
                       axis.line=list(col='black') # border of legend bar and ticks
                     ),    
                     par.settings=list(
                       axis.line=list(col='black') # bounding box line color
                     ),
                     scales=list(draw=F, cex=2), # removes coordinates on XY axes        
                     col.regions=LBDG) + # color scheme
  latticeExtra::layer(sp.lines(provsproj, col="black",lwd = 1.5))+  
  latticeExtra::layer(sp.polygons(quebec, fill="orange"))+  
  latticeExtra::layer(sp.polygons(newbrunswick, fill="yellow"))+  
  latticeExtra::layer(sp.polygons(lakes, fill="blue"))+  
  latticeExtra::layer(sp.polygons(usa, fill="lightgrey"))
dev.off()
