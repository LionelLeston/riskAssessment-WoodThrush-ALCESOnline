library(data.table)
library(dismo)
library(dplyr)
library(ggplot2)
library(ggspatial)
library(raster)
library(rpart)
library(maptools)
library(rgdal)
theme_set(theme_bw())
library(sf)
lcc_crs <- "+proj=lcc +lat_1=49 +lat_2=77 +lat_0=0 +lon_0=-95 +x_0=0 +y_0=0 +datum=NAD83 +units=m +no_defs"

prov <- st_read("0_data/raw/Canada shapefile/gpr_000a11a_e/gpr_000a11a_e.shp")
str(prov)
WOTHarea<-prov[prov$PRENAME=="Quebec"|prov$PRENAME=="Ontario"|prov$PRENAME=="New Brunswick"|prov$PRENAME=="Nova Scotia"|prov$PRENAME=="Prince Edward Island",]
WOTHsf <- st_transform(WOTHarea, lcc_crs)
ggplot() + 
  geom_sf(data = WOTHsf, size = 0.5, color = "black", fill = "white") + 
  ggtitle("Wood Thrush study area") + 
  coord_sf()

#need to dissolve provincial boundaries before using 
#Wood Thrush study area as a shape-file filter for
#clipping other shape-files
WOTHsf$area<-st_area(WOTHsf)
WOTHsf.D <-
  WOTHsf %>%
  summarise(area = sum(area))

#Insect outbreak data: might worsen or improve habitat for Wood Thrush by
#altering vegetation
#or might serve as temporary food source
FRI.insects <- st_read("0_data/raw/Ontario FRI/Forest_Insect_Damage_Event-shp/Forest_Insect_Damage_Event.shp")

FRI.insects.sf <- sf::st_as_sf(FRI.insects)
sf1 <- st_set_crs(FRI.insects.sf, "+proj=longlat +datum=NAD83 +no_defs")
sf1 <- st_transform(sf1, lcc_crs)

ggplot() + 
  geom_sf(data = sf1, size = 0.5, color = "blue", fill = "cyan1") + 
  ggtitle("Insect Damage Map") + 
  coord_sf()
levels(as.factor(sf1$FOREST_INS))#insect type
levels(as.factor(sf1$FOREST_DAM))#severity

sf1$FOREST_DAM.n<-ifelse(sf1$FOREST_DAM=="Light",1,
                         ifelse(sf1$FOREST_DAM=="Light-Moderate",2,
                                ifelse(sf1$FOREST_DAM=="Moderate",3,
                                       ifelse(sf1$FOREST_DAM=="Moderate-Severe",4,5))))
sf1$FOREST_DAM.n<-as.numeric(sf1$FOREST_DAM.n)
#Now create rasters for each variable of interest in the shape-file
library(fasterize)
#use Wood Thrush study area raster as a template
wothstudyareamask<-raster("0_data/raw/Canada shapefile/wothstudyareamask.tif")

#severity of insect damage
r.insects.severity<-fasterize(
  sf1,
  wothstudyareamask,
  field = "FOREST_DAM.n",
  fun="max",
  background = NA_real_,
  by = NULL
)
plot(r.insects.severity)
writeRaster(r.insects.severity, filename="0_data/raw/Ontario FRI/raster layers I made/InsectDamageSeverity.Ontario.tif", overwrite=TRUE)
#saves severity values for insect damage events at 250-m resolution within study area


#year of insect damage
r.insects.year<-fasterize(
  sf1,
  wothstudyareamask,
  field = "YEAR_OF_EV",
  fun="max",
  background = NA_real_,
  by = NULL
)
plot(r.insects.year)
writeRaster(r.insects.year, filename="0_data/raw/Ontario FRI/raster layers I made/InsectDamageYear.Ontario.tif", overwrite=TRUE)
#saves year values for insect damage events at 250-m resolution within study area

sf1$GypsyMoth<-ifelse(sf1$FOREST_INS=="Gypsy Moth",1,0)
r.GypsyMoth<-fasterize(
  sf1,
  wothstudyareamask,
  field = "GypsyMoth",
  fun="max",
  background = NA_real_,
  by = NULL
)
plot(r.GypsyMoth)
writeRaster(r.GypsyMoth, filename="0_data/raw/Ontario FRI/raster layers I made/GypsyMoth.Ontario.tif", overwrite=TRUE)
#saves presence of Gypsy Moth events at 250-m resolution within study area

sf1$SpruceBudworm<-ifelse(sf1$FOREST_INS=="Spruce Budworm",1,0)
r.SpruceBudworm<-fasterize(
  sf1,
  wothstudyareamask,
  field = "SpruceBudworm",
  fun="max",
  background = NA_real_,
  by = NULL
)
plot(r.SpruceBudworm)
writeRaster(r.SpruceBudworm, filename="0_data/raw/Ontario FRI/raster layers I made/SpruceBudworm.Ontario.tif", overwrite=TRUE)
#saves presence of Spruce Budworm events at 250-m resolution within study area

sf1$ForestTentCaterpillar<-ifelse(sf1$FOREST_INS=="Forest Tent Caterpillar",1,0)
r.ForestTentCaterpillar<-fasterize(
  sf1,
  wothstudyareamask,
  field = "ForestTentCaterpillar",
  fun="max",
  background = NA_real_,
  by = NULL
)
plot(r.ForestTentCaterpillar)
writeRaster(r.ForestTentCaterpillar, filename="0_data/raw/Ontario FRI/raster layers I made/ForestTentCaterpillar.Ontario.tif", overwrite=TRUE)
#saves presence of Forest Tent Caterpillar events at 250-m resolution within study area


#Abiotic disturbances
FRI.abiotic <- st_read("0_data/raw/Ontario FRI/Forest_Abiotic_Damage_Event-shp/Forest_Abiotic_Damage_Event.shp")

FRI.abiotic.sf <- sf::st_as_sf(FRI.abiotic)
sf2 <- st_set_crs(FRI.abiotic.sf, "+proj=longlat +datum=NAD83 +no_defs")
sf2 <- st_transform(sf2, lcc_crs)

ggplot() + 
  geom_sf(data = sf2, size = 0.5, color = "blue", fill = "cyan1") + 
  ggtitle("Abiotic Damage Map") + 
  coord_sf()
levels(as.factor(sf2$ABIOTIC_EV))#disturbance type
levels(as.factor(sf2$FOREST_DAM))#severity


sf2$FOREST_DAM.n<-ifelse(sf2$FOREST_DAM=="Light",1,
                         ifelse(sf2$FOREST_DAM=="Light-Moderate",2,
                                ifelse(sf2$FOREST_DAM=="Moderate",3,
                                       ifelse(sf2$FOREST_DAM=="Moderate-Severe",4,5))))
sf2$FOREST_DAM.n<-as.numeric(sf2$FOREST_DAM.n)

#Now create rasters for each variable of interest in the shape-file
#severity of abiotic damage
r.abiotic.severity<-fasterize(
  sf2,
  wothstudyareamask,
  field = "FOREST_DAM.n",
  fun="max",
  background = NA_real_,
  by = NULL
)
plot(r.abiotic.severity)
writeRaster(r.abiotic.severity, filename="0_data/raw/Ontario FRI/raster layers I made/AbioticDamageSeverity.Ontario.tif", overwrite=TRUE)
#saves severity values for abiotic damage events at 250-m resolution within study area

#year of abiotic damage
r.abiotic.year<-fasterize(
  sf2,
  wothstudyareamask,
  field = "YEAR_OF_EV",
  fun="max",
  background = NA_real_,
  by = NULL
)
plot(r.abiotic.year)
writeRaster(r.abiotic.year, filename="0_data/raw/Ontario FRI/raster layers I made/AbioticDamageYear.Ontario.tif", overwrite=TRUE)
#saves year values for abiotic damage events at 250-m resolution within study area

sf2$WindEvent<-ifelse(sf2$ABIOTIC_EV=="Blowdown",1,
                      ifelse(sf2$ABIOTIC_EV=="Windstorm",1,0))
r.WindEvent<-fasterize(
  sf2,
  wothstudyareamask,
  field = "WindEvent",
  fun="max",
  background = NA_real_,
  by = NULL
)
plot(r.WindEvent)
writeRaster(r.WindEvent, filename="0_data/raw/Ontario FRI/raster layers I made/WindEvent.Ontario.tif", overwrite=TRUE)
#saves presence of wind events at 250-m resolution within study area
