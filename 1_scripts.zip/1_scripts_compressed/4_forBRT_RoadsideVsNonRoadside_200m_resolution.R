Anyroad<-read.csv("0_data_for_BRT_models/raw/CanVec roads/PointDistanceToNearestAnyRoad.csv", header=TRUE)
Anyroad$Roadside150<-as.factor(Anyroad$Roadside150)
mytable.pc<-table(Anyroad[,c("PCODE","Roadside150")])   
df.pc<-data.frame(mytable.pc)
write.csv(df.pc, file="0_data_for_BRT_models/processed/roadside/Table.PointCountsXAnyRoadWithin150.csv")

Highway<-read.csv("0_data_for_BRT_models/raw/CanVec roads/PointDistanceToNearestMajorRoad.csv", header=TRUE)
Highway$MajorRoad150<-as.factor(Highway$MajorRoad150)
mytable.pc<-table(Highway[,c("PCODE","MajorRoad150")])   
df.pc<-data.frame(mytable.pc)
write.csv(df.pc, file="0_data_for_BRT_models/processed/roadside/Table.PointCountsXHighwayOrMajorRoadWithin150.csv")

#I have classified roads from the CanVec layers (1:50000) 
#for Ontario, Quebec, New Brunswick and Nova Scotia as 
#major (highway, freeway, ramp, rapid transit road, arterial 
#road, expressway) or not and estimated point count distances 
#to any road and to the nearest major road.

#Summaries of the number of point counts from different studies 
#are attached, assigned as either roadside (<150 m from any road) 
#or offroad (>150 m from any road) and as near a major road
#(<150 m) or not.

#Most BBS points in the provinces were correctly classified as roadside 
#(see tables below). Seventy percent of Forest Bird Monitoring 
#Program point counts were classified correctly as offroad. 
#Five percent of FBMP points were incorrectly classified as within 
#150 m of a major road. The few offroad BBS points might have been 
#along forestry roads missed in the CanVec layer. The roadside 
#FBMP points are from 2017 and before, so roads might have been put 
#in near their locations in years following the point counts. About 85 % 
#of points are within 150 m of one road. Assuming I change all FBMP points 
#to offroad and offroad BBS points to roadside, the % roadside will change 
#little.

#Just over a quarter of point counts are classified as near a major road. 