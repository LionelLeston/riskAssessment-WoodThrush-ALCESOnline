memory.limit(size=200000)
library(raster)
library(dismo)
library(rpart)
library(maptools)
library(data.table)
library(rgdal)
library(dplyr)
library(ggplot2)
library(spatial)
library(rasterVis)
library(RColorBrewer)

#Ag Canada annual cover layers for individual provinces in 2011, 2015, 2019: 30-
#Landsat rasters that can be processed individually, then used to extract cover
#data later on to point counts in a given survey year. 

#Due to the size of all of the files required or created in Steps 1 to 3,
#only the land cover rasters that need to be resampled to 200 m for the 
#ALCES Online models are stored here, in the "landscape rasters" sub-folder.

#The original raw data and "binary rasters" that were used to create the 
#"landscape rasters" are available in the "CHID-Regionalmodel / BRTmodel-RProj"
#R Project folder. To resample the landscape rasters to 200 m resolution,
#go to Step 4.

####################################################################
#                                                                  #
#                                                                  #
#                                                                  #
#                   STEP ONE - MAKE BINARY RASTERS                 #
#                                                                  #
#                                                                  #
#                                                                  #
####################################################################

#First, individual layers must be used to create binary habitat layers.
#Then those binary layers can be summarized at larger spatial scales equivalent
#to a point count area or local scale (150 m), or landscape scales appropriate
#for Wood Thrush (e.g. 1, 2 km)

#The binary rasters for Ontario were created separately in ArcGIS due to their size
#They are at 30-m resolution and occupy a lot of space.

#read in raster

#Nova Scotia 2011
ns2011<-raster("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/aci_2011_ns/aci_2011_ns.tif")
#create binary habitat rasters
water<-ns2011
values(water) = ifelse(values(water)==20,1,0)
plot(water)
writeRaster(water, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/ns2011_water.tif", overwrite=TRUE)
rm(water)

barren<-ns2011
values(barren) = ifelse(values(barren)==30,1,0)
plot(barren)
writeRaster(barren, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/ns2011_barren.tif", overwrite=TRUE)
rm(barren)

urban<-ns2011
values(urban) = ifelse(values(urban)==34,1,0)
plot(urban)
writeRaster(urban, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/ns2011_urban.tif", overwrite=TRUE)
rm(urban)

shrub<-ns2011
values(shrub) = ifelse(values(shrub)==50,1,0)
plot(shrub)
writeRaster(shrub, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/ns2011_shrub.tif", overwrite=TRUE)
rm(shrub)

wetland<-ns2011
values(wetland) = ifelse(values(wetland)==80,1,0)
plot(wetland)
writeRaster(wetland, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/ns2011_wetland.tif", overwrite=TRUE)
rm(wetland)

grassland<-ns2011
values(grassland) = ifelse(values(grassland)==110,1,0)
plot(grassland)
writeRaster(grassland, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/ns2011_grassland.tif", overwrite=TRUE)
rm(grassland)

cult<-ns2011
values(cult) = ifelse((values(cult)>119)&(values(cult)<200),1,0)
plot(cult)
writeRaster(cult, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/ns2011_cult.tif", overwrite=TRUE)
rm(cult)

orchard<-ns2011
values(orchard) = ifelse(values(orchard)==188,1,0)
plot(orchard)
writeRaster(orchard, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/ns2011_orchard.tif", overwrite=TRUE)
rm(orchard)

forestundiff<-ns2011
values(forestundiff) = ifelse(values(forestundiff)==200,1,0)
plot(forestundiff)
writeRaster(forestundiff, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/ns2011_forestundiff.tif", overwrite=TRUE)
rm(forestundiff)

conif<-ns2011
values(conif) = ifelse(values(conif)==210,1,0)
plot(conif)
writeRaster(conif, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/ns2011_conif.tif", overwrite=TRUE)
rm(conif)

decid<-ns2011
values(decid) = ifelse(values(decid)==220,1,0)
plot(decid)
writeRaster(decid, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/ns2011_decid.tif", overwrite=TRUE)
rm(decid)

mixed<-ns2011
values(mixed) = ifelse(values(mixed)==230,1,0)
plot(mixed)
writeRaster(mixed, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/ns2011_mixed.tif", overwrite=TRUE)
rm(mixed)

gc()

#Nova Scotia 2015
ns2015<-raster("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/aci_2015_ns/aci_2015_ns.tif")
#create binary habitat rasters
water<-ns2015
values(water) = ifelse(values(water)==20,1,0)
plot(water)
writeRaster(water, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/ns2015_water.tif", overwrite=TRUE)
rm(water)

barren<-ns2015
values(barren) = ifelse(values(barren)==30,1,0)
plot(barren)
writeRaster(barren, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/ns2015_barren.tif", overwrite=TRUE)
rm(barren)

urban<-ns2015
values(urban) = ifelse(values(urban)==34,1,0)
plot(urban)
writeRaster(urban, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/ns2015_urban.tif", overwrite=TRUE)
rm(urban)

shrub<-ns2015
values(shrub) = ifelse(values(shrub)==50,1,0)
plot(shrub)
writeRaster(shrub, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/ns2015_shrub.tif", overwrite=TRUE)
rm(shrub)

wetland<-ns2015
values(wetland) = ifelse(values(wetland)==80,1,0)
plot(wetland)
writeRaster(wetland, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/ns2015_wetland.tif", overwrite=TRUE)
rm(wetland)

grassland<-ns2015
values(grassland) = ifelse(values(grassland)==110,1,0)
plot(grassland)
writeRaster(grassland, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/ns2015_grassland.tif", overwrite=TRUE)
rm(grassland)

cult<-ns2015
values(cult) = ifelse((values(cult)>119)&(values(cult)<200),1,0)
plot(cult)
writeRaster(cult, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/ns2015_cult.tif", overwrite=TRUE)
rm(cult)

orchard<-ns2015
values(orchard) = ifelse(values(orchard)==188,1,0)
plot(orchard)
writeRaster(orchard, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/ns2015_orchard.tif", overwrite=TRUE)
rm(orchard)

forestundiff<-ns2015
values(forestundiff) = ifelse(values(forestundiff)==200,1,0)
plot(forestundiff)
writeRaster(forestundiff, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/ns2015_forestundiff.tif", overwrite=TRUE)
rm(forestundiff)

conif<-ns2015
values(conif) = ifelse(values(conif)==210,1,0)
plot(conif)
writeRaster(conif, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/ns2015_conif.tif", overwrite=TRUE)
rm(conif)

decid<-ns2015
values(decid) = ifelse(values(decid)==220,1,0)
plot(decid)
writeRaster(decid, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/ns2015_decid.tif", overwrite=TRUE)
rm(decid)

mixed<-ns2015
values(mixed) = ifelse(values(mixed)==230,1,0)
plot(mixed)
writeRaster(mixed, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/ns2015_mixed.tif", overwrite=TRUE)
rm(mixed)


#Nova Scotia 2020
ns2020<-raster("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/aci_2020_ns_v1/aci_2020_ns.tif")
#create binary habitat rasters
water<-ns2020
values(water) = ifelse(values(water)==20,1,0)
plot(water)
writeRaster(water, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/ns2020_water.tif", overwrite=TRUE)
rm(water)

barren<-ns2020
values(barren) = ifelse(values(barren)==30,1,0)
plot(barren)
writeRaster(barren, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/ns2020_barren.tif", overwrite=TRUE)
rm(barren)

urban<-ns2020
values(urban) = ifelse(values(urban)==34,1,0)
plot(urban)
writeRaster(urban, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/ns2020_urban.tif", overwrite=TRUE)
rm(urban)

shrub<-ns2020
values(shrub) = ifelse(values(shrub)==50,1,0)
plot(shrub)
writeRaster(shrub, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/ns2020_shrub.tif", overwrite=TRUE)
rm(shrub)

wetland<-ns2020
values(wetland) = ifelse(values(wetland)==80,1,0)
plot(wetland)
writeRaster(wetland, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/ns2020_wetland.tif", overwrite=TRUE)
rm(wetland)

grassland<-ns2020
values(grassland) = ifelse(values(grassland)==110,1,0)
plot(grassland)
writeRaster(grassland, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/ns2020_grassland.tif", overwrite=TRUE)
rm(grassland)

cult<-ns2020
values(cult) = ifelse((values(cult)>119)&(values(cult)<200),1,0)
plot(cult)
writeRaster(cult, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/ns2020_cult.tif", overwrite=TRUE)
rm(cult)

orchard<-ns2020
values(orchard) = ifelse(values(orchard)==188,1,0)
plot(orchard)
writeRaster(orchard, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/ns2020_orchard.tif", overwrite=TRUE)
rm(orchard)

forestundiff<-ns2020
values(forestundiff) = ifelse(values(forestundiff)==200,1,0)
plot(forestundiff)
writeRaster(forestundiff, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/ns2020_forestundiff.tif", overwrite=TRUE)
rm(forestundiff)

conif<-ns2020
values(conif) = ifelse(values(conif)==210,1,0)
plot(conif)
writeRaster(conif, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/ns2020_conif.tif", overwrite=TRUE)
rm(conif)

decid<-ns2020
values(decid) = ifelse(values(decid)==220,1,0)
plot(decid)
writeRaster(decid, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/ns2020_decid.tif", overwrite=TRUE)
rm(decid)

mixed<-ns2020
values(mixed) = ifelse(values(mixed)==230,1,0)
plot(mixed)
writeRaster(mixed, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/ns2020_mixed.tif", overwrite=TRUE)
rm(mixed)
gc()

#New Brunswick 2011
nb2011<-raster("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/aci_2011_nb/aci_2011_nb.tif")
#create binary habitat rasters
water<-nb2011
values(water) = ifelse(values(water)==20,1,0)
plot(water)
writeRaster(water, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/nb2011_water.tif", overwrite=TRUE)
rm(water)

barren<-nb2011
values(barren) = ifelse(values(barren)==30,1,0)
plot(barren)
writeRaster(barren, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/nb2011_barren.tif", overwrite=TRUE)
rm(barren)

urban<-nb2011
values(urban) = ifelse(values(urban)==34,1,0)
plot(urban)
writeRaster(urban, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/nb2011_urban.tif", overwrite=TRUE)
rm(urban)

shrub<-nb2011
values(shrub) = ifelse(values(shrub)==50,1,0)
plot(shrub)
writeRaster(shrub, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/nb2011_shrub.tif", overwrite=TRUE)
rm(shrub)

wetland<-nb2011
values(wetland) = ifelse(values(wetland)==80,1,0)
plot(wetland)
writeRaster(wetland, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/nb2011_wetland.tif", overwrite=TRUE)
rm(wetland)

grassland<-nb2011
values(grassland) = ifelse(values(grassland)==110,1,0)
plot(grassland)
writeRaster(grassland, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/nb2011_grassland.tif", overwrite=TRUE)
rm(grassland)

cult<-nb2011
values(cult) = ifelse((values(cult)>119)&(values(cult)<200),1,0)
plot(cult)
writeRaster(cult, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/nb2011_cult.tif", overwrite=TRUE)
rm(cult)

orchard<-nb2011
values(orchard) = ifelse(values(orchard)==188,1,0)
plot(orchard)
writeRaster(orchard, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/nb2011_orchard.tif", overwrite=TRUE)
rm(orchard)

forestundiff<-nb2011
values(forestundiff) = ifelse(values(forestundiff)==200,1,0)
plot(forestundiff)
writeRaster(forestundiff, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/nb2011_forestundiff.tif", overwrite=TRUE)
rm(forestundiff)

conif<-nb2011
values(conif) = ifelse(values(conif)==210,1,0)
plot(conif)
writeRaster(conif, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/nb2011_conif.tif", overwrite=TRUE)
rm(conif)

decid<-nb2011
values(decid) = ifelse(values(decid)==220,1,0)
plot(decid)
writeRaster(decid, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/nb2011_decid.tif", overwrite=TRUE)
rm(decid)

mixed<-nb2011
values(mixed) = ifelse(values(mixed)==230,1,0)
plot(mixed)
writeRaster(mixed, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/nb2011_mixed.tif", overwrite=TRUE)
rm(mixed)

gc()

#New Brunswick 2015
nb2015<-raster("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/aci_2015_nb/aci_2015_nb.tif")
#create binary habitat rasters
water<-nb2015
values(water) = ifelse(values(water)==20,1,0)
plot(water)
writeRaster(water, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/nb2015_water.tif", overwrite=TRUE)
rm(water)

barren<-nb2015
values(barren) = ifelse(values(barren)==30,1,0)
plot(barren)
writeRaster(barren, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/nb2015_barren.tif", overwrite=TRUE)
rm(barren)

urban<-nb2015
values(urban) = ifelse(values(urban)==34,1,0)
plot(urban)
writeRaster(urban, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/nb2015_urban.tif", overwrite=TRUE)
rm(urban)

shrub<-nb2015
values(shrub) = ifelse(values(shrub)==50,1,0)
plot(shrub)
writeRaster(shrub, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/nb2015_shrub.tif", overwrite=TRUE)
rm(shrub)

wetland<-nb2015
values(wetland) = ifelse(values(wetland)==80,1,0)
plot(wetland)
writeRaster(wetland, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/nb2015_wetland.tif", overwrite=TRUE)
rm(wetland)

grassland<-nb2015
values(grassland) = ifelse(values(grassland)==110,1,0)
plot(grassland)
writeRaster(grassland, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/nb2015_grassland.tif", overwrite=TRUE)
rm(grassland)

cult<-nb2015
values(cult) = ifelse((values(cult)>119)&(values(cult)<200),1,0)
plot(cult)
writeRaster(cult, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/nb2015_cult.tif", overwrite=TRUE)
rm(cult)

orchard<-nb2015
values(orchard) = ifelse(values(orchard)==188,1,0)
plot(orchard)
writeRaster(orchard, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/nb2015_orchard.tif", overwrite=TRUE)
rm(orchard)

forestundiff<-nb2015
values(forestundiff) = ifelse(values(forestundiff)==200,1,0)
plot(forestundiff)
writeRaster(forestundiff, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/nb2015_forestundiff.tif", overwrite=TRUE)
rm(forestundiff)

conif<-nb2015
values(conif) = ifelse(values(conif)==210,1,0)
plot(conif)
writeRaster(conif, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/nb2015_conif.tif", overwrite=TRUE)
rm(conif)

decid<-nb2015
values(decid) = ifelse(values(decid)==220,1,0)
plot(decid)
writeRaster(decid, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/nb2015_decid.tif", overwrite=TRUE)
rm(decid)

mixed<-nb2015
values(mixed) = ifelse(values(mixed)==230,1,0)
plot(mixed)
writeRaster(mixed, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/nb2015_mixed.tif", overwrite=TRUE)
rm(mixed)

#New Brunswick 2020
nb2020<-raster("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/aci_2020_ns_v1/aci_2020_ns.tif")
#create binary habitat rasters
water<-nb2020
values(water) = ifelse(values(water)==20,1,0)
plot(water)
writeRaster(water, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/nb2020_water.tif", overwrite=TRUE)
rm(water)

barren<-nb2020
values(barren) = ifelse(values(barren)==30,1,0)
plot(barren)
writeRaster(barren, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/nb2020_barren.tif", overwrite=TRUE)
rm(barren)

urban<-nb2020
values(urban) = ifelse(values(urban)==34,1,0)
plot(urban)
writeRaster(urban, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/nb2020_urban.tif", overwrite=TRUE)
rm(urban)

shrub<-nb2020
values(shrub) = ifelse(values(shrub)==50,1,0)
plot(shrub)
writeRaster(shrub, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/nb2020_shrub.tif", overwrite=TRUE)
rm(shrub)

wetland<-nb2020
values(wetland) = ifelse(values(wetland)==80,1,0)
plot(wetland)
writeRaster(wetland, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/nb2020_wetland.tif", overwrite=TRUE)
rm(wetland)

grassland<-nb2020
values(grassland) = ifelse(values(grassland)==110,1,0)
plot(grassland)
writeRaster(grassland, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/nb2020_grassland.tif", overwrite=TRUE)
rm(grassland)

cult<-nb2020
values(cult) = ifelse((values(cult)>119)&(values(cult)<200),1,0)
plot(cult)
writeRaster(cult, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/nb2020_cult.tif", overwrite=TRUE)
rm(cult)

orchard<-nb2020
values(orchard) = ifelse(values(orchard)==188,1,0)
plot(orchard)
writeRaster(orchard, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/nb2020_orchard.tif", overwrite=TRUE)
rm(orchard)

forestundiff<-nb2020
values(forestundiff) = ifelse(values(forestundiff)==200,1,0)
plot(forestundiff)
writeRaster(forestundiff, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/nb2020_forestundiff.tif", overwrite=TRUE)
rm(forestundiff)

conif<-nb2020
values(conif) = ifelse(values(conif)==210,1,0)
plot(conif)
writeRaster(conif, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/nb2020_conif.tif", overwrite=TRUE)
rm(conif)

decid<-nb2020
values(decid) = ifelse(values(decid)==220,1,0)
plot(decid)
writeRaster(decid, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/nb2020_decid.tif", overwrite=TRUE)
rm(decid)

mixed<-nb2020
values(mixed) = ifelse(values(mixed)==230,1,0)
plot(mixed)
writeRaster(mixed, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/nb2020_mixed.tif", overwrite=TRUE)
rm(mixed)
gc()

#Quebec 2011
qc2011<-raster("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/aci_2011_qc/aci_2011_qc.tif")
#create binary habitat rasters
water<-qc2011
values(water) = ifelse(values(water)==20,1,0)
plot(water)
writeRaster(water, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/qc2011_water.tif", overwrite=TRUE)
rm(water)

barren<-qc2011
values(barren) = ifelse(values(barren)==30,1,0)
plot(barren)
writeRaster(barren, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/qc2011_barren.tif", overwrite=TRUE)
rm(barren)

urban<-qc2011
values(urban) = ifelse(values(urban)==34,1,0)
plot(urban)
writeRaster(urban, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/qc2011_urban.tif", overwrite=TRUE)
rm(urban)

shrub<-qc2011
values(shrub) = ifelse(values(shrub)==50,1,0)
plot(shrub)
writeRaster(shrub, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/qc2011_shrub.tif", overwrite=TRUE)
rm(shrub)

wetland<-qc2011
values(wetland) = ifelse(values(wetland)==80,1,0)
plot(wetland)
writeRaster(wetland, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/qc2011_wetland.tif", overwrite=TRUE)
rm(wetland)

grassland<-qc2011
values(grassland) = ifelse(values(grassland)==110,1,0)
plot(grassland)
writeRaster(grassland, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/qc2011_grassland.tif", overwrite=TRUE)
rm(grassland)

cult<-qc2011
values(cult) = ifelse((values(cult)>119)&(values(cult)<200),1,0)
plot(cult)
writeRaster(cult, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/qc2011_cult.tif", overwrite=TRUE)
rm(cult)

orchard<-qc2011
values(orchard) = ifelse(values(orchard)==188,1,0)
plot(orchard)
writeRaster(orchard, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/qc2011_orchard.tif", overwrite=TRUE)
rm(orchard)

forestundiff<-qc2011
values(forestundiff) = ifelse(values(forestundiff)==200,1,0)
plot(forestundiff)
writeRaster(forestundiff, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/qc2011_forestundiff.tif", overwrite=TRUE)
rm(forestundiff)

conif<-qc2011
values(conif) = ifelse(values(conif)==210,1,0)
plot(conif)
writeRaster(conif, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/qc2011_conif.tif", overwrite=TRUE)
rm(conif)

decid<-qc2011
values(decid) = ifelse(values(decid)==220,1,0)
plot(decid)
writeRaster(decid, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/qc2011_decid.tif", overwrite=TRUE)
rm(decid)

mixed<-qc2011
values(mixed) = ifelse(values(mixed)==230,1,0)
plot(mixed)
writeRaster(mixed, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/qc2011_mixed.tif", overwrite=TRUE)
rm(mixed)

gc()

#Quebec 2015
qc2015<-raster("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/aci_2015_qc/aci_2015_qc.tif")
#create binary habitat rasters
water<-qc2015
values(water) = ifelse(values(water)==20,1,0)
plot(water)
writeRaster(water, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/qc2015_water.tif", overwrite=TRUE)
rm(water)

barren<-qc2015
values(barren) = ifelse(values(barren)==30,1,0)
plot(barren)
writeRaster(barren, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/qc2015_barren.tif", overwrite=TRUE)
rm(barren)

urban<-qc2015
values(urban) = ifelse(values(urban)==34,1,0)
plot(urban)
writeRaster(urban, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/qc2015_urban.tif", overwrite=TRUE)
rm(urban)

shrub<-qc2015
values(shrub) = ifelse(values(shrub)==50,1,0)
plot(shrub)
writeRaster(shrub, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/qc2015_shrub.tif", overwrite=TRUE)
rm(shrub)

wetland<-qc2015
values(wetland) = ifelse(values(wetland)==80,1,0)
plot(wetland)
writeRaster(wetland, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/qc2015_wetland.tif", overwrite=TRUE)
rm(wetland)

grassland<-qc2015
values(grassland) = ifelse(values(grassland)==110,1,0)
plot(grassland)
writeRaster(grassland, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/qc2015_grassland.tif", overwrite=TRUE)
rm(grassland)

cult<-qc2015
values(cult) = ifelse((values(cult)>119)&(values(cult)<200),1,0)
plot(cult)
writeRaster(cult, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/qc2015_cult.tif", overwrite=TRUE)
rm(cult)

orchard<-qc2015
values(orchard) = ifelse(values(orchard)==188,1,0)
plot(orchard)
writeRaster(orchard, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/qc2015_orchard.tif", overwrite=TRUE)
rm(orchard)

forestundiff<-qc2015
values(forestundiff) = ifelse(values(forestundiff)==200,1,0)
plot(forestundiff)
writeRaster(forestundiff, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/qc2015_forestundiff.tif", overwrite=TRUE)
rm(forestundiff)

conif<-qc2015
values(conif) = ifelse(values(conif)==210,1,0)
plot(conif)
writeRaster(conif, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/qc2015_conif.tif", overwrite=TRUE)
rm(conif)

decid<-qc2015
values(decid) = ifelse(values(decid)==220,1,0)
plot(decid)
writeRaster(decid, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/qc2015_decid.tif", overwrite=TRUE)
rm(decid)

mixed<-qc2015
values(mixed) = ifelse(values(mixed)==230,1,0)
plot(mixed)
writeRaster(mixed, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/qc2015_mixed.tif", overwrite=TRUE)
rm(mixed)

#Quebec 2020
qc2020<-raster("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/aci_2020_qc_v1/aci_2020_qc.tif")
#create binary habitat rasters
water<-qc2020
values(water) = ifelse(values(water)==20,1,0)
plot(water)
writeRaster(water, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/qc2020_water.tif", overwrite=TRUE)
rm(water)

barren<-qc2020
values(barren) = ifelse(values(barren)==30,1,0)
plot(barren)
writeRaster(barren, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/qc2020_barren.tif", overwrite=TRUE)
rm(barren)

urban<-qc2020
values(urban) = ifelse(values(urban)==34,1,0)
plot(urban)
writeRaster(urban, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/qc2020_urban.tif", overwrite=TRUE)
rm(urban)

shrub<-qc2020
values(shrub) = ifelse(values(shrub)==50,1,0)
plot(shrub)
writeRaster(shrub, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/qc2020_shrub.tif", overwrite=TRUE)
rm(shrub)

wetland<-qc2020
values(wetland) = ifelse(values(wetland)==80,1,0)
plot(wetland)
writeRaster(wetland, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/qc2020_wetland.tif", overwrite=TRUE)
rm(wetland)

grassland<-qc2020
values(grassland) = ifelse(values(grassland)==110,1,0)
plot(grassland)
writeRaster(grassland, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/qc2020_grassland.tif", overwrite=TRUE)
rm(grassland)

cult<-qc2020
values(cult) = ifelse((values(cult)>119)&(values(cult)<200),1,0)
plot(cult)
writeRaster(cult, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/qc2020_cult.tif", overwrite=TRUE)
rm(cult)

orchard<-qc2020
values(orchard) = ifelse(values(orchard)==188,1,0)
plot(orchard)
writeRaster(orchard, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/qc2020_orchard.tif", overwrite=TRUE)
rm(orchard)

forestundiff<-qc2020
values(forestundiff) = ifelse(values(forestundiff)==200,1,0)
plot(forestundiff)
writeRaster(forestundiff, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/qc2020_forestundiff.tif", overwrite=TRUE)
rm(forestundiff)

conif<-qc2020
values(conif) = ifelse(values(conif)==210,1,0)
plot(conif)
writeRaster(conif, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/qc2020_conif.tif", overwrite=TRUE)
rm(conif)

decid<-qc2020
values(decid) = ifelse(values(decid)==220,1,0)
plot(decid)
writeRaster(decid, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/qc2020_decid.tif", overwrite=TRUE)
rm(decid)

mixed<-qc2020
values(mixed) = ifelse(values(mixed)==230,1,0)
plot(mixed)
writeRaster(mixed, filename="0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/qc2020_mixed.tif", overwrite=TRUE)
rm(mixed)
gc()


####################################################################
#                                                                  #
#                                                                  #
#                                                                  #
#                   STEP TWO - GET PROPORTION OF LAND COVER        #
#                              TYPES WITHIN ~ 150 M                #
#                                                                  #
#                                                                  #
#                                                                  #
####################################################################


#Once binary rasters are made, extract % cover by each cover class
#at different spatial scales using a Gaussian filter. The new raster
#layers will have values between 0 and 1 rather than exactly 0 or 1.
#The rasters will be at 30-m resolution and take up a lot of memory.

#New Brunswick 2011 layers
rs2011<-c("nb2011_barren.tif","nb2011_conif.tif","nb2011_cult.tif","nb2011_decid.tif","nb2011_forestundiff.tif","nb2011_grassland.tif",
          "nb2011_mixed.tif","nb2011_orchard.tif","nb2011_shrub.tif","nb2011_urban.tif","nb2011_water.tif","nb2011_wetland.tif")
for (i in 1:length(rs2011)) { 
  nb2011 <- raster(paste0("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/",rs2011[i]))
  ## sigma = 150m
  fw150<-focalWeight(x=nb2011,d=150,type="Gauss")
  nb2011_Gauss150.local<-focal(nb2011,w=fw150,na.rm=TRUE)
  #names(nb2011_Gauss150.local) <- gsub("2011_","2011.local_",names(nb2011))
  writeRaster(nb2011_Gauss150.local, filename=paste0("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/",names(nb2011_Gauss150.local),".local.tif"),overwrite=TRUE)
}


#New Brunswick 2015 Layers
rs2015<-c("nb2015_barren.tif","nb2015_conif.tif","nb2015_cult.tif","nb2015_decid.tif","nb2015_forestundiff.tif","nb2015_grassland.tif",
          "nb2015_mixed.tif","nb2015_orchard.tif","nb2015_shrub.tif","nb2015_urban.tif","nb2015_water.tif","nb2015_wetland.tif")
for (i in 1:length(rs2015)) { 
  nb2015 <- raster(paste0("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/",rs2015[i]))
  ## sigma = 150m
  fw150<-focalWeight(x=nb2015,d=150,type="Gauss")
  nb2015_Gauss150.local<-focal(nb2015,w=fw150,na.rm=TRUE)
  #names(nb2015_Gauss150.local) <- gsub("2015_","2015.local_",names(nb2015))
  writeRaster(nb2015_Gauss150.local, filename=paste0("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/",names(nb2015_Gauss150.local),".local.tif"),overwrite=TRUE)
}

#New Brunswick 2020 Layers
rs2020<-c("nb2020_barren.tif","nb2020_conif.tif","nb2020_cult.tif","nb2020_decid.tif","nb2020_forestundiff.tif","nb2020_grassland.tif",
          "nb2020_mixed.tif","nb2020_orchard.tif","nb2020_shrub.tif","nb2020_urban.tif","nb2020_water.tif","nb2020_wetland.tif")
for (i in 1:length(rs2020)) { 
  nb2020 <- raster(paste0("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/",rs2020[i]))
  ## sigma = 150m
  fw150<-focalWeight(x=nb2020,d=150,type="Gauss")
  nb2020_Gauss150.local<-focal(nb2020,w=fw150,na.rm=TRUE)
  #names(nb2020_Gauss150.local) <- gsub("2020_","2020.local_",names(nb2020))
  writeRaster(nb2020_Gauss150.local, filename=paste0("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/",names(nb2020_Gauss150.local),".local.tif"),overwrite=TRUE)
}


#Nova Scotia 2011 layers
rs2011<-c("ns2011_barren.tif","ns2011_conif.tif","ns2011_cult.tif",
          "ns2011_decid.tif","ns2011_forestundiff.tif","ns2011_grassland.tif",
          "ns2011_mixed.tif","ns2011_orchard.tif","ns2011_shrub.tif","ns2011_urban.tif","ns2011_water.tif","ns2011_wetland.tif")
#
for (i in 1:length(rs2011)) { 
  ns2011 <- raster(paste0("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/",rs2011[i]))
  ## sigma = 150m
  fw150<-focalWeight(x=ns2011,d=150,type="Gauss")
  ns2011_Gauss150.local<-focal(ns2011,w=fw150,na.rm=TRUE)
  #names(ns2011_Gauss150.local) <- gsub("2011_","2011.local_",names(ns2011))
  writeRaster(ns2011_Gauss150.local, filename=paste0("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/",names(ns2011_Gauss150.local),".local.tif"),overwrite=TRUE)
  rm(ns2011, ns2011_Gauss150.local)
  gc()
}

#Nova Scotia 2015 Layers
rs2015<-c("ns2015_barren.tif","ns2015_conif.tif","ns2015_cult.tif","ns2015_decid.tif","ns2015_grassland.tif",
          "ns2015_mixed.tif","ns2015_orchard.tif","ns2015_shrub.tif","ns2015_urban.tif","ns2015_water.tif","ns2015_wetland.tif")
for (i in 1:length(rs2015)) { 
  ns2015 <- raster(paste0("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/",rs2015[i]))
  ## sigma = 150m
  fw150<-focalWeight(x=ns2015,d=150,type="Gauss")
  ns2015_Gauss150.local<-focal(ns2015,w=fw150,na.rm=TRUE)
  #names(ns2015_Gauss150.local) <- gsub("2015_","2015.local_",names(ns2015))
  writeRaster(ns2015_Gauss150.local, filename=paste0("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/",names(ns2015_Gauss150.local),".local.tif"),overwrite=TRUE)
}

#Nova Scotia 2020 Layers
rs2020<-c("ns2020_barren.tif","ns2020_conif.tif","ns2020_cult.tif","ns2020_decid.tif","ns2020_grassland.tif",
          "ns2020_mixed.tif","ns2020_orchard.tif","ns2020_shrub.tif","ns2020_urban.tif","ns2020_water.tif","ns2020_wetland.tif")
for (i in 1:length(rs2020)) { 
  ns2020 <- raster(paste0("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/",rs2020[i]))
  ## sigma = 150m
  fw150<-focalWeight(x=ns2020,d=150,type="Gauss")
  ns2020_Gauss150.local<-focal(ns2020,w=fw150,na.rm=TRUE)
  #names(ns2020_Gauss150.local) <- gsub("2020_","2020.local_",names(ns2020))
  writeRaster(ns2020_Gauss150.local, filename=paste0("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/",names(ns2020_Gauss150.local),".local.tif"),overwrite=TRUE)
}


#Quebec 2011 layers
rs2011<-c("qc2011_barren.tif","qc2011_conif.tif","qc2011_cult.tif","qc2011_decid.tif","qc2011_forestundiff.tif","qc2011_grassland.tif",
          "qc2011_mixed.tif","qc2011_orchard.tif","qc2011_shrub.tif","qc2011_urban.tif","qc2011_water.tif","qc2011_wetland.tif")
for (i in 1:length(rs2011)) { 
  ## sigma = 150m
  fw150<-focalWeight(x=qc2011,d=150,type="Gauss")
  qc2011_Gauss150.local<-focal(qc2011,w=fw150,na.rm=TRUE)
  #names(qc2011_Gauss150.local) <- gsub("2011_","2011.local_",names(qc2011))
  writeRaster(qc2011_Gauss150.local, filename=paste0("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/",names(qc2011_Gauss150.local),".local.tif"),overwrite=TRUE)
}

#Quebec 2015 layers
rs2015<-c("qc2015_barren.tif","qc2015_conif.tif","qc2015_cult.tif","qc2015_decid.tif","qc2015_forestundiff.tif","qc2015_grassland.tif",
          "qc2015_mixed.tif","qc2015_orchard.tif","qc2015_shrub.tif","qc2015_urban.tif","qc2015_water.tif","qc2015_wetland.tif")
for (i in 1:length(rs2015)) { 
  qc2015 <- raster(paste0("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/",rs2015[i]))
  ## sigma = 150m
  fw150<-focalWeight(x=qc2015,d=150,type="Gauss")
  qc2015_Gauss150.local<-focal(qc2015,w=fw150,na.rm=TRUE)
  #names(qc2015_Gauss150.local) <- gsub("2015_","2015.local_",names(qc2015))
  writeRaster(qc2015_Gauss150.local, filename=paste0("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/",names(qc2015_Gauss150.local),".local.tif"),overwrite=TRUE)
}

#Quebec 2020 layers
rs2020<-c("qc2020_barren.tif","qc2020_conif.tif","qc2020_cult.tif","qc2020_decid.tif","qc2020_forestundiff.tif","qc2020_grassland.tif",
          "qc2020_mixed.tif","qc2020_orchard.tif","qc2020_shrub.tif","qc2020_urban.tif","qc2020_water.tif","qc2020_wetland.tif")
for (i in 1:length(rs2020)) { 
  qc2020 <- raster(paste0("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/",rs2020[i]))
  ## sigma = 150m
  fw150<-focalWeight(x=qc2020,d=150,type="Gauss")
  qc2020_Gauss150.local<-focal(qc2020,w=fw150,na.rm=TRUE)
  #names(qc2020_Gauss150.local) <- gsub("2020_","2020.local_",names(qc2020))
  writeRaster(qc2020_Gauss150.local, filename=paste0("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/",names(qc2020_Gauss150.local),".local.tif"),overwrite=TRUE)
}


#Ontario 2011 Layers
rs2011<-c("on2011_barren.tif","on2011_conif.tif","on2011_cult.tif","on2011_decid.tif","on2011_grassland.tif",
          "on2011_mixed.tif","on2011_shrub.tif","on2011_urban.tif","on2011_water.tif","on2011_wetland.tif")
for (i in 1:length(rs2011)) { 
  on2011 <- raster(paste0("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/on2011 binary files/",rs2011[i]))
  ## sigma = 150m
  fw150<-focalWeight(x=on2011,d=150,type="Gauss")
  on2011_Gauss150.local<-focal(on2011,w=fw150,na.rm=TRUE)
  #names(on2011_Gauss150.local) <- gsub("2011_","2011.local_",names(on2011))
  writeRaster(on2011_Gauss150.local, filename=paste0("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/",names(on2011_Gauss150.local),".local.tif"),overwrite=TRUE)
}

#Ontario 2015 Layers
rs2015<-c("on2015_barren.tif","on2015_conif.tif","on2015_cult.tif","on2015_decid.tif","on2015_grassland.tif",
          "on2015_mixed.tif","on2015_orchard.tif","on2015_shrub.tif","on2015_urban.tif","on2015_water.tif","on2015_wetland.tif")
for (i in 1:length(rs2015)) { 
  on2015 <- raster(paste0("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/on2015 binary files/",rs2015[i]))
  ## sigma = 150m
  fw150<-focalWeight(x=on2015,d=150,type="Gauss")
  on2015_Gauss150.local<-focal(on2015,w=fw150,na.rm=TRUE)
  #names(on2015_Gauss150.local) <- gsub("2015_","2015.local_",names(on2015))
  writeRaster(on2015_Gauss150.local, filename=paste0("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/",names(on2015_Gauss150.local),".local.tif"),overwrite=TRUE)
}

#Ontario 2020 Layers
rs2020<-c("on2020_barren.tif","on2020_conif.tif","on2020_cult.tif","on2020_decid.tif","on2020_grassland.tif",
          "on2020_mixed.tif","on2020_orchard.tif","on2020_shrub.tif","on2020_urban.tif","on2020_water.tif","on2020_wetland.tif")
for (i in 1:length(rs2020)) { 
  on2020 <- raster(paste0("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/binary habitat rasters/on2020 binary files/",rs2020[i]))
  ## sigma = 150m
  fw150<-focalWeight(x=on2020,d=150,type="Gauss")
  on2020_Gauss150.local<-focal(on2020,w=fw150,na.rm=TRUE)
  #names(on2020_Gauss150.local) <- gsub("2020_","2020.local_",names(on2020))
  writeRaster(on2020_Gauss150.local, filename=paste0("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/",names(on2020_Gauss150.local),".local.tif"),overwrite=TRUE)
}


####################################################################
#                                                                  #
#                                                                  #
#                                                                  #
#             STEP THREE - CONVERT PROPORTION OF LAND COVER        #
#   TYPES WITHIN ~ 150-2000 M FROM 30-M to 150-M RESOLUTION        #
#                                                                  #
#                                                                  #
#                                                                  #
####################################################################


#Aggregate (resample to coarser resolution to speed up processing)
rlist <- list.files("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/",pattern="local.tif$")
for (i in rlist){
  ras<-raster(paste0("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/",i))
  #ras<-raster("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/on2015.local_decid.local.tif")
  #change resolution from 30x30 to 150x150
  ras.aggregate <- aggregate(ras, fact=5)
  res(ras.aggregate)
  names(ras.aggregate) <- gsub("local","150m",names(ras))
  writeRaster(ras.aggregate, filename=paste0("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/150 m/",names(ras.aggregate),".tif"),overwrite=TRUE)
}

#Once you have that coarser 150-m resolution, you will use it to extract
#landscape metrics at larger spatial scales: 30-m resolution takes too long.
rlist2 <- list.files("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/150 m/",pattern="150m.tif$")
for (i in rlist2){
  ras<-raster(paste0("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/150 m/",i))
  ## sigma = 250m
  fw250<-focalWeight(x=ras,d=250,type="Gauss")
  ras_Gauss250<-focal(ras,w=fw250,na.rm=TRUE)
  names(ras_Gauss250) <- gsub("150m","250m",names(ras))
  writeRaster(ras_Gauss250, filename=paste0("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/250 m/",names(ras_Gauss250),".tif"),overwrite=TRUE)
}


rlist3 <- list.files("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/150 m/",pattern="150m.tif$")
for (i in rlist3){
  ras<-raster(paste0("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/150 m/",i))
  #ras<-raster("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/on2015.local_decid.local.tif")
  ## sigma = 1000m
  fw1000<-focalWeight(x=ras,d=1000,type="Gauss")
  ras_Gauss1000<-focal(ras,w=fw1000,na.rm=TRUE)
  names(ras_Gauss1000) <- gsub("150m","1000m",names(ras))
  writeRaster(ras_Gauss1000, filename=paste0("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/1000 m/",names(ras_Gauss1000),".tif"),overwrite=TRUE)
}

rlist4 <- list.files("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/150 m/",pattern="150m.tif$")
for (i in rlist4){
  ras<-raster(paste0("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/150 m/",i))
  #ras<-raster("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/on2015.local_decid.local.tif")
  ## sigma = 2000m
  fw2000<-focalWeight(x=ras,d=2000,type="Gauss")
  ras_Gauss2000<-focal(ras,w=fw2000,na.rm=TRUE)
  names(ras_Gauss2000) <- gsub("150m","2000m",names(ras))
  writeRaster(ras_Gauss2000, filename=paste0("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/2000 m/",names(ras_Gauss2000),".tif"),overwrite=TRUE)
}

####################################################################
#                                                                  #
#                                                                  #
#                                                                  #
#             STEP FOUR - CONVERT PROPORTION OF LAND COVER         #
#   TYPES WITHIN ~ 150-2000 M FROM 150-M to 200-M RESOLUTION       #
#                                                                  #
#                                                                  #
#                                                                  #
####################################################################


#Resample everything to 200-m resolution
#Aggregate (resample to coarser resolution to speed up processing)
#The other reason to do this is because LANDIS Outputs are at 200 m 
#resolution so it will be easier to convert those outputs to model 
#predictions for Wood Thrush

rlist <- list.files("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/150 m/",pattern=".tif$")
#Deciduous forest is the only Agriculture Canada land cover type that will be examined at 150-m
#scale in ALCES Online models
for (i in rlist){
  ras<-raster(paste0("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/150 m/",i))
  #change resolution from 150x150 to 200x200
  resampleFactor <- 200/150
  inCols <- ncol(ras)
  inRows <- nrow(ras)
  resampledRaster <- raster(ncol=(inCols / resampleFactor), nrow=(inRows / resampleFactor))
  extent(resampledRaster) <- extent(ras)
  res(resampledRaster)<-200#set to exactly 200 m before resampling occurs
  resampledRaster <- resample(ras,resampledRaster,datatype="INT1U",method='bilinear')
  writeRaster(resampledRaster, filename=paste0("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 200 m/150 m/",names(resampledRaster),".tif"),overwrite=TRUE)
}

#No Agriculture Canada Land Cover layers at 250-m scale are included in final
#BRT model selected for Landis scenarios, so they are not resampled for the 
#BRT models used in ALCES Online scenarios.
# rlist2 <- list.files("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/250 m/",pattern=".tif$")
# for (i in rlist2){
#   ras<-raster(paste0("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/250 m/",i))
#   #change resolution from 150x150 to 200x200
#   resampleFactor <- 200/150
#   inCols <- ncol(ras)
#   inRows <- nrow(ras)
#   resampledRaster <- raster(ncol=(inCols / resampleFactor), nrow=(inRows / resampleFactor))
#   extent(resampledRaster) <- extent(ras)
#   res(resampledRaster)<-200#set to exactly 200 m before resampling occurs
#   resampledRaster <- resample(ras,resampledRaster,datatype="INT1U",method='bilinear')
#   writeRaster(resampledRaster, filename=paste0("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 200 m/250 m/",names(resampledRaster),".tif"),overwrite=TRUE)
# }

#Grassland and cropland are the only Agriculture Canada land cover types that will be examined at 1000-m
#scale in ALCES Online models
rlist3 <- list.files("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/1000 m/",pattern=".tif$")
for (i in rlist3){
  ras<-raster(paste0("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/1000 m/",i))
  #change resolution from 150x150 to 200x200
  resampleFactor <- 200/150
  inCols <- ncol(ras)
  inRows <- nrow(ras)
  resampledRaster <- raster(ncol=(inCols / resampleFactor), nrow=(inRows / resampleFactor))
  extent(resampledRaster) <- extent(ras)
  res(resampledRaster)<-200#set to exactly 200 m before resampling occurs
  resampledRaster <- resample(ras,resampledRaster,datatype="INT1U",method='bilinear')
  writeRaster(resampledRaster, filename=paste0("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 200 m/1000 m/",names(resampledRaster),".tif"),overwrite=TRUE)
}

#Most Agriculture Canada land cover types will be examined at 2000-m
#scale in ALCES Online models - except deciduous, cropland, and grassland
rlist4 <- list.files("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/2000 m/",pattern=".tif$")
for (i in rlist4){
  ras<-raster(paste0("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/2000 m/",i))
  #change resolution from 150x150 to 200x200
  resampleFactor <- 200/150
  inCols <- ncol(ras)
  inRows <- nrow(ras)
  resampledRaster <- raster(ncol=(inCols / resampleFactor), nrow=(inRows / resampleFactor))
  extent(resampledRaster) <- extent(ras)
  res(resampledRaster)<-200#set to exactly 200 m before resampling occurs
  resampledRaster <- resample(ras,resampledRaster,datatype="INT1U",method='bilinear')
  writeRaster(resampledRaster, filename=paste0("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 200 m/2000 m/",names(resampledRaster),".tif"),overwrite=TRUE)
}

####################################################################
#                                                                  #
#                                                                  #
#                                                                  #
#             STEP FIVE - EXTRACT PROPORTION OF LAND COVER         #
#              TYPES AT 200-M RESOLUTION TO POINT COUNTS           #
#                                                                  #
#                                                                  #
#                                                                  #
####################################################################

