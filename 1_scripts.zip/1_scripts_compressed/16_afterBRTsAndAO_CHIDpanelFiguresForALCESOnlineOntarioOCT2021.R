#The purpose of this script is to process specific outputs
#from each self-contained Zonation exercise that has been 
#run, creating custom-designed plots in R from that output.

#There is a "current" and a "current + 2070" Zonation exercise
#for each Bird Conservation Region in Ontario

#For the Bird Conservation Regions in Ontario, I will create two
#sets of maps for each Zonation exercise. Each set will contain a panel colouring
#pixels according to their conservation priority on a continuous
#gradient. The second panel will identify all the pixels
#that are required for conservation to maintain 50/75/90/100 % of the current
#population of Wood Thrush in the study area.

#Current population from mean density raster: 

library(sp)
library(sf)
library(viridis)
library(lattice)
library(latticeExtra)
library(rasterVis)
library(raster)
library(tmap)
library(rgdal)
library(ggplot2)
tmap_mode("view")  #plot on map using tmap viewer

#province and territory shapefile
provs <-  readOGR("0_data_for_BRT_models/raw/BCR_Terrestrial_master/BCR_Terrestrial_master.shp")
#provs <-  readOGR("0_data_for_BRT_models/Canada shapefile/gpr_000a11a_e/gpr_000a11a_e.shp")
lcc_crs<-"+proj=lcc +lat_0=0 +lon_0=-95 +lat_1=49 +lat_2=77 +x_0=0 +y_0=0 +ellps=GRS80 +units=m +no_defs" 
provsproj<-spTransform(provs, CRSobj = lcc_crs)

#protected areas 
PAs <- readOGR("0_data_for_BRT_models/raw/Protected Areas/CPCAD2019.shp") 
PA.Ontario<-PAs[PAs$LOC_E=="Ontario",]
PAproj <- spTransform(PA.Ontario, CRSobj = lcc_crs) # reproject PA rasters to be lcc


########################################
#                                      #
#                                      #
#               BCR 13                 #
#                                      #
#                                      #
########################################


current.bcr13<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Zonation Inputs/Zonation_current_only_BCR13/Zonation_current_only/Zonation_current_only.rank.compressed.tif")
current.bcr13.rp<-projectRaster(current.bcr13, crs=lcc_crs)
current.2070.bcr13<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Zonation Inputs/Zonation_current_plus_2070_BCR13/outputs/Zonation_current_plus_2070.rank.compressed.tif")
current.2070.bcr13.rp<-projectRaster(current.2070.bcr13, crs=lcc_crs)
iStack<-stack(current.bcr13.rp, current.2070.bcr13.rp)


names(iStack) <- c("Current", "Current Plus 2070")#rename the files for the panel plot 'names'

#colour ramp for raster
bluegreen.colors2 <- colorRampPalette(c("#FFFACD", 
                                        "#FFF68F", 
                                        "#ADFF2F", 
                                        "greenyellow", 
                                        "#00CD00", 
                                        "green3", 
                                        "mediumturquoise", 
                                        "#007FFF", 
                                        "blue", 
                                        "purple", 
                                        "red"), space="Lab")

LBDG<-colorRampPalette(c("tan","darkgreen"))


#setting my trellis themes
#these will remain this way until you change them back
mytheme <- theme_classic() +
  theme(text=element_text(size=12, family="Arial"),
        axis.text.x=element_text(size=12),
        axis.text.y=element_text(size=12),
        axis.title.x=element_text(margin=margin(10,0,0,0)),
        axis.title.y=element_text(margin=margin(0,10,0,0)),
        axis.line.x=element_line(linetype=1),
        axis.line.y=element_line(linetype=1))

mytheme$panel.border = element_rect(colour = "black", fill = NA)
mytheme$panel.border$col = "black"
mytheme$strip.background$alpha = 0
mytheme <- trellis.par.set(mytheme)

tiff("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Zonation Inputs/BCR13MultipanelZonationRanks.tiff", units="in", width=12, height=8, res=300)
rasterVis::levelplot(iStack,
                     margin=FALSE, # removes the histograms at the margins                    
                     colorkey=list(
                       space='bottom', # location for legend bar              
                       #height=0.5, width=0.5,
                       labels=list(at=seq(0,1,0.2), font=20, cex=2), # tick labels on legend
                       axis.line=list(col='black') # border of legend bar and ticks
                     ),    
                     par.settings=list(
                       axis.line=list(col='black') # bounding box line color
                     ),
                     scales=list(draw=F, cex=2), # removes coordinates on XY axes        
                     col.regions=LBDG) + # color scheme
  latticeExtra::layer(sp.lines(provsproj, col="grey",lwd = 1.5))+ # extra shapefile data I want overlayed
  #latticeExtra::layer(sp.lines(AlPacproj, col="black",lwd = 1.5))+ # extra shapefile data I want overlayed
  latticeExtra::layer(sp.polygons(PAproj, col="black",lwd = 1.5)) # extra shapefile data I want overlayed
dev.off()

############
#example code to create discrete value rasters for figures with CHID identified
#these rasters could then be stacked in the above code for panels. 

#BCR 13 Current Distribution 
current.bcr13.b <- current.bcr13
#The proportion of the total value in the current density layers
#starts to become <1 when the proportion of landscape removed 
#becomes >0
current.bcr13.b[!current.bcr13 >= 0] <- 0 
#what land you can lose (~0.5%) before starting to lose habitat for 100 % of current population
current.bcr13.b[current.bcr13 >= 0] <- 1 
#what land you need to maintain habitat for 100 % of current population
current.bcr13.b[current.bcr13 >= 0.31898] <- 2 
#what land you need (100-31.898) to maintain habitat for 90 % of current population
current.bcr13.b[current.bcr13 >= 0.57796] <- 3 
#what land you need to maintain habitat for 75 % of current population
current.bcr13.b[current.bcr13 >= 0.81995] <- 4 
#what land you need to maintain habitat for 50 % of current population
plot(current.bcr13.b)

#view
tm_shape(current.bcr13.b) + tm_raster()
plot(current.bcr13.b)
writeRaster(current.bcr13.b, filename="4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Zonation Inputs/Zonation_current_only_BCR13/Zonation_current_only/Zonation_current_only_BCR13.perc_popn_range.tif", overwrite=TRUE)

#BCR 13 Current + 2070 Distribution
current.2070.bcr13.b <- current.2070.bcr13

#The current population in Year 0 is 86.24 % what is expected in Year 50 
#or 86.24 % of the 2070 population (using all 5 simulation runs)

#The proportion of the total value in the current density layers
#starts to become <1 when the proportion of landscape removed 
#becomes >0.005
current.2070.bcr13.b[current.2070.bcr13 < (0.16799)] <- 0 
#what land you can lose before starting to lose habitat for 100 % of current population 
current.2070.bcr13.b[current.2070.bcr13 >= 0.16799] <- 1 
#what land you need to maintain habitat for 100 % of current population
current.2070.bcr13.b[current.2070.bcr13 >= 0.58796] <- 2 
#what land you need to maintain habitat for 90 % of current population
current.2070.bcr13.b[current.2070.bcr13 >= 0.76295] <- 3 
#what land you need to maintain habitat for 75 % of current population
current.2070.bcr13.b[current.2070.bcr13 >= 0.90494] <- 4 
#what land you need to maintain habitat for 50 % of current population
plot(current.2070.bcr13.b)

#view
tm_shape(current.2070.bcr13.b) + tm_raster()
plot(current.2070.bcr13.b)
writeRaster(current.2070.bcr13.b, filename="4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Zonation Inputs/Zonation_current_plus_2070_BCR13/outputs/Zonation_current_plus_2070_BCR13.perc_popn_range.tif", overwrite=TRUE)


#stack the rasters for the panel plot
current.bcr13.b<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Zonation Inputs/Zonation_current_only_BCR13/Zonation_current_only/Zonation_current_only_BCR13.perc_popn_range.tif")
current.bcr13.b.rp<-projectRaster(current.bcr13.b, crs=lcc_crs)

current.2070.bcr13.b<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Zonation Inputs/Zonation_current_plus_2070_BCR13/outputs/Zonation_current_plus_2070_BCR13.perc_popn_range.tif")
current.2070.bcr13.b.rp<-projectRaster(current.2070.bcr13.b, crs=lcc_crs)

iStackB <- stack(current.bcr13.b.rp, current.2070.bcr13.b.rp)


names(iStackB) <- c("Current", "Current Plus 2070")#rename the files for the panel plot 'names'

#setting my trellis themes
#these will remain this way until you change them back
mytheme <- theme_classic() +
  theme(text=element_text(size=12, family="Arial"),
        axis.text.x=element_text(size=12),
        axis.text.y=element_text(size=12),
        axis.title.x=element_text(margin=margin(10,0,0,0)),
        axis.title.y=element_text(margin=margin(0,10,0,0)),
        axis.line.x=element_line(linetype=1),
        axis.line.y=element_line(linetype=1))

mytheme$panel.border = element_rect(colour = "black", fill = NA)
mytheme$panel.border$col = "black"
mytheme$strip.background$alpha = 0
mytheme <- trellis.par.set(mytheme)

#heatramp<- colorRampPalette(c("#ABD9E9","#FFFFBF","#FEE090","#FDAE61","#F46D43", "#D73027", "#A50026") ) #set the colours #individual colours for colour ramp from blue to red
#cuts <- c(0.00, 0.60, 0.80,0.85, 0.90, 0.95, 1.00) #set breaks in ranking


heatramp<- colorRampPalette(c("#ABD9E9","#FFFFBF","#FEE090", "#F46D43", "#A50026") ) #set the colours #individual colours for colour ramp from blue to red
tiff('4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Zonation Inputs/BCR13percentagecurrent.tiff', units="in", width=12, height=8, res=300)
rasterVis::levelplot(iStackB,
                     margin=FALSE, 
                     # removes the histograms at the margins   
                     colorkey=FALSE,
                     # colorkey=list(
                     #   space='right', # location for legend bar              
                     #   height=0.5, width=0.5, at=seq(0,4,1), 
                     #   labels=list(as.character(c("No contribution", "75-100% Popn", "50-75% Popn", "25-50% Popn", "0-25% Popn")), font=10, cex=2), # tick labels on legend
                     #   axis.line=list(col='black') # border of legend bar and ticks
                     # ),    
                     par.settings=list(
                       axis.line=list(col='black') # bounding box line color
                     ),
                     scales=list(draw=F, cex=2), # removes coordinates on XY axes        
                     col.regions=heatramp) + # color scheme
  latticeExtra::layer(sp.lines(provsproj, col="grey",lwd = 1.5))+ # extra shapefile data I want overlayed
  latticeExtra::layer(sp.lines(PAproj, col="black",lwd = 1.5))#+ # extra shapefile data I want overlayed
#latticeExtra::layer(sp.lines(AlPacproj, col="black",lwd = 1.5)) 
# extra shapefile data I want overlayed but won't overlay for unknown reason
dev.off()


########################################
#                                      #
#                                      #
#               BCR 12                 #
#                                      #
#                                      #
########################################

current.bcr12<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Zonation Inputs/Zonation_current_only_BCR12/Zonation_current_only_BCR12/Zonation_current_only_BCR12.rank.compressed.tif")
current.bcr12.rp<-projectRaster(current.bcr12, crs=lcc_crs)

current.2070.bcr12<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Zonation Inputs/Zonation_current_plus_2070_BCR12/Zonation_current_plus_2070_BCR12/Zonation_current_plus_2070_BCR12.rank.compressed.tif")
current.2070.bcr12.rp<-projectRaster(current.2070.bcr12, crs=lcc_crs)

iStack<-stack(current.bcr12.rp, current.2070.bcr12.rp)


names(iStack) <- c("Current", "Current Plus 2070")#rename the files for the panel plot 'names'

#colour ramp for raster
bluegreen.colors2 <- colorRampPalette(c("#FFFACD", 
                                        "#FFF68F", 
                                        "#ADFF2F", 
                                        "greenyellow", 
                                        "#00CD00", 
                                        "green3", 
                                        "mediumturquoise", 
                                        "#007FFF", 
                                        "blue", 
                                        "purple", 
                                        "red"), space="Lab")

LBDG<-colorRampPalette(c("tan","darkgreen"))


#setting my trellis themes
#these will remain this way until you change them back
mytheme <- theme_classic() +
  theme(text=element_text(size=12, family="Arial"),
        axis.text.x=element_text(size=12),
        axis.text.y=element_text(size=12),
        axis.title.x=element_text(margin=margin(10,0,0,0)),
        axis.title.y=element_text(margin=margin(0,10,0,0)),
        axis.line.x=element_line(linetype=1),
        axis.line.y=element_line(linetype=1))

mytheme$panel.border = element_rect(colour = "black", fill = NA)
mytheme$panel.border$col = "black"
mytheme$strip.background$alpha = 0
mytheme <- trellis.par.set(mytheme)

tiff("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Zonation Inputs/BCR12MultipanelZonationRanks.tiff", units="in", width=12, height=8, res=300)
rasterVis::levelplot(iStack,
                     margin=FALSE, # removes the histograms at the margins                    
                     colorkey=list(
                       space='bottom', # location for legend bar              
                       #height=0.5, width=0.5,
                       labels=list(at=seq(0,1,0.2), font=20, cex=2), # tick labels on legend
                       axis.line=list(col='black') # border of legend bar and ticks
                     ),    
                     par.settings=list(
                       axis.line=list(col='black') # bounding box line color
                     ),
                     scales=list(draw=F, cex=2), # removes coordinates on XY axes        
                     col.regions=LBDG) + # color scheme
  latticeExtra::layer(sp.lines(provsproj, col="grey",lwd = 1.5))+ # extra shapefile data I want overlayed
  latticeExtra::layer(sp.polygons(PAproj, col="black",lwd = 1.5)) # extra shapefile data I want overlayed
dev.off()

############
#example code to create discrete value rasters for figures with CHID identified
#these rasters could then be stacked in the above code for panels. 

#BCR 12 Current Distribution 
current.bcr12.b <- current.bcr12
#The proportion of the total value in the current density layers
#starts to become <1 when the proportion of landscape removed 
#becomes >0.006
current.bcr12.b[current.bcr12 < (0.006)] <- 0 
#what land you can lose (~0.6%) before starting to lose habitat for 100 % of current population
current.bcr12.b[current.bcr12 >= 0.006] <- 1 
#rank based on what land you need (1-0.006) to maintain habitat for 100 % of current population
current.bcr12.b[current.bcr12 >= 0.28699] <- 2 
#rank based on what land you need (1-0.28699) to maintain habitat for 90 % of current population
current.bcr12.b[current.bcr12 >= 0.50599] <- 3 
#rank based on what land you need (1-0.50599) to maintain habitat for 75 % of current population
current.bcr12.b[current.bcr12 >= 0.75198] <- 4 
#rank based on what land you need (1-0.75198) to maintain habitat for 50 % of current population
plot(current.bcr12.b)

#view
tm_shape(current.bcr12.b) + tm_raster()
plot(current.bcr12.b)
writeRaster(current.bcr12.b, filename="4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Zonation Inputs/Zonation_current_only_BCR12/Zonation_current_only_BCR12/Zonation_current_only_BCR12.perc_popn_range.tif", overwrite=TRUE)

#BCR 12 Current + 2070 Distribution
current.2070.bcr12.b <- current.2070.bcr12

#The current population in Year 0 is 77.0 % what is expected in Year 50

#The proportion of the total value in the current density layers
#starts to become <1 when the proportion of landscape removed 
#becomes >0.005
current.2070.bcr12.b[current.2070.bcr12 < (0.42599)] <- 0 
#what land you can lose before starting to lose habitat for 100 % of current population 
current.2070.bcr12.b[current.2070.bcr12 >= 0.42599] <- 1 
#rank based on what land you need to maintain habitat for 100 % of current population
current.2070.bcr12.b[current.2070.bcr12 >= 0.74698] <- 2 
#rank based on what land you need to maintain habitat for 90 % of current population
current.2070.bcr12.b[current.2070.bcr12 >= 0.84898] <- 3 
#rank based on what land you need to maintain habitat for 75 % of current population
current.2070.bcr12.b[current.2070.bcr12 >= 0.93398] <- 4 
#rank based on what land you need to maintain habitat for 50 % of current population
plot(current.2070.bcr12.b)

#view
tm_shape(current.2070.bcr12.b) + tm_raster()
plot(current.2070.bcr12.b)
writeRaster(current.2070.bcr12.b, filename="4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Zonation Inputs/Zonation_current_plus_2070_BCR12/Zonation_current_plus_2070_BCR12/Zonation_current_plus_2070_BCR12.perc_popn_range.tif", overwrite=TRUE)


#stack the rasters for the panel plot
current.bcr12.b<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Zonation Inputs/Zonation_current_only_BCR12/Zonation_current_only_BCR12/Zonation_current_only_BCR12.perc_popn_range.tif")
current.bcr12.b.rp<-projectRaster(current.bcr12.b, crs=lcc_crs)

current.2070.bcr12.b<-raster("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Zonation Inputs/Zonation_current_plus_2070_BCR12/Zonation_current_plus_2070_BCR12/Zonation_current_plus_2070_BCR12.perc_popn_range.tif")
current.2070.bcr12.b.rp<-projectRaster(current.2070.bcr12.b, crs=lcc_crs)

iStackB <- stack(current.bcr12.b.rp, current.2070.bcr12.b.rp)


names(iStackB) <- c("Current", "Current Plus 2070")#rename the files for the panel plot 'names'

#setting my trellis themes
#these will remain this way until you change them back
mytheme <- theme_classic() +
  theme(text=element_text(size=12, family="Arial"),
        axis.text.x=element_text(size=12),
        axis.text.y=element_text(size=12),
        axis.title.x=element_text(margin=margin(10,0,0,0)),
        axis.title.y=element_text(margin=margin(0,10,0,0)),
        axis.line.x=element_line(linetype=1),
        axis.line.y=element_line(linetype=1))

mytheme$panel.border = element_rect(colour = "black", fill = NA)
mytheme$panel.border$col = "black"
mytheme$strip.background$alpha = 0
mytheme <- trellis.par.set(mytheme)

#heatramp<- colorRampPalette(c("#ABD9E9","#FFFFBF","#FEE090","#FDAE61","#F46D43", "#D73027", "#A50026") ) #set the colours #individual colours for colour ramp from blue to red
#cuts <- c(0.00, 0.60, 0.80,0.85, 0.90, 0.95, 1.00) #set breaks in ranking


heatramp<- colorRampPalette(c("#ABD9E9","#FFFFBF","#FEE090", "#F46D43", "#A50026") ) #set the colours #individual colours for colour ramp from blue to red
tiff('4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Zonation Inputs/BCR12percentagecurrent.tiff', units="in", width=12, height=8, res=300)
rasterVis::levelplot(iStackB,
                     margin=FALSE, 
                     # removes the histograms at the margins   
                     colorkey=FALSE,
                     # colorkey=list(
                     #   space='right', # location for legend bar              
                     #   height=0.5, width=0.5, at=seq(0,4,1), 
                     #   labels=list(as.character(c("No contribution", "75-100% Popn", "50-75% Popn", "25-50% Popn", "0-25% Popn")), font=10, cex=2), # tick labels on legend
                     #   axis.line=list(col='black') # border of legend bar and ticks
                     # ),    
                     par.settings=list(
                       axis.line=list(col='black') # bounding box line color
                     ),
                     scales=list(draw=F, cex=2), # removes coordinates on XY axes        
                     col.regions=heatramp) + # color scheme
  latticeExtra::layer(sp.lines(provsproj, col="grey",lwd = 1.5))+ # extra shapefile data I want overlayed
  latticeExtra::layer(sp.lines(PAproj, col="black",lwd = 1.5))#+ # extra shapefile data I want overlayed
dev.off()

#Runtime plots
library(ggplot2)
library(grid)
library(gridExtra)
current.bcr12.rt<-read.csv("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Zonation Inputs/Zonation_current_only_BCR12/Zonation_current_only_BCR12/Zonation_current_only_BCR12.runtimeplot.csv")
plot1<- ggplot(data=current.bcr12.rt)+
  geom_line(aes(x=Prop_landscape_lost, y=prop_currentpopn_remaining),color="darkred")+
  geom_vline(xintercept = 0.006,  size=0.5, linetype="dashed")+
  geom_vline(xintercept = 0.28699,  size=0.5, linetype="dashed")+
  geom_vline(xintercept = 0.50599,  size=0.5, linetype="dashed")+
  geom_vline(xintercept = 0.75198,  size=0.5, linetype="dashed")+
  labs(x = "Proportion of WOTH BCR-12 Ontario range lost", y="Proportion of Current Population Left", size=2)+
  annotate("text", x= 0.05, y = 0.125,hjust=0, label = "100 % of current population", size=3, angle=90)+
  annotate("text", x= 0.32, y = 0.125,hjust=0, label = "90 % of current population", size=3, angle=90)+
  annotate("text", x= 0.55, y = 0,hjust=0, label = "75 % of current population", size=3, angle=90)+
  annotate("text", x= 0.77, y = 0,hjust=0, label = "50 % of current population", size=3, angle=90)

ggsave(plot1, file="4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Zonation Inputs/Zonation_current_only_BCR12/Zonation_current_only_BCR12/Zonation_current_only_BCR12.runtimeplot.png", units="in", width=10, height=8)

current.2070.bcr12.rt<-read.csv("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Zonation Inputs/Zonation_current_plus_2070_BCR12/Zonation_current_plus_2070_BCR12/Zonation_current_plus_2070_BCR12.runtimeplot.csv")
plot2<- ggplot(data=current.2070.bcr12.rt)+
  geom_line(aes(x=Prop_landscape_lost, y=prop_futurepopnremaining),color="darkred")+
  geom_vline(xintercept = 0.42599,  size=0.5, linetype="dashed")+
  #rank based on what land you need to maintain habitat for 100 % of current population
  geom_vline(xintercept = 0.74698,  size=0.5, linetype="dashed")+
  #rank based on what land you need to maintain habitat for 90 % of current population
  geom_vline(xintercept = 0.84898,  size=0.5, linetype="dashed")+
  #rank based on what land you need to maintain habitat for 75 % of current population
  geom_vline(xintercept = 0.93398,  size=0.5, linetype="dashed")+
  #rank based on what land you need to maintain habitat for 50 % of current population
  labs(x = "Proportion of WOTH BCR-12 Ontario range lost", y="Proportion of Future Population Left", size=2)+
  annotate("text", x= 0.44, y = 0,hjust=0, label = "100 % of current population", size=3, angle=90)+
  annotate("text", x= 0.76, y = 0, hjust=0, label = "90 % of current population", size=3, angle=90)+
  annotate("text", x= 0.86, y = 0, hjust=0, label = "75 % of current population", size=3, angle=90)+
  annotate("text", x= 0.95, y = 0.5,hjust=0, label = "50 % of current population", size=3, angle=90)

ggsave(plot2, file="4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Zonation Inputs/Zonation_current_plus_2070_BCR12/Zonation_current_plus_2070_BCR12/Zonation_current_plus_2070_BCR12.runtimeplot.png", units="in", width=10, height=8)

plot3<-grid.arrange(plot1,plot2,ncol=2)
ggsave(plot3, file="4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Zonation Inputs/Zonation_BCR12.runtimeplots.png", units="in", width=12, height=8)

current.bcr13.rt<-read.csv("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Zonation Inputs/Zonation_current_only_BCR13/Zonation_current_only/Zonation_current_only_BCR13.runtimeplot.csv")
plot4<- ggplot(data=current.bcr13.rt)+
  geom_line(aes(x=Prop_landscape_lost, y=prop_currentpopn_remaining),color="darkred")+
  geom_vline(xintercept = 0.001,  size=0.5, linetype="dashed")+
  #what land you can lose while maintaining habitat for 100 % of current population
  geom_vline(xintercept = 0.31898,  size=0.5, linetype="dashed")+
  #what land you can lose while maintaining habitat for 90 % of current population
  geom_vline(xintercept = 0.57796,  size=0.5, linetype="dashed")+
  #what land you can lose while maintaining habitat for 75 % of current population
  geom_vline(xintercept = 0.81995,  size=0.5, linetype="dashed")+
  #what land you can lose while maintaining habitat for 50 % of current population
  labs(x = "Proportion of WOTH BCR-13 Ontario range lost", y="Proportion of Current Population Left", size=2)+
  annotate("text", x= 0.01, y = 0.125,hjust=0, label = "100 % of current population", size=3, angle=90)+
  annotate("text", x= 0.33, y = 0.125,hjust=0, label = "90 % of current population", size=3, angle=90)+
  annotate("text", x= 0.59, y = 0,hjust=0, label = "75 % of current population", size=3, angle=90)+
  annotate("text", x= 0.84, y = 0,hjust=0, label = "50 % of current population", size=3, angle=90)

ggsave(plot4, file="4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Zonation Inputs/Zonation_current_only_BCR13/Zonation_current_only/Zonation_current_only_BCR13.runtimeplot.png", units="in", width=10, height=8)

current.2070.bcr13.rt<-read.csv("4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Zonation Inputs/Zonation_current_plus_2070_BCR13/outputs_old/Zonation_current_plus_2070_BCR13.runtimeplot.csv")
plot5<- ggplot(data=current.2070.bcr13.rt)+
  geom_line(aes(x=Prop_landscape_lost, y=prop_futurepopn_remaining),color="darkred")+
  geom_vline(xintercept = 0.16799,  size=0.5, linetype="dashed")+
  #what land you can lose while maintaining habitat for 100 % of current population
  geom_vline(xintercept = 0.58796,  size=0.5, linetype="dashed")+
  #what land you need to maintain habitat for 90 % of current population
  geom_vline(xintercept = 0.76295,  size=0.5, linetype="dashed")+
  #what land you can lose while maintaining habitat for 75 % of current population
  geom_vline(xintercept = 0.90494,  size=0.5, linetype="dashed")+
  #what land you can lose while maintaining habitat for 50 % of current population
  labs(x = "Proportion of WOTH BCR-13 Ontario range lost", y="Proportion of Future Population Left", size=2)+
  annotate("text", x= 0.18, y = 0,hjust=0, label = "100 % of current population", size=3, angle=90)+
  annotate("text", x= 0.60, y = 0, hjust=0, label = "90 % of current population", size=3, angle=90)+
  annotate("text", x= 0.78, y = 0, hjust=0, label = "75 % of current population", size=3, angle=90)+
  annotate("text", x= 0.92, y = 0.5,hjust=0, label = "50 % of current population", size=3, angle=90)

ggsave(plot5, file="4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Zonation Inputs/Zonation_current_plus_2070_BCR13/outputs_old/Zonation_current_plus_2070_BCR13.runtimeplot.png", units="in", width=10, height=8)

plot6<-grid.arrange(plot4,plot5,ncol=2)
ggsave(plot6, file="4_BRT_outputs/alces_200_model/pred_CI/WOTH Predictions/Zonation Inputs/Zonation_BCR13.runtimeplots.png", units="in", width=12, height=8)


