#Note: This script is for estimating area and size class distributions
#of spruce budworm outbreak areas within Ontario Wood Thrush range. These layers aren't
#used as variables in the BRT or GLM models for ALCES Online scenarios
#but are necessary for modeling changes in forest age structure in the simulations.

#I am using GIS data updated as recently as 2020 by the Ontario Ministry of 
#Natural Resources' Forest Research Inventory. Insect outbreak polygons were intersected in
#ArcGIS with Bird Conservation Region polygons, so that I can get separate area and
#size class distributions by BCR and see where budworm outbreaks are concentrated. There 
#are other forest insect pests in the database, but I am only measuring the areas of 
#budworm outbreaks severe enough to be forest mortality events.

#I will start by importing a csv files containing the areas of individual outbreak polygons
#limited to those within the updated Wood Thrush range in Ontario.

library(raster)
library(dismo)
library(rpart)
library(maptools)
library(data.table)
library(rgdal)
library(dplyr)
library(ggplot2)
library(spatial)
library(rasterVis)
library(RColorBrewer)

OUTB<-read.csv("2_GIS outputs for ALCES Online/Recent NonHarvest/InsectXYearXBCR/InsectsXYearXBCRXWOTH.csv")

###############################################################################################
#                                                                                             #
#                                                                                             #
#                                BUDWORM                                                   #
#                                                                                             #
###############################################################################################
str(OUTB)
nrow(OUTB)#503474

#So I'll generate summaries for each BCR. 
#I am only interested in the 10 most recent years (2010-2019) 
#and only in budworm outbreaks that cause mortality, opening
#up the forest
levels(as.factor(OUTB$YEAR_OF_EV))
OUTB10<-OUTB[OUTB$YEAR_OF_EV>2010,]
nrow(OUTB10)#178293

OUTB10budwormsumm<-OUTB10 %>%
  filter(FOREST_INS=="Spruce Budworm")%>%
  group_by(BCRNAME, FOREST_DAM) %>%
  summarise(TotalArea=sum(RecalcHa), 
            MeanCutSize=mean(RecalcHa),
            MaxCutSize=max(RecalcHa))

#  BCRNAME                               FOREST_DAM      TotalArea MeanCutSize MaxCutSize
# 1 BOREAL HARDWOOD TRANSITION            Light                534.       12.7       275. 
# 2 BOREAL HARDWOOD TRANSITION            Moderate-Severe   539206.       28.1     22095. 
# 3 BOREAL HARDWOOD TRANSITION            Mortality          53872. (73%) 22.9      1144. 
# 4 BOREAL SOFTWOOD SHIELD                Light                601.        8.84      158. 
# 5 BOREAL SOFTWOOD SHIELD                Moderate-Severe   291417.       30.8      6324. 
# 6 BOREAL SOFTWOOD SHIELD                Mortality           2544. ( 4%)  7.59       92.6
# 7 LOWER GREAT LAKES/ ST. LAWRENCE PLAIN Light                278.        2.21       59.5
# 8 LOWER GREAT LAKES/ ST. LAWRENCE PLAIN Moderate-Severe    99323.       46.0      5406. 
# 9 LOWER GREAT LAKES/ ST. LAWRENCE PLAIN Mortality          17501. (23%) 41.8      1251. 

#Total Area of Mortality Outbreaks from 2010-2020: 73917 ha
#There is significant budworm-related mortality in all 3 BCRs

library(hrbrthemes)
#in Boreal Hardwood Transition BCR
p.bht <- OUTB10 %>%
  filter(FOREST_INS=="Spruce Budworm")%>%
  filter(BCRNAME == "BOREAL HARDWOOD TRANSITION")%>%
  filter(FOREST_DAM == "Mortality")%>%
  ggplot( aes(x=RecalcHa, fill=BCRNAME)) +
  geom_histogram( color="#e9ecef", alpha=0.6, position = 'identity') +
  scale_fill_manual(values=c("#69b3a2", "#404080", "red")) +
  theme_ipsum() +
  labs(fill="") #Virtually all mortal outbreaks < 300 ha 

tiff('2_GIS outputs for ALCES Online/BUDWORM_BorealHardwoodTransition.tiff', units="in", width=12, height=8, res=300)
OUTB10 %>%
  filter(FOREST_INS=="Spruce Budworm")%>%
  filter(BCRNAME == "BOREAL HARDWOOD TRANSITION")%>%
  filter(FOREST_DAM == "Mortality")%>%
  ggplot( aes(x=RecalcHa, fill=BCRNAME)) +
  geom_histogram( color="#e9ecef", alpha=0.6, position = 'identity') +
  scale_fill_manual(values=c("#69b3a2", "#404080", "red")) +
  theme_ipsum() +
  labs(fill="")
dev.off()

p.bht300 <- OUTB10 %>%
  filter(FOREST_INS=="Spruce Budworm")%>%
  filter(BCRNAME == "BOREAL HARDWOOD TRANSITION")%>%
  filter(FOREST_DAM == "Mortality")%>%
  filter(RecalcHa < 300)%>%
  ggplot( aes(x=RecalcHa, ..count../sum(..count..), fill=BCRNAME)) +
  geom_histogram( color="#e9ecef", alpha=0.6, position = 'identity', bins=4) +
  scale_fill_manual(values=c("#69b3a2", "#404080")) +
  theme_ipsum() +
  labs(fill="")

tiff('2_GIS outputs for ALCES Online/BUDWORM_BorealHardwoodTransition_250andbelow.tiff', units="in", width=12, height=8, res=300)
OUTB10 %>%
  filter(FOREST_INS=="Spruce Budworm")%>%
  filter(BCRNAME == "BOREAL HARDWOOD TRANSITION")%>%
  filter(FOREST_DAM == "Mortality")%>%
  filter(RecalcHa < 300)%>%
  ggplot( aes(x=RecalcHa, ..count../sum(..count..), fill=BCRNAME)) +
  geom_histogram( color="#e9ecef", alpha=0.6, position = 'identity', bins=4) +
  scale_fill_manual(values=c("#69b3a2", "#404080")) +
  theme_ipsum() +
  labs(fill="")
dev.off()

#About 90 % of mortal outbreaks are 0-50 ha (Use 25 ha for size class)
#About 7.5 % of mortal outbreaks are 50-150 ha (Use 125 ha for size class)
#About 2.5 % of mortal outbreaks are 150-250 ha (Use 200 ha for size class)

#There will a few larger than that in exceptional cases

#In Boreal Softwood Shield BCR
p.bss <- OUTB10 %>%
  filter(FOREST_INS=="Spruce Budworm")%>%
  filter(BCRNAME == "BOREAL SOFTWOOD SHIELD")%>%
  filter(FOREST_DAM == "Mortality")%>%
  ggplot( aes(x=RecalcHa, fill=BCRNAME)) +
  geom_histogram( color="#e9ecef", alpha=0.6, position = 'identity') +
  scale_fill_manual(values=c("#69b3a2", "#404080")) +
  theme_ipsum() +
  labs(fill="") #Virtually all mortal budworm outbreaks < 100 ha 

tiff('2_GIS outputs for ALCES Online/BUDWORM_BorealSoftwoodShield.tiff', units="in", width=12, height=8, res=300)
OUTB10 %>%
  filter(FOREST_INS=="Spruce Budworm")%>%
  filter(BCRNAME == "BOREAL SOFTWOOD SHIELD")%>%
  filter(FOREST_DAM == "Mortality")%>%
  ggplot( aes(x=RecalcHa, fill=BCRNAME)) +
  geom_histogram( color="#e9ecef", alpha=0.6, position = 'identity') +
  scale_fill_manual(values=c("#69b3a2", "#404080")) +
  theme_ipsum() +
  labs(fill="")
dev.off()

p.bss100 <- OUTB10 %>%
  filter(FOREST_INS=="Spruce Budworm")%>%
  filter(BCRNAME == "BOREAL SOFTWOOD SHIELD")%>%
  filter(FOREST_DAM == "Mortality")%>%
  filter(RecalcHa < 100)%>%
  ggplot( aes(x=RecalcHa, ..count../sum(..count..), fill=BCRNAME)) +
  geom_histogram( color="#e9ecef", alpha=0.6, position = 'identity', bins=4) +
  scale_fill_manual(values=c("#69b3a2", "#404080")) +
  theme_ipsum() +
  labs(fill="")

tiff('2_GIS outputs for ALCES Online/BUDWORM_BorealSoftwoodShield_below100.tiff', units="in", width=12, height=8, res=300)
OUTB10 %>%
  filter(FOREST_INS=="Spruce Budworm")%>%
  filter(BCRNAME == "BOREAL SOFTWOOD SHIELD")%>%
  filter(FOREST_DAM == "Mortality")%>%
  filter(RecalcHa < 100)%>%
  ggplot( aes(x=RecalcHa, ..count../sum(..count..), fill=BCRNAME)) +
  geom_histogram( color="#e9ecef", alpha=0.6, position = 'identity', bins=4) +
  scale_fill_manual(values=c("#69b3a2", "#404080")) +
  theme_ipsum() +
  labs(fill="")
dev.off()

#About 85 % of mortal outbreaks are 0-15 ha (Use 7.5 ha)
#About 13 % of mortal outbreaks are 15-45 ha (Use 30 ha)
#About 2 % of mortal outbreaks are 45-76.7 ha (Use 60.8 ha)

#In Great Lakes/St. Lawrence Plain BCR
p.glsll <- OUTB10 %>%
  filter(FOREST_INS=="Spruce Budworm")%>%
  filter(BCRNAME == "LOWER GREAT LAKES/ ST. LAWRENCE PLAIN")%>%
  filter(FOREST_DAM == "Mortality")%>%
  ggplot( aes(x=RecalcHa, fill=BCRNAME)) +
  geom_histogram( color="#e9ecef", alpha=0.6, position = 'identity') +
  scale_fill_manual(values=c("#69b3a2", "#404080")) +
  theme_ipsum() +
  labs(fill="") #Virtually all mortal budworm outbreaks < 250 ha 

tiff('2_GIS outputs for ALCES Online/BUDWORM_GreatLakesStLawrencePlain.tiff', units="in", width=12, height=8, res=300)
OUTB10 %>%
  filter(FOREST_INS=="Spruce Budworm")%>%
  filter(BCRNAME == "LOWER GREAT LAKES/ ST. LAWRENCE PLAIN")%>%
  filter(FOREST_DAM == "Mortality")%>%
  ggplot( aes(x=RecalcHa, fill=BCRNAME)) +
  geom_histogram( color="#e9ecef", alpha=0.6, position = 'identity') +
  scale_fill_manual(values=c("#69b3a2", "#404080")) +
  theme_ipsum() +
  labs(fill="")
dev.off()

p.glsll250 <- OUTB10 %>%
  filter(FOREST_INS=="Spruce Budworm")%>%
  filter(BCRNAME == "LOWER GREAT LAKES/ ST. LAWRENCE PLAIN")%>%
  filter(FOREST_DAM == "Mortality")%>%
  filter(RecalcHa < 250)%>%
  ggplot( aes(x=RecalcHa, ..count../sum(..count..), fill=BCRNAME)) +
  geom_histogram( color="#e9ecef", alpha=0.6, position = 'identity', bins=4) +
  scale_fill_manual(values=c("#69b3a2", "#404080")) +
  theme_ipsum() +
  labs(fill="")

tiff('2_GIS outputs for ALCES Online/BUDWORM_GreatLakesStLawrencePlain_below250.tiff', units="in", width=12, height=8, res=300)
OUTB10 %>%
  filter(FOREST_INS=="Spruce Budworm")%>%
  filter(BCRNAME == "LOWER GREAT LAKES/ ST. LAWRENCE PLAIN")%>%
  filter(FOREST_DAM == "Mortality")%>%
  filter(RecalcHa < 250)%>%
  ggplot( aes(x=RecalcHa, ..count../sum(..count..), fill=BCRNAME)) +
  geom_histogram( color="#e9ecef", alpha=0.6, position = 'identity', bins=4) +
  scale_fill_manual(values=c("#69b3a2", "#404080")) +
  theme_ipsum() +
  labs(fill="")
dev.off()

#About 83 % of mortal outbreaks are 0-37.5 ha (Use 18.5 ha for size class)
#About 13 % of mortal outbreaks are 37.5-112.5 ha (Use 75 ha for size class)
#About 3 % of mortal outbreaks are 112.5-185 ha (Use 148 ha for size class)
#About 1 % of mortal outbreaks are 185-262.5 ha (Use 222 ha for size class)

