memory.limit(size=600000)
library(raster)
library(dismo)
library(rpart)
library(maptools)
library(data.table)
library(rgdal)
library(dplyr)
library(blockCV)
library(gbm)
library(sf)
library(sp)
library(cowplot)
library(automap)
library(ggplot2)
library(grid)
library(gridExtra)
# A function that fits the BRT model ('gbm.step' from dismo package) on pre-defined folds, and saves outputs ####
brt_blocks <- function(data = datcombo, pred.stack = pred_ontario, seed = 1222, pred.variables ,output.folder, blocks=NULL, keep.out = TRUE, tc=3,lr=0.001,bf=0.5, save.points.shp=FALSE){ 
  # Arguments for this function
  ## data: data.frame object containing data for model fitting
  ## pred.stack: the raster stack/brick used as prediction dataset
  ## pred.variables: a character vector giving the names of predictor variables that will be included in BRT models
  ## blocks: object resulting from 'spatialBlocks' function that contains classification of sample points into folds
  ## output.folder: path to output folder (if folder does not exist it is created)
  ## keep.out: logical, whether to keep the output in the workspace. both blocks object and the brt output are automatically saved in the output folder regardless
  ## tc: BRT tree complexity
  ## lr: BRT learning rate
  ## bf: BRT bag fraction
  ## save.points.shp: logical, whether to save survey points as a shapefile in output folder
  
  # fit BRT models using pre-determined folds for CV
  if (is.null(blocks)){
    folds<-NULL
    n.folds<-10
  }
  
  else {
    folds<-blocks$foldID
    n.folds<-blocks$k
  }
  
  x1 <-
    try(brt <-
          gbm.step(
            datcombo,
            gbm.y = "ABUND",
            gbm.x = pred.variables,
            fold.vector = folds,
            n.folds = n.folds,
            family = "poisson",
            tree.complexity = tc,
            learning.rate = lr,
            bag.fraction = bf,
            offset = datcombo$logoffset,
            site.weights = datcombo$wt,
            keep.fold.models = T,
            keep.fold.fit = T
          ))
  
  if(class(x1)=="NULL"){#retry models that didn't converge with smaller learning rate
    x1 <-
      try(brt <-
            gbm.step(
              datcombo,
              gbm.y = "ABUND",
              gbm.x = pred.variables,
              fold.vector = folds,
              n.folds = n.folds,
              family = "poisson",
              tree.complexity = tc,
              learning.rate = lr/10,
              bag.fraction = bf,
              offset = datcombo$logoffset,
              site.weights = datcombo$wt,
              keep.fold.models = T,
              keep.fold.fit = T
            ))
  }
  
  if(class(x1)=="NULL"){#retry models that didn't converge with smaller learning rate
    x1 <-
      try(brt <-
            gbm.step(
              datcombo,
              gbm.y = "ABUND",
              gbm.x = pred.variables,
              fold.vector = folds,
              n.folds = n.folds,
              family = "poisson",
              tree.complexity = tc,
              learning.rate = lr/100,
              bag.fraction = bf,
              offset = datcombo$logoffset,
              site.weights = datcombo$wt,
              keep.fold.models = T,
              keep.fold.fit = T
            ))
  }
  
  if(class(x1)=="NULL"){
    stop("Restart model with even smaller learning rate, or other predictors!")
  }
  
  # Define/create folders for storing outputs
  if (class(x1) != "try-error") {
    z <- output.folder
    
    if (file.exists(z) == FALSE) {
      dir.create(z)
    }
    
    if (is.null(blocks)){
      save(brt, file = paste(z, speclist[j], "brtAB.R", sep = ""))
    }
    
    else {
      save(blocks, file = paste(z, speclist[j], "blocks.R", sep = ""))
      save(brt, file = paste(z, speclist[j], "brtAB.R", sep = ""))
    }  
    
    
    ## Model evaluation
    varimp <- as.data.frame(brt$contributions)
    write.csv(varimp, file = paste(z, speclist[j], "varimp.csv", sep = ""))
    cvstats <- t(as.data.frame(brt$cv.statistics))
    write.csv(cvstats, file = paste(z, speclist[j], "cvstats.csv", sep =
                                      ""))
    pdf(paste(z, speclist[j], "_plot.pdf", sep = ""))
    gbm.plot(
      brt,
      n.plots = length(pred.variables),
      smooth = TRUE,
      plot.layout = c(3, 3),
      common.scale = T
    )
    dev.off()
    pdf(paste(z, speclist[j], "_plot.var-scale.pdf", sep = ""))
    gbm.plot(
      brt,
      n.plots = length(pred.variables),
      smooth = TRUE,
      plot.layout = c(3, 3),
      common.scale = F,
      write.title = F
    )
    dev.off()
    
    
    ## Model prediction
    
    rast <-
      predict(pred.stack,
              brt,
              type = "response",
              n.trees = brt$n.trees)
    writeRaster(
      rast,
      filename = paste(z, speclist[j], "_pred1km", sep = ""),
      format = "GTiff",
      overwrite = TRUE
    )
    
    data_sp <-SpatialPointsDataFrame(coords = data[, c("X","Y")], data = data, proj4string = LCC)
    png(paste(z, speclist[j], "_pred1km.png", sep = ""))
    plot(rast, zlim = c(0, 1))
    points(data_sp$X, data_sp$Y, cex = 0.05)
    dev.off()
    
    if(save.points.shp==T){
      writeOGR(
        data_sp,
        dsn = paste(z, "surveypoints.shp", sep = ""),
        layer = "data_sp",
        driver = "ESRI Shapefile"
      )
    }
    
    if(keep.out==T) {return(brt)}
  }
}

#As ALCES Online is not currently set up to model predictors at 250-m resolution,
#I am running one version of the "ALCES" BRT model using predictors at 250-m 
#resolution (ALCES 250 model), then a version using predictors resampled to a 
#resolution that is currently available in ALCES Online (200 m or maybe 500 m)

#ALCES 250 MODEL

#load data and prepare objects ####
load("0_data_for_BRT_models/processed/pointswithdataApril5_D.RData")
#contains SScombo.recombinedD (predictor variable values at 250-m resolution)
#and SScombo.recombinedE (predictor variable values at 200-m resolution)

#load raster brick as prediction stack. This raster brick can be
#omitted in favour of just using the point count data to create 
#training and test data folds for cross validatio, but will be
#necessary for predicting Wood Thrush distribution across the entire
#study area. Names in the predictor stack have to be exactly the 
#same as the variables used in the BRTs.

pred_ontario<-brick("0_data_for_BRT_models/processed/prediction rasters/Ontario/pred_ontario.grd")

LAEA<-CRS("+proj=aea +lat_0=40 +lon_0=-96 +lat_1=44.75 +lat_2=55.75 +x_0=0 +y_0=0 +a=6378137 +rf=298.257223999999 +units=m +no_defs")
LCC <- CRS("+proj=lcc +lat_1=49 +lat_2=77 +lat_0=0 +lon_0=-95 +x_0=0 +y_0=0 +datum=NAD83 +units=m +no_defs")
latlong <- CRS("+proj=longlat +datum=WGS84 +ellps=WGS84 +towgs84=0,0,0")


############################################################################
#                                                                          #
#                                                                          #
#                                                                          #
#       Excluding Exceedance From Predictors - ALCES 250 Model             #
#                                                                          #
#                                                                          #
#                                                                          #
############################################################################
#The selected scales model is the final model chosen for Landis scenarios
#To model Wood Thrush habitat availability in Ontario outside of Landis, we
#are using ALCES Online. ALCES Online scenarios do not model changes in biomass
#so the the ALCES Online model used in predicting Wood Thrush abundance based
#on future habitat differs from the selected scales model in not having biomass
#as a predictor. Other than that, the ALCES 250 model and selected scales model 
#have the same predictors and use the same potential data for analysis.

datcombo<-SScombo.recombinedD#start with observations where exceedance values are complete

speclist<-c("WOTH")
j<-which(speclist=="WOTH") 
datcombo$logoffset<-log(datcombo$offset)
datcombo$ABUND<-datcombo$spp

# convert data into SpatialPointDataFrame class
datcombo_sp <-SpatialPointsDataFrame(coords = datcombo[, c("X", "Y")], data = datcombo, proj4string = latlong)
#reproject in Lambert Conformal Conic
datcombo_sp<-spTransform(datcombo_sp, CRS=LCC)#

# create a column converting abundance to occupancy
datcombo_sp$OCCU <- 0 
datcombo_sp$OCCU[which(datcombo_sp$ABUND > 0)] <- 1

# Selected scales model ####
# list variables for selected scales model
pred.variables8<-c("decid.150m",
                   #"barren.150m",
                   #"conif.150m",
                   #"cult.150m",
                   #"grassland.150m",
                   #"mixed.150m",
                   #"orchard.150m",
                   #"shrub.150m",
                   #"urban.150m",
                   #"water.150m",
                   #"wetland.150m",
                   #"barren.250m",
                   #"conif.250m",
                   #"cult.250m",
                   #"decid.250m",
                   #"grassland.250m",
                   #"mixed.250m",
                   #"orchard.250m",
                   #"shrub.250m",
                   #"urban.250m",
                   #"water.250m",
                   #"wetland.250m", 
                   #"barren.1000m",
                   #"conif.1000m",
                   "cult.1000m",
                   #"decid.1000m",
                   "grassland.1000m",
                   #"mixed.1000m",
                   #"orchard.1000m",
                   #"shrub.1000m",
                   #"urban.1000m",
                   #"water.1000m",
                   #"wetland.1000m", 
                   "barren.2000m",
                   "conif.2000m",
                   #"cult.2000m",
                   #"decid.2000m",
                   #"grassland.2000m",
                   "mixed.2000m",
                   "orchard.2000m",
                   "shrub.2000m",
                   "urban.2000m",
                   "water.2000m",
                   "wetland.2000m",
                   #"Structure_Biomass_Branch.local",              
                   #"Structure_Biomass_Foliage.local",             
                   #"Structure_Biomass_StemBark.local",            
                   #"Structure_Biomass_StemWood.local",            
                   #"Structure_Biomass_TotalDead.local",  
                   #"Structure_Stand_Age.local",
                   #"Structure_Biomass_TotalLiveAboveGround.local",
                   #"Structure_Biomass_Branch.250m",              
                   #"Structure_Biomass_Foliage.250m",             
                   #"Structure_Biomass_StemBark.250m",            
                   #"Structure_Biomass_StemWood.250m",            
                   #"Structure_Biomass_TotalDead.250m",  
                   #"Structure_Stand_Age.250m",
                   #"Structure_Biomass_TotalLiveAboveGround.250m",
                   #"Structure_Biomass_Branch.1000m",              
                   #"Structure_Biomass_Foliage.1000m",             
                   #"Structure_Biomass_StemBark.1000m",            
                   #"Structure_Biomass_StemWood.1000m",            
                   #"Structure_Biomass_TotalDead.1000m", 
                   #"TotalBiomass.1000m",
                   #"Structure_Stand_Age.1000m",
                   #"Structure_Biomass_TotalLiveAboveGround.1000m",
                   #"Structure_Biomass_Branch.2000m",              
                   #"Structure_Biomass_Foliage.2000m",             
                   #"Structure_Biomass_StemBark.2000m",            
                   #"Structure_Biomass_StemWood.2000m",            
                   #"Structure_Biomass_TotalDead.2000m",  
                   "Structure_Stand_Age.2000m",
                   #"Structure_Biomass_TotalLiveAboveGround.2000m",
                   "Roadside150",
                   "MajorRoad150",
                   "elev",
                   "slope",
                   "TPI",
                   "TRI",
                   "swamp.150m")#,"swamp.250m","swamp.1000m","swamp.2000m")

# create object storing the indices of predictor layers (from the prediction dataset) for the autocorrelation assessment that will inform block size. Only include continuous numeric variables here. Can use indexing "[-c(x:y)] to exclude them (e.g. exclude climate variables, etc).
ind8 <- which(names(pred_ontario) %in% pred.variables8)

# Calculate autocorrelation range: using just one of the four province for now
#See if I can create a mosaic raster brick
#Note: normally
start_time <- Sys.time()
sp.auto.arr1 <- spatialAutoRange(pred_ontario[[ind8]])
end_time <- Sys.time()
end_time - start_time#Time difference of 12.0884 mins

# Use spatial blocks to separate train and test folds
start_time <- Sys.time()
set.seed(123)
sp_block_selected <-  spatialBlock(
  speciesData = datcombo_sp,
  species = "OCCU",
  rasterLayer = NULL,
  iteration = 250,
  theRange = sp.auto.arr1$range,
  selection = "random",
  maskBySpecies = FALSE
)
end_time <- Sys.time()
end_time - start_time#Time difference of 7.135354 hours

save(sp.auto.arr1, sp_block_selected, file="4_BRT_outputs/alces_250_model/spautoarr1andblocks.RData")

start_time<-Sys.time()
#the selected scales BRT (brt6) that was selected for use with the Landis scenarios
#provided the predictors that were run for the model used to get predictions
#from the ALCES Online scenario...except for biomass
#The same predictors were run in the alces_250 model and the alces_200 model

brt6<- brt_blocks(data=datcombo, pred.variables = pred.variables8, output.folder = "4_BRT_outputs/alces_250_model/", blocks=sp_block_selected, save.points.shp = TRUE, lr=0.01)  
#fitting final gbm model with a fixed number of 400 trees for NA
#mean total deviance = 5.204 
#mean residual deviance = 3.955 
#estimated cv deviance = 5.199 ; se = 1.796 
#training data correlation = 0.372 
#cv correlation =  0.207 ; se = 0.036 

#elapsed time -  0.44 minutes 
end_time<-Sys.time()
end_time-start_time
#Time difference of 36.28599 mins

save(brt6, file="4_BRT_outputs/alces_250_model/brt6.RData")

rast4 <-
  predict(pred_ontario,
          brt6,
          type = "response",
          n.trees = brt6$n.trees)
plot(rast4)
writeRaster(rast4, file="4_BRT_outputs/alces_250_model/pred_250m_ontario.tif", overwrite=TRUE)

#ALCES 200 MODEL

#load data and prepare objects ####
load("0_data_for_BRT_models/processed/pointswithdataMay29_200_m_res_D.RData")

#load raster brick as prediction stack. This raster brick can be
#omitted in favour of just using the point count data to create 
#training and test data folds for cross validatio, but will be
#necessary for predicting Wood Thrush distribution across the entire
#study area. Names in the predictor stack have to be exactly the 
#same as the variables used in the BRTs.

pred_ontario<-brick("0_data_for_BRT_models/processed/prediction rasters/Ontario/pred_ontario.grd")
#E:/CWS Wood Thrush Contract/CHID-Regionalmodel/
LAEA<-CRS("+proj=aea +lat_0=40 +lon_0=-96 +lat_1=44.75 +lat_2=55.75 +x_0=0 +y_0=0 +a=6378137 +rf=298.257223999999 +units=m +no_defs")
LCC <- CRS("+proj=lcc +lat_1=49 +lat_2=77 +lat_0=0 +lon_0=-95 +x_0=0 +y_0=0 +datum=NAD83 +units=m +no_defs")
latlong <- CRS("+proj=longlat +datum=WGS84 +ellps=WGS84 +towgs84=0,0,0")


############################################################################
#                                                                          #
#                                                                          #
#                                                                          #
#       Excluding Exceedance From Predictors - ALCES 200 Model             #
#                                                                          #
#                                                                          #
#                                                                          #
############################################################################
#The selected scales model is the final model chosen for Landis scenarios
#To model Wood Thrush habitat availability in Ontario outside of Landis, we
#are using ALCES Online. ALCES Online scenarios do not model changes in biomass
#so the the ALCES Online model used in predicting Wood Thrush abundance based
#on future habitat differs from the selected scales model in not having biomass
#as a predictor. Other than that, the ALCES 250 model and selected scales model 
#have the same predictors and use the same potential data for analysis.

datcombo<-SScombo.recombinedD_200m_res#start with observations where exceedance values are complete

speclist<-c("WOTH")
j<-which(speclist=="WOTH") 
datcombo$logoffset<-log(datcombo$offset)
datcombo$ABUND<-datcombo$spp

# convert data into SpatialPointDataFrame class
datcombo_sp <-SpatialPointsDataFrame(coords = datcombo[, c("X", "Y")], data = datcombo, proj4string = latlong)
#reproject in Lambert Conformal Conic
datcombo_sp<-spTransform(datcombo_sp, CRS=LCC)#

# create a column converting abundance to occupancy
datcombo_sp$OCCU <- 0 
datcombo_sp$OCCU[which(datcombo_sp$ABUND > 0)] <- 1

# Selected scales model ####
# list variables for selected scales model
pred.variables.alces200<-c("decid.150m",
                   #"barren.150m",
                   #"conif.150m",
                   #"cult.150m",
                   #"grassland.150m",
                   #"mixed.150m",
                   #"orchard.150m",
                   #"shrub.150m",
                   #"urban.150m",
                   #"water.150m",
                   #"wetland.150m",
                   #"barren.250m",
                   #"conif.250m",
                   #"cult.250m",
                   #"decid.250m",
                   #"grassland.250m",
                   #"mixed.250m",
                   #"orchard.250m",
                   #"shrub.250m",
                   #"urban.250m",
                   #"water.250m",
                   #"wetland.250m", 
                   #"barren.1000m",
                   #"conif.1000m",
                   "cult.1000m",
                   #"decid.1000m",
                   "grassland.1000m",
                   #"mixed.1000m",
                   #"orchard.1000m",
                   #"shrub.1000m",
                   #"urban.1000m",
                   #"water.1000m",
                   #"wetland.1000m", 
                   "barren.2000m",
                   "conif.2000m",
                   #"cult.2000m",
                   #"decid.2000m",
                   #"grassland.2000m",
                   "mixed.2000m",
                   "orchard.2000m",
                   "shrub.2000m",
                   "urban.2000m",
                   "water.2000m",
                   "wetland.2000m",
                   #"Structure_Biomass_Branch.local",              
                   #"Structure_Biomass_Foliage.local",             
                   #"Structure_Biomass_StemBark.local",            
                   #"Structure_Biomass_StemWood.local",            
                   #"Structure_Biomass_TotalDead.local",  
                   #"Structure_Stand_Age.local",
                   #"Structure_Biomass_TotalLiveAboveGround.local",
                   #"Structure_Biomass_Branch.250m",              
                   #"Structure_Biomass_Foliage.250m",             
                   #"Structure_Biomass_StemBark.250m",            
                   #"Structure_Biomass_StemWood.250m",            
                   #"Structure_Biomass_TotalDead.250m",  
                   #"Structure_Stand_Age.250m",
                   #"Structure_Biomass_TotalLiveAboveGround.250m",
                   #"Structure_Biomass_Branch.1000m",              
                   #"Structure_Biomass_Foliage.1000m",             
                   #"Structure_Biomass_StemBark.1000m",            
                   #"Structure_Biomass_StemWood.1000m",            
                   #"Structure_Biomass_TotalDead.1000m", 
                   #"TotalBiomass.1000m",
                   #"Structure_Stand_Age.1000m",
                   #"Structure_Biomass_TotalLiveAboveGround.1000m",
                   #"Structure_Biomass_Branch.2000m",              
                   #"Structure_Biomass_Foliage.2000m",             
                   #"Structure_Biomass_StemBark.2000m",            
                   #"Structure_Biomass_StemWood.2000m",            
                   #"Structure_Biomass_TotalDead.2000m",  
                   "Structure_Stand_Age.2000m",
                   #"Structure_Biomass_TotalLiveAboveGround.2000m",
                   "Roadside150",
                   "MajorRoad150",
                   "elev",
                   "slope",
                   "TPI",
                   "TRI",
                   "swamp.150m")#,"swamp.250m","swamp.1000m","swamp.2000m")

# create object storing the indices of predictor layers (from the prediction dataset) for the autocorrelation assessment that will inform block size. Only include continuous numeric variables here. Can use indexing "[-c(x:y)] to exclude them (e.g. exclude climate variables, etc).
ind.alces200 <- which(names(pred_ontario) %in% pred.variables.alces200)

# Calculate autocorrelation range: using just one of the four province for now
#See if I can create a mosaic raster brick
#Note: normally
start_time <- Sys.time()
sp.auto.arr1 <- spatialAutoRange(pred_ontario[[ind.alces200]])
end_time <- Sys.time()
end_time - start_time#Time difference of 12.0884 mins

# Use spatial blocks to separate train and test folds
start_time <- Sys.time()
set.seed(123)
sp_block_selected <-  spatialBlock(
  speciesData = datcombo_sp,
  species = "OCCU",
  rasterLayer = NULL,
  iteration = 250,
  theRange = sp.auto.arr1$range,
  selection = "random",
  maskBySpecies = FALSE
)
end_time <- Sys.time()
end_time - start_time#Time difference of 7.135354 hours

save(sp.auto.arr1, sp_block_selected, file="4_BRT_outputs/alces_200_model/spautoarr1andblocks.RData")

datcombo$Structure_Stand_Age.2000m<-datcombo$Structure_Stand_Age_2000m
datcombo$Structure_Stand_Age_2000m<-NULL
start_time<-Sys.time()
brt_alces200<- brt_blocks(data=datcombo, pred.variables = pred.variables.alces200, output.folder = "4_BRT_outputs/alces_200_model/", blocks=sp_block_selected, save.points.shp = TRUE, lr=0.01)  
#fitting final gbm model with a fixed number of 3150 trees for NA
#mean total deviance = 5.204 
#mean residual deviance = 3.392 
#estimated cv deviance = 5.101 ; se = 1.887 
#training data correlation = 0.467 
#cv correlation =  0.225 ; se = 0.038 
#elapsed time -  0.04 minutes  
end_time<-Sys.time()
end_time-start_time
#Time difference of 2.902881 hours

save(brt_alces200, file="4_BRT_outputs/alces_200_model/brt_alces200.RData")

rast4 <-
  predict(pred_ontario,
          brt_alces200,
          type = "response",
          n.trees = brt_alces200$n.trees)
plot(rast4)
writeRaster(rast4, file="4_BRT_outputs/alces_200_model/pred_200m_ontario.tif", overwrite=TRUE)

#examine the data points to look at the blocks they're assigned to
shp <- st_read("4_BRT_outputs/alces_200_model/surveypoints.shp")
names(shp)#since it's a shapefile, variable names have been truncated
nrow(shp)#316241
#no block assignments seen

load("4_BRT_outputs/alces_200_model/spautoarr1andblocks.RData")
load("4_BRT_outputs/alces_200_model/WOTHblocks.R")
load("4_BRT_outputs/alces_200_model/brt_alces200.RData")
#try to extract the most important interactions in this BRT

find.int <- gbm.interactions(brt_alces200)
find.int$rank.list#these are interactions with largest effects
#    var1.index                var1.names var2.index                var2.names int.size
# 1          19                swamp.150m         12 Structure_Stand_Age.2000m    17.59
# 2          13               Roadside150         12 Structure_Stand_Age.2000m    15.10
# 3          13               Roadside150          1                decid.150m    12.20
# 4          13               Roadside150          2                cult.1000m    10.04
# 5          12 Structure_Stand_Age.2000m          6               mixed.2000m     9.44
# 6          12 Structure_Stand_Age.2000m          1                decid.150m     7.11
# 7          16                     slope         15                      elev     7.10
# 8          19                swamp.150m          2                cult.1000m     5.63
# 9          15                      elev         12 Structure_Stand_Age.2000m     5.00
# 10         17                       TPI         10               water.2000m     4.02
# 11         10               water.2000m          1                decid.150m     3.00
# 12         15                      elev         13               Roadside150     2.57
# 13         19                swamp.150m          1                decid.150m     2.26
# 14         15                      elev          6               mixed.2000m     1.74
# 15         19                swamp.150m         15                      elev     1.48
# 16         13               Roadside150          8               shrub.2000m     1.47
# 17         15                      elev          5               conif.2000m     1.25
# 18         12 Structure_Stand_Age.2000m          8               shrub.2000m     1.20

I.1<-gbm.perspec(brt_alces200, 19, 12)
#plot interaction of swamp.150m X Structure_Stand_age.2000m
I.2<-gbm.perspec(brt_alces200, 13, 12)
#plot interaction of Roadside150 X Structure_Stand_age.2000m
I.3<-gbm.perspec(brt_alces200, 13, 1)
#plot interaction of Roadside150 X decid.150m
I.4<-gbm.perspec(brt_alces200, 13, 2)
#plot interaction of Roadside150 X cult.1000m
I.5<-gbm.perspec(brt_alces200, 12, 6)
I.6<-gbm.perspec(brt_alces200, 12, 1)

############################################################################
#                                                                          #
#                                                                          #
#                                                                          #
#       Compare Predictive Accuracy - ALCES 200 vs. ALCES 250 Model        #
#                                                                          #
#                                                                          #
#                                                                          #
############################################################################

library(ggplot2)
library(grid)
library(gridExtra)
load("4_BRT_outputs/alces_200_model/brt_alces200.RData")
load("4_BRT_outputs/alces_250_model/brt6.RData")

# Model deviance
df<- data.frame(grp=c("ALCES 200", "ALCES 250"),
                deviance=c(brt_alces200$cv.statistics$deviance.mean,
                           brt6$cv.statistics$deviance.mean),
                se=c(brt_alces200$cv.statistics$deviance.se,
                     brt6$cv.statistics$deviance.se)
)
k1<-ggplot(df, aes(grp,deviance,ymin=deviance-se,ymax=deviance+se))+
  geom_pointrange()+ylab("Deviance")

tiff('4_BRT_outputs/BRTdeviancesALCES.tiff', units="in", width=12, height=8, res=300)
k1
dev.off()

# correlation
df2<- data.frame(grp=c("ALCES 200", "ALCES 250"),
                 correlation=c(brt_alces200$cv.statistics$correlation.mean,
                               brt6$cv.statistics$correlation.mean),
                 se=c(brt_alces200$cv.statistics$correlation.se,
                      brt6$cv.statistics$correlation.se)
)
df2$LCL<-df2$correlation-1.96*df2$se
df2$UCL<-df2$correlation+1.96*df2$se
k2<-ggplot(df2, aes(grp,correlation,ymin=correlation-se,ymax=correlation+se))+
  geom_pointrange()+ylab("Cross-validation correlation")

tiff('4_BRT_outputs/BRT.CVcorrelation.tiff', units="in", width=12, height=8, res=300)
k2
dev.off()

# Calibration:  The estimated intercepts and slopes of linear regression models of predictions against observations. The intercept measures the magnitude and direction of bias, with values close to 0 indicating low or no bias. 
#The slope yields information about the consistency in the bias as a function of the mean, with a value of 1 indicating a consistent bias if the intercept is a nonzero value.
## intercept
df3<- data.frame(grp=c("ALCES 200", "ALCES 250"),
                 calibration.intercept=c(brt_alces200$cv.statistics$calibration.mean[1],
                                         brt6$cv.statistics$calibration.mean[1]),
                 se=c(brt_alces200$cv.statistics$calibration.se[1],
                      brt6$cv.statistics$calibration.se[1])
)
df3$LCL<-df3$calibration.intercept-1.96*df3$se
df3$UCL<-df3$calibration.intercept+1.96*df3$se
k3<-ggplot(df3, aes(grp,calibration.intercept,ymin=calibration.intercept-se,ymax=calibration.intercept+se))+
  geom_pointrange()+ylab("Calibration intercept")

tiff('4_BRT_outputs/BRT.calibrationintercept.tiff', units="in", width=12, height=8, res=300)
k3
dev.off()

## slope
df4<- data.frame(grp=c("ALCES 200", "ALCES 250"),
                 calibration.slope=c(brt_alces200$cv.statistics$calibration.mean[2],
                                     brt6$cv.statistics$calibration.mean[2]),
                 se=c(brt_alces200$cv.statistics$calibration.se[2],
                      brt6$cv.statistics$calibration.se[2])
)
df4$LCL<-df4$calibration.slope-1.96*df4$se
df4$UCL<-df4$calibration.slope+1.96*df4$se
k4<-ggplot(df4, aes(grp,calibration.slope,ymin=calibration.slope-se,ymax=calibration.slope+se))+
  geom_pointrange()+ylab("Calibration slope")

tiff('4_BRT_outputs/BRT.calibrationslope.tiff', units="in", width=12, height=8, res=300)
k4
dev.off()

tiff('4_BRT_outputs/BRT.comparemodels.multipanel.tiff', units="in", width=12, height=8, res=300)
grid.arrange(k1,k2,k3,k4, nrow=2, ncol=2)
dev.off()
#Selected scales BRT appears best in terms of CV correlation and calibration



############################################################################
#                                                                          #
#                                                                          #
#                                                                          #
#       Get confidence intervals for model predictions from an area        #
#                                                                          #
#                                                                          #
#                                                                          #
############################################################################
memory.limit(size=56000)
library(raster)
library(dismo)
library(rpart)
library(maptools)
library(data.table)
library(rgdal)
library(dplyr)
library(blockCV)
library(gbm)
library(sf)
library(sp)
library(cowplot)
library(automap)
library(ggplot2)
library(grid)
library(gridExtra)
#sample data
load("0_data_for_BRT_models/processed/pointswithdataMay29_200_m_res_D.RData")
datcombo<-SScombo.recombinedD_200m_res#start with observations where exceedance values are complete
speclist<-c("WOTH")
j<-which(speclist=="WOTH") 
datcombo$logoffset<-log(datcombo$offset)
datcombo$ABUND<-datcombo$spp

#We'll use brt_alces200 and Ontario for predictions
load("4_BRT_outputs/alces_200_model/spautoarr1andblocks.RData")
load("4_BRT_outputs/alces_200_model/brt_alces200.RData")
pred_ontario<-brick("0_data_for_BRT_models/processed/prediction rasters/Ontario/pred_ontario.grd")
#E:/CWS Wood Thrush Contract/CHID-Regionalmodel/
rm(list=setdiff(ls(),c("datcombo","sp_block_selected","pred_ontario","blockCV_brt","brt_alces200")))
gc()
# A function to obtain confidence intervals of model predictions ####

# First, get and save the BRT resamples. 
#The resampling was originally done within a boot_brt function that
#could be applied to any BRT model. However, the function takes a long
#time and a lot of memory to run, and if the function fails for any reason,
#all resamples are lost. So I've taken the code out of the function and
#save each resample to disk one by one so that not all work is lost.
#That way, if the system crashes you don't lose everyting.

data=datcombo
brtmodel=brt_alces200
blocks=sp_block_selected
pred.data=pred_ontario
nsamples=250
output.folder = "4_BRT_outputs/alces_200_model/pred_CI"
  
  
z <- output.folder
  
if (file.exists(z) == FALSE) {
    dir.create(z)
}
  
for(i in 1:nsamples){
    
    
  cat("loop",i,"\n") # this prints the loop number on console to track function progress
    
  brt <- NULL#added April 16
  attempt <- 0#added April 16
  while( is.null(brt) && attempt <= 20 ) {#added April 16
    attempt <- attempt + 1#added April 16
      
    sample<-sample(1:nrow(data),size=nrow(data),replace=T)
    data2<-data[sample,]
      
    try(brt <-
         gbm.step(
            data = data2,
            gbm.y = brtmodel$gbm.call$gbm.y,
            gbm.x = brtmodel$gbm.call$gbm.x,
            fold.vector = blocks$foldID[sample],
            n.folds = brtmodel$gbm.call$cv.folds,
            family = brtmodel$gbm.call$family,
            tree.complexity = brtmodel$gbm.call$tree.complexity,
            learning.rate = brtmodel$gbm.call$learning.rate,
            bag.fraction = brtmodel$gbm.call$bag.fraction,
            offset = brtmodel$gbm.call$offset[sample],
            site.weights = data2$wt
          ))
  }#added April 16
    
  saveRDS(brt, file=paste0(z,"bootstrap_model",i,".R"))
    
    
}
  
#Now get the predictions from each time step and simulation run of
#the ALCES Online Baseline Scenario

#Year 0 (2010, but actually 2020) - Simulation Run 1
#Predicted density + uncertainty for southern Ontario


brtmodel=readRDS("4_BRT_outputs/alces_200_model/pred_CI/bootstrap_model1.R")

pred_ontario<-brick("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/pred_on_AO2010.1.grd")
pred.data=pred_ontario
nsamples=250
output.folder = "4_BRT_outputs/alces_200_model/pred_CI"

rast <-  predict(pred.data,
                 brtmodel,
                 type = "response",
                 n.trees = brtmodel$n.trees)

stack1<-stack(rast)
names(stack1)[1]<-"model estimate"

z <- output.folder


for(i in 1:nsamples){
  
  cat("loop",i,"\n") # this prints the loop number on console to track function progress
  
  brt=readRDS(paste0("4_BRT_outputs/alces_200_model/pred_CI/bootstrap_model",i,".R"))
  
  rast <- predict(pred.data,
                  brt,
                  type = "response",
                  n.trees = brt$n.trees)
  
  stack1 <- addLayer(stack1, rast)
  names(stack1)[i+1]<-paste0("sample",i)
  
}

#ran out of memory after loop 137
rm(data, datcombo, brt_alces200, data2)
gc()

writeRaster(stack1[[1:50]], filename=paste0(z, "/WOTH Predictions/Year 2010 Simulation 1/samples_OntarioA.grd"), format="raster",overwrite=TRUE)
writeRaster(stack1[[51:60]], filename=paste0(z, "/WOTH Predictions/Year 2010 Simulation 1/samples_OntarioA2.grd"), format="raster",overwrite=TRUE)
writeRaster(stack1[[61:100]], filename=paste0(z, "/WOTH Predictions/Year 2010 Simulation 1/samples_OntarioB.grd"), format="raster",overwrite=TRUE)
writeRaster(stack1[[101:137]], filename=paste0(z, "/WOTH Predictions/Year 2010 Simulation 1/samples_OntarioC.grd"), format="raster",overwrite=TRUE)

stack1<-stack(rast)
names(stack1)[1]<-"model estimate"

for(i in 138:nsamples){
  
  cat("loop",i,"\n") # this prints the loop number on console to track function progress
  
  brt=readRDS(paste0("4_BRT_outputs/alces_200_model/pred_CI/bootstrap_model",i,".R"))
  
  rast <- predict(pred.data,
                  brt,
                  type = "response",
                  n.trees = brt$n.trees)
  
  stack1 <- addLayer(stack1, rast)
  #names(stack1)[i+1]<-paste0("sample",i)
  #Otherwise, Error in `names<-`(`*tmp*`, value = `*vtmp*`) : 
  #incorrect number of layer names
  
}

writeRaster(stack1[[2:51]], filename=paste0(z, "/WOTH Predictions/Year 2010 Simulation 1/samples_OntarioD.grd"), format="raster",overwrite=TRUE)
#corresponds with samples 138:188
writeRaster(stack1[[52:101]], filename=paste0(z, "/WOTH Predictions/Year 2010 Simulation 1/samples_OntarioE.grd"), format="raster",overwrite=TRUE)
#corresponds with samples 189:240
writeRaster(stack1[[102:114]], filename=paste0(z, "/WOTH Predictions/Year 2010 Simulation 1/samples_OntarioF.grd"), format="raster",overwrite=TRUE)
#corresponds with final 13

rm(brtmodel,pred_ontario,sp_block_selected,pred.data)
gc()

stackA<-brick(paste0(z, "/WOTH Predictions/Year 2010 Simulation 1/samples_OntarioA.grd"))
stackA<-stackA[[-1]]
stackB<-brick(paste0(z, "/WOTH Predictions/Year 2010 Simulation 1/samples_OntarioA2.grd"))
stackC<-brick(paste0(z, "/WOTH Predictions/Year 2010 Simulation 1/samples_OntarioB.grd"))
stackD<-brick(paste0(z, "/WOTH Predictions/Year 2010 Simulation 1/samples_OntarioC.grd"))
stackE<-stack1[[-1]]

stack1<-stack(stackA,stackB,stackC,stackD,stackE)

#dropped the [[-1]]
fun0.05 <- function(x) {quantile(x, probs = 0.05, na.rm = TRUE)}
lower<- calc(stack1,fun0.05)
fun0.95 <- function(x) {quantile(x, probs = 0.95, na.rm = TRUE)}
upper<- calc(stack1,fun0.95)
meanDens<-mean(stack1, na.rm = TRUE)
fun0.50 <- function(x) {quantile(x, probs = 0.50, na.rm = TRUE)}
medianDens<-calc(stack1, fun0.50)
fun0.sd <- function(x) {sd(x, na.rm = TRUE)}
sdDens<-calc(stack1, fun0.sd)

writeRaster(meanDens, filename=paste0(z, "/WOTH Predictions/Year 2010 Simulation 1/mean_WOTH_Ontario.tif"), format="GTiff",overwrite=TRUE)
writeRaster(lower, filename=paste0(z, "/WOTH Predictions/Year 2010 Simulation 1/confint_lower_Ontario.tif"), format="GTiff",overwrite=TRUE)
writeRaster(upper, filename=paste0(z, "/WOTH Predictions/Year 2010 Simulation 1/confint_upper_Ontario.tif"), format="GTiff",overwrite=TRUE)
writeRaster(medianDens, filename=paste0(z, "/WOTH Predictions/Year 2010 Simulation 1/median_WOTH_Ontario.tif"), format="GTiff",overwrite=TRUE)
writeRaster(sdDens, filename=paste0(z, "/WOTH Predictions/Year 2010 Simulation 1/sd_WOTH_Ontario.tif"), format="GTiff",overwrite=TRUE)

rm(stackA, stackB, stackC, stackD, stackE, stack1, rast, meanDens, sdDens, lower, upper, medianDens)
gc()

#Year 10 (2020, but actually 2030) - Simulation Run 1
#Predicted density + uncertainty for southern Ontario
#Restart
library(raster)
library(dismo)
library(rpart)
library(maptools)
library(data.table)
library(rgdal)
library(dplyr)
library(blockCV)
library(gbm)
library(sf)
library(sp)

brtmodel=readRDS("4_BRT_outputs/alces_200_model/pred_CI/bootstrap_model1.R")

pred_ontario<-brick("3_ALCES Online Outputs/Predictor Stacks/Year 2020 Simulation 1/pred_on_AO2020.1.grd")
pred.data=pred_ontario
nsamples=250
output.folder = "4_BRT_outputs/alces_200_model/pred_CI"
rm(pred_ontario)
gc()
rast <-  predict(pred.data,
                 brtmodel,
                 type = "response",
                 n.trees = brtmodel$n.trees)

stack1<-stack(rast)
names(stack1)[1]<-"model estimate"

z <- output.folder


for(i in 1:nsamples){
  
  cat("loop",i,"\n") # this prints the loop number on console to track function progress
  
  brt=readRDS(paste0("4_BRT_outputs/alces_200_model/pred_CI/bootstrap_model",i,".R"))
  
  rast <- predict(pred.data,
                  brt,
                  type = "response",
                  n.trees = brt$n.trees)
  
  stack1 <- addLayer(stack1, rast)
  names(stack1)[i+1]<-paste0("sample",i)
  
}#ran out of memory after loop 238
rm(brt, pred_ontario)
gc()
writeRaster(stack1[[1:50]], filename=paste0(z, "/WOTH Predictions/Year 2020 Simulation 1/samples_OntarioA.grd"), format="raster",overwrite=TRUE)
writeRaster(stack1[[51:100]], filename=paste0(z, "/WOTH Predictions/Year 2020 Simulation 1/samples_OntarioB.grd"), format="raster",overwrite=TRUE)
writeRaster(stack1[[101:150]], filename=paste0(z, "/WOTH Predictions/Year 2020 Simulation 1/samples_OntarioC.grd"), format="raster",overwrite=TRUE)
writeRaster(stack1[[151:200]], filename=paste0(z, "/WOTH Predictions/Year 2020 Simulation 1/samples_OntarioD.grd"), format="raster",overwrite=TRUE)
rm(brt,brtmodel)
gc()
writeRaster(stack1[[201:238]], filename=paste0(z, "/WOTH Predictions/Year 2020 Simulation 1/samples_OntarioE.grd"), format="raster",overwrite=TRUE)

stack1<-stack(rast)
names(stack1)[1]<-"model estimate"

for(i in 239:nsamples){
  
  cat("loop",i,"\n") # this prints the loop number on console to track function progress
  
  brt=readRDS(paste0("4_BRT_outputs/alces_200_model/pred_CI/bootstrap_model",i,".R"))
  
  rast <- predict(pred.data,
                  brt,
                  type = "response",
                  n.trees = brt$n.trees)
  
  stack1 <- addLayer(stack1, rast)
  #names(stack1)[i+1]<-paste0("sample",i)
  #Otherwise, Error in `names<-`(`*tmp*`, value = `*vtmp*`) : 
  #incorrect number of layer names
  
}

writeRaster(stack1[[2:13]], filename=paste0(z, "/WOTH Predictions/Year 2020 Simulation 1/samples_OntarioF.grd"), format="raster",overwrite=TRUE)
#for loops 239-250, the final 12 predictions
rm(pred.data, brt, stack1)

stackA<-brick(paste0(z, "/WOTH Predictions/Year 2020 Simulation 1/samples_OntarioA.grd"))
stackA<-stackA[[-1]]
stackB<-brick(paste0(z, "/WOTH Predictions/Year 2020 Simulation 1/samples_OntarioB.grd"))
stackC<-brick(paste0(z, "/WOTH Predictions/Year 2020 Simulation 1/samples_OntarioC.grd"))
stackD<-brick(paste0(z, "/WOTH Predictions/Year 2020 Simulation 1/samples_OntarioD.grd"))
stackE<-brick(paste0(z, "/WOTH Predictions/Year 2020 Simulation 1/samples_OntarioE.grd"))
stackF<-brick(paste0(z, "/WOTH Predictions/Year 2020 Simulation 1/samples_OntarioF.grd"))

stack1<-stack(stackA,stackB,stackC,stackD,stackE,stackF)

#dropped the [[-1]]
fun0.05 <- function(x) {quantile(x, probs = 0.05, na.rm = TRUE)}
lower<- calc(stack1,fun0.05)
fun0.95 <- function(x) {quantile(x, probs = 0.95, na.rm = TRUE)}
upper<- calc(stack1,fun0.95)
meanDens<-mean(stack1, na.rm = TRUE)
fun0.50 <- function(x) {quantile(x, probs = 0.50, na.rm = TRUE)}
medianDens<-calc(stack1, fun0.50)
fun0.sd <- function(x) {sd(x, na.rm = TRUE)}
sdDens<-calc(stack1, fun0.sd)

writeRaster(meanDens, filename=paste0(z, "/WOTH Predictions/Year 2020 Simulation 1/mean_WOTH_Ontario.tif"), format="GTiff",overwrite=TRUE)
writeRaster(lower, filename=paste0(z, "/WOTH Predictions/Year 2020 Simulation 1/confint_lower_Ontario.tif"), format="GTiff",overwrite=TRUE)
writeRaster(upper, filename=paste0(z, "/WOTH Predictions/Year 2020 Simulation 1/confint_upper_Ontario.tif"), format="GTiff",overwrite=TRUE)
writeRaster(medianDens, filename=paste0(z, "/WOTH Predictions/Year 2020 Simulation 1/median_WOTH_Ontario.tif"), format="GTiff",overwrite=TRUE)
writeRaster(sdDens, filename=paste0(z, "/WOTH Predictions/Year 2020 Simulation 1/sd_WOTH_Ontario.tif"), format="GTiff",overwrite=TRUE)

rm(brt, lower, meanDens, medianDens, pred.data, rast, sdDens, stack1, stackA, stackB, stackC, stackD, stackE, stackF, upper)
gc()

#Year 20 (2030, but actually 2040) - Simulation Run 1
#Predicted density + uncertainty for southern Ontario
#Restart

brtmodel=readRDS("4_BRT_outputs/alces_200_model/pred_CI/bootstrap_model1.R")

pred_ontario<-brick("3_ALCES Online Outputs/Predictor Stacks/Year 2030 Simulation 1/pred_on_AO2030.1.grd")
pred.data=pred_ontario
nsamples=250
output.folder = "4_BRT_outputs/alces_200_model/pred_CI"
rm(pred_ontario)
gc()
rast <-  predict(pred.data,
                 brtmodel,
                 type = "response",
                 n.trees = brtmodel$n.trees)

stack1<-stack(rast)
names(stack1)[1]<-"model estimate"

z <- output.folder

rm(brtmodel)
gc()
for(i in 1:nsamples){
  
  cat("loop",i,"\n") # this prints the loop number on console to track function progress
  
  brt=readRDS(paste0("4_BRT_outputs/alces_200_model/pred_CI/bootstrap_model",i,".R"))
  
  rast <- predict(pred.data,
                  brt,
                  type = "response",
                  n.trees = brt$n.trees)
  
  stack1 <- addLayer(stack1, rast)
  names(stack1)[i+1]<-paste0("sample",i)
  
}#memory ran out after loop 177
rm(brt)
gc()
writeRaster(stack1[[1:50]], filename=paste0(z, "/WOTH Predictions/Year 2030 Simulation 1/samples_OntarioA.grd"), format="raster",overwrite=TRUE)
#not enough memory
writeRaster(stack1[[51:100]], filename=paste0(z, "/WOTH Predictions/Year 2030 Simulation 1/samples_OntarioB.grd"), format="raster",overwrite=TRUE)
#not enough memory
writeRaster(stack1[[101:150]], filename=paste0(z, "/WOTH Predictions/Year 2030 Simulation 1/samples_OntarioC.grd"), format="raster",overwrite=TRUE)
#not enough memory
writeRaster(stack1[[151:177]], filename=paste0(z, "/WOTH Predictions/Year 2030 Simulation 1/samples_OntarioD.grd"), format="raster",overwrite=TRUE)
#not enough memory
stack1<-dropLayer(stack1, 151:177)
stack1<-dropLayer(stack1, 101:150)
gc()
writeRaster(stack1[[1:50]], filename=paste0(z, "/WOTH Predictions/Year 2030 Simulation 1/samples_OntarioA.grd"), format="raster",overwrite=TRUE)
#success
writeRaster(stack1[[51:100]], filename=paste0(z, "/WOTH Predictions/Year 2030 Simulation 1/samples_OntarioB.grd"), format="raster",overwrite=TRUE)
#success, but now I have to restart from loop 101

stack1<-stack(rast)
names(stack1)[1]<-"model estimate"

for(i in 101:nsamples){
  
  cat("loop",i,"\n") # this prints the loop number on console to track function progress
  
  brt=readRDS(paste0("4_BRT_outputs/alces_200_model/pred_CI/bootstrap_model",i,".R"))
  
  rast <- predict(pred.data,
                  brt,
                  type = "response",
                  n.trees = brt$n.trees)
  
  stack1 <- addLayer(stack1, rast)
  #names(stack1)[i+1]<-paste0("sample",i)
  #Otherwise, Error in `names<-`(`*tmp*`, value = `*vtmp*`) : 
  #incorrect number of layer names
  
}#forgot to reset stack1; out of memory after loop 134
stack1<-dropLayer(stack1, 1:100)
gc()
nlayers(stack1)#loops 101-134
writeRaster(stack1, filename=paste0(z, "/WOTH Predictions/Year 2030 Simulation 1/samples_OntarioC.grd"), format="raster",overwrite=TRUE)


stack1<-stack(rast)
names(stack1)[1]<-"model estimate"

for(i in 135:nsamples){
  
  cat("loop",i,"\n") # this prints the loop number on console to track function progress
  
  brt=readRDS(paste0("4_BRT_outputs/alces_200_model/pred_CI/bootstrap_model",i,".R"))
  
  rast <- predict(pred.data,
                  brt,
                  type = "response",
                  n.trees = brt$n.trees)
  
  stack1 <- addLayer(stack1, rast)
  #names(stack1)[i+1]<-paste0("sample",i)
  #Otherwise, Error in `names<-`(`*tmp*`, value = `*vtmp*`) : 
  #incorrect number of layer names
  
}

nlayers(stack1)#117, corresponding to 135-250 plus "rast"
rm(brt)
gc()
writeRaster(stack1[[2:60]], filename=paste0(z, "/WOTH Predictions/Year 2030 Simulation 1/samples_OntarioD.grd"), format="raster",overwrite=TRUE)
writeRaster(stack1[[61:117]], filename=paste0(z, "/WOTH Predictions/Year 2030 Simulation 1/samples_OntarioE.grd"), format="raster",overwrite=TRUE)

rm(pred.data, stack1, rast)
gc()

stackA<-brick(paste0(z, "/WOTH Predictions/Year 2030 Simulation 1/samples_OntarioA.grd"))
stackB<-brick(paste0(z, "/WOTH Predictions/Year 2030 Simulation 1/samples_OntarioB.grd"))
stackC<-brick(paste0(z, "/WOTH Predictions/Year 2030 Simulation 1/samples_OntarioC.grd"))
stackD<-brick(paste0(z, "/WOTH Predictions/Year 2030 Simulation 1/samples_OntarioD.grd"))
stackE<-brick(paste0(z, "/WOTH Predictions/Year 2030 Simulation 1/samples_OntarioE.grd"))

stack1<-stack(stackA,stackB,stackC,stackD,stackE)

fun0.05 <- function(x) {quantile(x, probs = 0.05, na.rm = TRUE)}
lower<- calc(stack1,fun0.05)
fun0.95 <- function(x) {quantile(x, probs = 0.95, na.rm = TRUE)}
upper<- calc(stack1,fun0.95)
meanDens<-mean(stack1, na.rm = TRUE)
fun0.50 <- function(x) {quantile(x, probs = 0.50, na.rm = TRUE)}
medianDens<-calc(stack1, fun0.50)
fun0.sd <- function(x) {sd(x, na.rm = TRUE)}
sdDens<-calc(stack1, fun0.sd)

writeRaster(meanDens, filename=paste0(z, "/WOTH Predictions/Year 2030 Simulation 1/mean_WOTH_Ontario.tif"), format="GTiff",overwrite=TRUE)
writeRaster(lower, filename=paste0(z, "/WOTH Predictions/Year 2030 Simulation 1/confint_lower_Ontario.tif"), format="GTiff",overwrite=TRUE)
writeRaster(upper, filename=paste0(z, "/WOTH Predictions/Year 2030 Simulation 1/confint_upper_Ontario.tif"), format="GTiff",overwrite=TRUE)
writeRaster(medianDens, filename=paste0(z, "/WOTH Predictions/Year 2030 Simulation 1/median_WOTH_Ontario.tif"), format="GTiff",overwrite=TRUE)
writeRaster(sdDens, filename=paste0(z, "/WOTH Predictions/Year 2030 Simulation 1/sd_WOTH_Ontario.tif"), format="GTiff",overwrite=TRUE)



rm(lower, meanDens, medianDens, sdDens, stackA, stackB, stackC, stackD, stackE, upper)
gc()

#Year 30 (2040, but actually 2050) - Simulation Run 1
#Predicted density + uncertainty for southern Ontario
#Restart

brtmodel=readRDS("4_BRT_outputs/alces_200_model/pred_CI/bootstrap_model1.R")

pred_ontario<-brick("3_ALCES Online Outputs/Predictor Stacks/Year 2040 Simulation 1/pred_on_AO2040.1.grd")
pred.data=pred_ontario
nsamples=250
output.folder = "4_BRT_outputs/alces_200_model/pred_CI"
rm(pred_ontario)
gc()
rast <-  predict(pred.data,
                 brtmodel,
                 type = "response",
                 n.trees = brtmodel$n.trees)

stack1<-stack(rast)
names(stack1)[1]<-"model estimate"

z <- output.folder

rm(brtmodel)
gc()
for(i in 1:nsamples){
  
  cat("loop",i,"\n") # this prints the loop number on console to track function progress
  
  brt=readRDS(paste0("4_BRT_outputs/alces_200_model/pred_CI/bootstrap_model",i,".R"))
  
  rast <- predict(pred.data,
                  brt,
                  type = "response",
                  n.trees = brt$n.trees)
  
  stack1 <- addLayer(stack1, rast)
  names(stack1)[i+1]<-paste0("sample",i)
  
}#ran out of memory after loop 210
rm(brt)
gc()
writeRaster(stack1[[1:50]], filename=paste0(z, "/WOTH Predictions/Year 2040 Simulation 1/samples_OntarioA.grd"), format="raster",overwrite=TRUE)
#success
writeRaster(stack1[[51:100]], filename=paste0(z, "/WOTH Predictions/Year 2040 Simulation 1/samples_OntarioB.grd"), format="raster",overwrite=TRUE)
#success
writeRaster(stack1[[101:150]], filename=paste0(z, "/WOTH Predictions/Year 2040 Simulation 1/samples_OntarioC.grd"), format="raster",overwrite=TRUE)
#not enough memory
writeRaster(stack1[[151:200]], filename=paste0(z, "/WOTH Predictions/Year 2040 Simulation 1/samples_OntarioD.grd"), format="raster",overwrite=TRUE)
#not enough memory
writeRaster(stack1[[201:210]], filename=paste0(z, "/WOTH Predictions/Year 2040 Simulation 1/samples_OntarioE.grd"), format="raster",overwrite=TRUE)
#not enough memory
stack1<-dropLayer(stack1, 1:100)
#drop first 100 layers since they were successfully saved
gc()
writeRaster(stack1[[1:50]], filename=paste0(z, "/WOTH Predictions/Year 2040 Simulation 1/samples_OntarioC.grd"), format="raster",overwrite=TRUE)
#corresponds to original 101:150 layers
writeRaster(stack1[[51:100]], filename=paste0(z, "/WOTH Predictions/Year 2040 Simulation 1/samples_OntarioD.grd"), format="raster",overwrite=TRUE)
#corresponds to original 151:200 layers
writeRaster(stack1[[101:110]], filename=paste0(z, "/WOTH Predictions/Year 2040 Simulation 1/samples_OntarioE.grd"), format="raster",overwrite=TRUE)
#corresponds to original 201:210 layers

stack1<-stack(rast)
names(stack1)[1]<-"model estimate"

for(i in 211:nsamples){
  
  cat("loop",i,"\n") # this prints the loop number on console to track function progress
  
  brt=readRDS(paste0("4_BRT_outputs/alces_200_model/pred_CI/bootstrap_model",i,".R"))
  
  rast <- predict(pred.data,
                  brt,
                  type = "response",
                  n.trees = brt$n.trees)
  
  stack1 <- addLayer(stack1, rast)
  #names(stack1)[i+1]<-paste0("sample",i)
  #Otherwise, Error in `names<-`(`*tmp*`, value = `*vtmp*`) : 
  #incorrect number of layer names
  
}
nlayers(stack1)#41 layers: 40 needed
writeRaster(stack1[[2:41]], filename=paste0(z, "/WOTH Predictions/Year 2040 Simulation 1/samples_OntarioF.grd"), format="raster",overwrite=TRUE)

rm(pred.data, stack1, rast)
gc()

stackA<-brick(paste0(z, "/WOTH Predictions/Year 2040 Simulation 1/samples_OntarioA.grd"))
stackB<-brick(paste0(z, "/WOTH Predictions/Year 2040 Simulation 1/samples_OntarioB.grd"))
stackC<-brick(paste0(z, "/WOTH Predictions/Year 2040 Simulation 1/samples_OntarioC.grd"))
stackD<-brick(paste0(z, "/WOTH Predictions/Year 2040 Simulation 1/samples_OntarioD.grd"))
stackE<-brick(paste0(z, "/WOTH Predictions/Year 2040 Simulation 1/samples_OntarioE.grd"))
stackF<-brick(paste0(z, "/WOTH Predictions/Year 2040 Simulation 1/samples_OntarioF.grd"))

stack1<-stack(stackA,stackB,stackC,stackD,stackE,stackF)

fun0.05 <- function(x) {quantile(x, probs = 0.05, na.rm = TRUE)}
lower<- calc(stack1,fun0.05)
fun0.95 <- function(x) {quantile(x, probs = 0.95, na.rm = TRUE)}
upper<- calc(stack1,fun0.95)
meanDens<-mean(stack1, na.rm = TRUE)
fun0.50 <- function(x) {quantile(x, probs = 0.50, na.rm = TRUE)}
medianDens<-calc(stack1, fun0.50)
fun0.sd <- function(x) {sd(x, na.rm = TRUE)}
sdDens<-calc(stack1, fun0.sd)

writeRaster(meanDens, filename=paste0(z, "/WOTH Predictions/Year 2040 Simulation 1/mean_WOTH_Ontario.tif"), format="GTiff",overwrite=TRUE)
writeRaster(lower, filename=paste0(z, "/WOTH Predictions/Year 2040 Simulation 1/confint_lower_Ontario.tif"), format="GTiff",overwrite=TRUE)
writeRaster(upper, filename=paste0(z, "/WOTH Predictions/Year 2040 Simulation 1/confint_upper_Ontario.tif"), format="GTiff",overwrite=TRUE)
writeRaster(medianDens, filename=paste0(z, "/WOTH Predictions/Year 2040 Simulation 1/median_WOTH_Ontario.tif"), format="GTiff",overwrite=TRUE)
writeRaster(sdDens, filename=paste0(z, "/WOTH Predictions/Year 2040 Simulation 1/sd_WOTH_Ontario.tif"), format="GTiff",overwrite=TRUE)

#Year 40 (2050, but actually 2060) - Simulation Run 1
#Predicted density + uncertainty for southern Ontario
#Restart

brtmodel=readRDS("4_BRT_outputs/alces_200_model/pred_CI/bootstrap_model1.R")

pred_ontario<-brick("3_ALCES Online Outputs/Predictor Stacks/Year 2050 Simulation 1/pred_on_AO2050.1.grd")
pred.data=pred_ontario
nsamples=250
output.folder = "4_BRT_outputs/alces_200_model/pred_CI"
rm(pred_ontario)
gc()
rast <-  predict(pred.data,
                 brtmodel,
                 type = "response",
                 n.trees = brtmodel$n.trees)

stack1<-stack(rast)
names(stack1)[1]<-"model estimate"

z <- output.folder


for(i in 1:nsamples){
  
  cat("loop",i,"\n") # this prints the loop number on console to track function progress
  
  brt=readRDS(paste0("4_BRT_outputs/alces_200_model/pred_CI/bootstrap_model",i,".R"))
  
  rast <- predict(pred.data,
                  brt,
                  type = "response",
                  n.trees = brt$n.trees)
  
  stack1 <- addLayer(stack1, rast)
  names(stack1)[i+1]<-paste0("sample",i)
  
}#ran out of memory after loop 184
rm(brt,brtmodel)
gc()
writeRaster(stack1[[1:50]], filename=paste0(z, "/WOTH Predictions/Year 2050 Simulation 1/samples_OntarioA.grd"), format="raster",overwrite=TRUE)
#not enough memory
writeRaster(stack1[[51:100]], filename=paste0(z, "/WOTH Predictions/Year 2050 Simulation 1/samples_OntarioB.grd"), format="raster",overwrite=TRUE)
#successful
writeRaster(stack1[[101:150]], filename=paste0(z, "/WOTH Predictions/Year 2050 Simulation 1/samples_OntarioC.grd"), format="raster",overwrite=TRUE)
#not enough memory
writeRaster(stack1[[151:184]], filename=paste0(z, "/WOTH Predictions/Year 2050 Simulation 1/samples_OntarioD.grd"), format="raster",overwrite=TRUE)
#successful
nlayers(stack1)
stack1<-dropLayer(stack1, 151:184)
nlayers(stack1)
gc()
writeRaster(stack1[[1:50]], filename=paste0(z, "/WOTH Predictions/Year 2050 Simulation 1/samples_OntarioA.grd"), format="raster",overwrite=TRUE)
#successful
writeRaster(stack1[[101:150]], filename=paste0(z, "/WOTH Predictions/Year 2050 Simulation 1/samples_OntarioC.grd"), format="raster",overwrite=TRUE)
#successful
rm(stack1)
gc()


stack1<-stack(rast)
names(stack1)[1]<-"model estimate"

for(i in 185:nsamples){
  
  cat("loop",i,"\n") # this prints the loop number on console to track function progress
  
  brt=readRDS(paste0("4_BRT_outputs/alces_200_model/pred_CI/bootstrap_model",i,".R"))
  
  rast <- predict(pred.data,
                  brt,
                  type = "response",
                  n.trees = brt$n.trees)
  
  stack1 <- addLayer(stack1, rast)
  #names(stack1)[i+1]<-paste0("sample",i)
  #Otherwise, Error in `names<-`(`*tmp*`, value = `*vtmp*`) : 
  #incorrect number of layer names
  
}

writeRaster(stack1[[1:67]], filename=paste0(z, "/WOTH Predictions/Year 2050 Simulation 1/samples_OntarioE.grd"), format="raster",overwrite=TRUE)
#corresponds to loops 185:250


rm(pred.data, brt, stack1, rast)
gc()

stackA<-brick(paste0(z, "/WOTH Predictions/Year 2050 Simulation 1/samples_OntarioA.grd"))
stackB<-brick(paste0(z, "/WOTH Predictions/Year 2050 Simulation 1/samples_OntarioB.grd"))
stackC<-brick(paste0(z, "/WOTH Predictions/Year 2050 Simulation 1/samples_OntarioC.grd"))
stackD<-brick(paste0(z, "/WOTH Predictions/Year 2050 Simulation 1/samples_OntarioD.grd"))
stackE<-brick(paste0(z, "/WOTH Predictions/Year 2050 Simulation 1/samples_OntarioE.grd"))

stack1<-stack(stackA,stackB,stackC,stackD,stackE)

fun0.05 <- function(x) {quantile(x, probs = 0.05, na.rm = TRUE)}
lower<- calc(stack1,fun0.05)
fun0.95 <- function(x) {quantile(x, probs = 0.95, na.rm = TRUE)}
upper<- calc(stack1,fun0.95)
meanDens<-mean(stack1, na.rm = TRUE)
fun0.50 <- function(x) {quantile(x, probs = 0.50, na.rm = TRUE)}
medianDens<-calc(stack1, fun0.50)
fun0.sd <- function(x) {sd(x, na.rm = TRUE)}
sdDens<-calc(stack1, fun0.sd)

writeRaster(meanDens, filename=paste0(z, "/WOTH Predictions/Year 2050 Simulation 1/mean_WOTH_Ontario.tif"), format="GTiff",overwrite=TRUE)
writeRaster(lower, filename=paste0(z, "/WOTH Predictions/Year 2050 Simulation 1/confint_lower_Ontario.tif"), format="GTiff",overwrite=TRUE)
writeRaster(upper, filename=paste0(z, "/WOTH Predictions/Year 2050 Simulation 1/confint_upper_Ontario.tif"), format="GTiff",overwrite=TRUE)
writeRaster(medianDens, filename=paste0(z, "/WOTH Predictions/Year 2050 Simulation 1/median_WOTH_Ontario.tif"), format="GTiff",overwrite=TRUE)
writeRaster(sdDens, filename=paste0(z, "/WOTH Predictions/Year 2050 Simulation 1/sd_WOTH_Ontario.tif"), format="GTiff",overwrite=TRUE)



rm(lower, meanDens, medianDens, rast, sdDens, stack1, stackA, stackB, stackC, stackD, stackE, upper)
gc()

#Year 50 (2060, but actually 2070) - Simulation Run 1
#Predicted density + uncertainty for southern Ontario
#Restart

brtmodel=readRDS("4_BRT_outputs/alces_200_model/pred_CI/bootstrap_model1.R")

pred_ontario<-brick("3_ALCES Online Outputs/Predictor Stacks/Year 2060 Simulation 1/pred_on_AO2060.1.grd")
pred.data=pred_ontario
nsamples=250
output.folder = "4_BRT_outputs/alces_200_model/pred_CI"
rm(pred_ontario)
gc()
rast <-  predict(pred.data,
                 brtmodel,
                 type = "response",
                 n.trees = brtmodel$n.trees)

stack1<-stack(rast)
names(stack1)[1]<-"model estimate"

z <- output.folder


for(i in 1:nsamples){
  
  cat("loop",i,"\n") # this prints the loop number on console to track function progress
  
  brt=readRDS(paste0("4_BRT_outputs/alces_200_model/pred_CI/bootstrap_model",i,".R"))
  
  rast <- predict(pred.data,
                  brt,
                  type = "response",
                  n.trees = brt$n.trees)
  
  stack1 <- addLayer(stack1, rast)
  names(stack1)[i+1]<-paste0("sample",i)
  
}#ran out of memory after loop 152

writeRaster(stack1[[1:50]], filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 1/samples_OntarioA.grd"), format="raster",overwrite=TRUE)
writeRaster(stack1[[51:100]], filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 1/samples_OntarioB.grd"), format="raster",overwrite=TRUE)
writeRaster(stack1[[101:152]], filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 1/samples_OntarioC.grd"), format="raster",overwrite=TRUE)

rm(brtmodel)
gc()

stack1<-stack(rast)
names(stack1)[1]<-"model estimate"

for(i in 153:nsamples){
  
  cat("loop",i,"\n") # this prints the loop number on console to track function progress
  
  brt=readRDS(paste0("4_BRT_outputs/alces_200_model/pred_CI/bootstrap_model",i,".R"))
  
  rast <- predict(pred.data,
                  brt,
                  type = "response",
                  n.trees = brt$n.trees)
  
  stack1 <- addLayer(stack1, rast)
  #names(stack1)[i+1]<-paste0("sample",i)
  #Otherwise, Error in `names<-`(`*tmp*`, value = `*vtmp*`) : 
  #incorrect number of layer names
  
}

writeRaster(stack1[[1:48]], filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 1/samples_OntarioD.grd"), format="raster",overwrite=TRUE)
#corresponds to loops 153:200
writeRaster(stack1[[49:99]], filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 1/samples_OntarioE.grd"), format="raster",overwrite=TRUE)
#corresponds to loops 201:250

rm(pred.data, brt, stack1)

stackA<-brick(paste0(z, "/WOTH Predictions/Year 2060 Simulation 1/samples_OntarioA.grd"))
stackB<-brick(paste0(z, "/WOTH Predictions/Year 2060 Simulation 1/samples_OntarioB.grd"))
stackC<-brick(paste0(z, "/WOTH Predictions/Year 2060 Simulation 1/samples_OntarioC.grd"))
stackD<-brick(paste0(z, "/WOTH Predictions/Year 2060 Simulation 1/samples_OntarioD.grd"))
stackE<-brick(paste0(z, "/WOTH Predictions/Year 2060 Simulation 1/samples_OntarioE.grd"))

stack1<-stack(stackA,stackB,stackC,stackD,stackE)

fun0.05 <- function(x) {quantile(x, probs = 0.05, na.rm = TRUE)}
lower<- calc(stack1,fun0.05)
fun0.95 <- function(x) {quantile(x, probs = 0.95, na.rm = TRUE)}
upper<- calc(stack1,fun0.95)
meanDens<-mean(stack1, na.rm = TRUE)
fun0.50 <- function(x) {quantile(x, probs = 0.50, na.rm = TRUE)}
medianDens<-calc(stack1, fun0.50)
fun0.sd <- function(x) {sd(x, na.rm = TRUE)}
sdDens<-calc(stack1, fun0.sd)

writeRaster(meanDens, filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 1/mean_WOTH_Ontario.tif"), format="GTiff",overwrite=TRUE)
writeRaster(lower, filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 1/confint_lower_Ontario.tif"), format="GTiff",overwrite=TRUE)
writeRaster(upper, filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 1/confint_upper_Ontario.tif"), format="GTiff",overwrite=TRUE)
writeRaster(medianDens, filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 1/median_WOTH_Ontario.tif"), format="GTiff",overwrite=TRUE)
writeRaster(sdDens, filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 1/sd_WOTH_Ontario.tif"), format="GTiff",overwrite=TRUE)


rm(lower, meanDens, medianDens, rast, sdDens, stack1, stackA, stackB, stackC, stackD, stackE, upper)
gc()



#Year 50 (2060, but actually 2070) - Simulation Run 2
#Predicted density + uncertainty for southern Ontario
#Restart

brtmodel=readRDS("4_BRT_outputs/alces_200_model/pred_CI/bootstrap_model1.R")

pred_ontario<-brick("3_ALCES Online Outputs/Predictor Stacks/Year 2060 Simulation 2/pred_on_AO2060.2.grd")
pred.data=pred_ontario
nsamples=250
output.folder = "4_BRT_outputs/alces_200_model/pred_CI"
rm(pred_ontario)
gc()
rast <-  predict(pred.data,
                 brtmodel,
                 type = "response",
                 n.trees = brtmodel$n.trees)

stack1<-stack(rast)
names(stack1)[1]<-"model estimate"

z <- output.folder
rm(brtmodel)
gc()

for(i in 1:nsamples){
  
  cat("loop",i,"\n") # this prints the loop number on console to track function progress
  
  brt=readRDS(paste0("4_BRT_outputs/alces_200_model/pred_CI/bootstrap_model",i,".R"))
  
  rast <- predict(pred.data,
                  brt,
                  type = "response",
                  n.trees = brt$n.trees)
  
  stack1 <- addLayer(stack1, rast)
  names(stack1)[i+1]<-paste0("sample",i)
  
}#ran out of memory after loop 183
rm(brt)
gc()
writeRaster(stack1[[151:183]], filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 2/samples_OntarioD.grd"), format="raster",overwrite=TRUE)
writeRaster(stack1[[1:50]], filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 2/samples_OntarioA.grd"), format="raster",overwrite=TRUE)
stack1<-dropLayer(stack1,151:183)
gc()
writeRaster(stack1[[51:100]], filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 2/samples_OntarioB.grd"), format="raster",overwrite=TRUE)
writeRaster(stack1[[101:150]], filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 2/samples_OntarioC.grd"), format="raster",overwrite=TRUE)

stack1<-stack(rast)
names(stack1)[1]<-"model estimate"

for(i in 184:nsamples){
  
  cat("loop",i,"\n") # this prints the loop number on console to track function progress
  
  brt=readRDS(paste0("4_BRT_outputs/alces_200_model/pred_CI/bootstrap_model",i,".R"))
  
  rast <- predict(pred.data,
                  brt,
                  type = "response",
                  n.trees = brt$n.trees)
  
  stack1 <- addLayer(stack1, rast)
  #names(stack1)[i+1]<-paste0("sample",i)
  #Otherwise, Error in `names<-`(`*tmp*`, value = `*vtmp*`) : 
  #incorrect number of layer names
  
}
rm(brt)
gc()
nlayers(stack1)
writeRaster(stack1[[2:18]], filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 2/samples_OntarioE.grd"), format="raster",overwrite=TRUE)
writeRaster(stack1[[19:68]], filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 2/samples_OntarioF.grd"), format="raster",overwrite=TRUE)

rm(pred.data, stack1)
gc()
stackA<-brick(paste0(z, "/WOTH Predictions/Year 2060 Simulation 2/samples_OntarioA.grd"))
stackB<-brick(paste0(z, "/WOTH Predictions/Year 2060 Simulation 2/samples_OntarioB.grd"))
stackC<-brick(paste0(z, "/WOTH Predictions/Year 2060 Simulation 2/samples_OntarioC.grd"))
stackD<-brick(paste0(z, "/WOTH Predictions/Year 2060 Simulation 2/samples_OntarioD.grd"))
stackE<-brick(paste0(z, "/WOTH Predictions/Year 2060 Simulation 2/samples_OntarioE.grd"))
stackF<-brick(paste0(z, "/WOTH Predictions/Year 2060 Simulation 2/samples_OntarioF.grd"))

stack1<-stack(stackA,stackB,stackC,stackD,stackE,stackF)

fun0.05 <- function(x) {quantile(x, probs = 0.05, na.rm = TRUE)}
lower<- calc(stack1,fun0.05)
fun0.95 <- function(x) {quantile(x, probs = 0.95, na.rm = TRUE)}
upper<- calc(stack1,fun0.95)
meanDens<-mean(stack1, na.rm = TRUE)
fun0.50 <- function(x) {quantile(x, probs = 0.50, na.rm = TRUE)}
medianDens<-calc(stack1, fun0.50)
fun0.sd <- function(x) {sd(x, na.rm = TRUE)}
sdDens<-calc(stack1, fun0.sd)

writeRaster(meanDens, filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 2/mean_WOTH_Ontario.tif"), format="GTiff",overwrite=TRUE)
writeRaster(lower, filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 2/confint_lower_Ontario.tif"), format="GTiff",overwrite=TRUE)
writeRaster(upper, filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 2/confint_upper_Ontario.tif"), format="GTiff",overwrite=TRUE)
writeRaster(medianDens, filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 2/median_WOTH_Ontario.tif"), format="GTiff",overwrite=TRUE)
writeRaster(sdDens, filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 2/sd_WOTH_Ontario.tif"), format="GTiff",overwrite=TRUE)


rm(lower, meanDens, medianDens, rast, sdDens, stack1, stackA, stackB, stackC, stackD, stackE, stackF, upper)
gc()




#Year 50 (2060, but actually 2070) - Simulation Run 3
#Predicted density + uncertainty for southern Ontario
#Restart

brtmodel=readRDS("4_BRT_outputs/alces_200_model/pred_CI/bootstrap_model1.R")

pred_ontario<-brick("3_ALCES Online Outputs/Predictor Stacks/Year 2060 Simulation 3/pred_on_AO2060.3.grd")
pred.data=pred_ontario
nsamples=250
output.folder = "4_BRT_outputs/alces_200_model/pred_CI"
rm(pred_ontario)
gc()
rast <-  predict(pred.data,
                 brtmodel,
                 type = "response",
                 n.trees = brtmodel$n.trees)

stack1<-stack(rast)
names(stack1)[1]<-"model estimate"

z <- output.folder
rm(brtmodel)
gc()

for(i in 1:nsamples){
  
  cat("loop",i,"\n") # this prints the loop number on console to track function progress
  
  brt=readRDS(paste0("4_BRT_outputs/alces_200_model/pred_CI/bootstrap_model",i,".R"))
  
  rast <- predict(pred.data,
                  brt,
                  type = "response",
                  n.trees = brt$n.trees)
  
  stack1 <- addLayer(stack1, rast)
  names(stack1)[i+1]<-paste0("sample",i)
  
}

rm(brt)
gc()

writeRaster(stack1[[151:200]], filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 3/samples_OntarioD.grd"), format="raster",overwrite=TRUE)
stack1<-dropLayer(stack1,151:200)
gc()
writeRaster(stack1[[101:150]], filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 3/samples_OntarioC.grd"), format="raster",overwrite=TRUE)
#out of memory
writeRaster(stack1[[1:50]], filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 3/samples_OntarioA.grd"), format="raster",overwrite=TRUE)
#out of memory
writeRaster(stack1[[51:100]], filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 3/samples_OntarioB.grd"), format="raster",overwrite=TRUE)
#success
stack1<-dropLayer(stack1,51:100)
gc()
nlayers(stack1)
writeRaster(stack1[[51:100]], filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 3/samples_OntarioC.grd"), format="raster",overwrite=TRUE)
#corresponds to bootstraps 101:150
writeRaster(stack1[[1:50]], filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 3/samples_OntarioA.grd"), format="raster",overwrite=TRUE)
#out of memory


stack1<-stack(rast)
names(stack1)[1]<-"model estimate"

for(i in 201:nsamples){
  
  cat("loop",i,"\n") # this prints the loop number on console to track function progress
  
  brt=readRDS(paste0("4_BRT_outputs/alces_200_model/pred_CI/bootstrap_model",i,".R"))
  
  rast <- predict(pred.data,
                  brt,
                  type = "response",
                  n.trees = brt$n.trees)
  
  stack1 <- addLayer(stack1, rast)
  #names(stack1)[i+1]<-paste0("sample",i)
  #Otherwise, Error in `names<-`(`*tmp*`, value = `*vtmp*`) : 
  #incorrect number of layer names
  
}
rm(brt)
gc()
nlayers(stack1)
writeRaster(stack1[[2:51]], filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 3/samples_OntarioE.grd"), format="raster",overwrite=TRUE)

rm(pred.data, stack1)
gc()
stackA<-brick(paste0(z, "/WOTH Predictions/Year 2060 Simulation 3/samples_OntarioA.grd"))
stackB<-brick(paste0(z, "/WOTH Predictions/Year 2060 Simulation 3/samples_OntarioB.grd"))
stackC<-brick(paste0(z, "/WOTH Predictions/Year 2060 Simulation 3/samples_OntarioC.grd"))
stackD<-brick(paste0(z, "/WOTH Predictions/Year 2060 Simulation 3/samples_OntarioD.grd"))
stackE<-brick(paste0(z, "/WOTH Predictions/Year 2060 Simulation 3/samples_OntarioE.grd"))

stack1<-stack(stackA,stackB,stackC,stackD,stackE)

fun0.05 <- function(x) {quantile(x, probs = 0.05, na.rm = TRUE)}
lower<- calc(stack1,fun0.05)
fun0.95 <- function(x) {quantile(x, probs = 0.95, na.rm = TRUE)}
upper<- calc(stack1,fun0.95)
meanDens<-mean(stack1, na.rm = TRUE)
fun0.50 <- function(x) {quantile(x, probs = 0.50, na.rm = TRUE)}
medianDens<-calc(stack1, fun0.50)
fun0.sd <- function(x) {sd(x, na.rm = TRUE)}
sdDens<-calc(stack1, fun0.sd)

writeRaster(meanDens, filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 3/mean_WOTH_Ontario.tif"), format="GTiff",overwrite=TRUE)
writeRaster(lower, filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 3/confint_lower_Ontario.tif"), format="GTiff",overwrite=TRUE)
writeRaster(upper, filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 3/confint_upper_Ontario.tif"), format="GTiff",overwrite=TRUE)
writeRaster(medianDens, filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 3/median_WOTH_Ontario.tif"), format="GTiff",overwrite=TRUE)
writeRaster(sdDens, filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 3/sd_WOTH_Ontario.tif"), format="GTiff",overwrite=TRUE)




#Year 50 (2060, but actually 2070) - Simulation Run 4
#Predicted density + uncertainty for southern Ontario
#Restart

brtmodel=readRDS("4_BRT_outputs/alces_200_model/pred_CI/bootstrap_model1.R")

pred_ontario<-brick("3_ALCES Online Outputs/Predictor Stacks/Year 2060 Simulation 4/pred_on_AO2060.4.grd")
pred.data=pred_ontario
nsamples=250
output.folder = "4_BRT_outputs/alces_200_model/pred_CI"
rm(pred_ontario)
gc()
rast <-  predict(pred.data,
                 brtmodel,
                 type = "response",
                 n.trees = brtmodel$n.trees)

stack1<-stack(rast)
names(stack1)[1]<-"model estimate"

z <- output.folder
rm(brtmodel)
gc()

for(i in 1:nsamples){
  
  cat("loop",i,"\n") # this prints the loop number on console to track function progress
  
  brt=readRDS(paste0("4_BRT_outputs/alces_200_model/pred_CI/bootstrap_model",i,".R"))
  
  rast <- predict(pred.data,
                  brt,
                  type = "response",
                  n.trees = brt$n.trees)
  
  stack1 <- addLayer(stack1, rast)
  names(stack1)[i+1]<-paste0("sample",i)
  
}

rm(brt,stackA,stackB,stackC,stackD,stackE,upper,meanDens,medianDens,sdDens,lower)
gc()

writeRaster(stack1[[151:174]], filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 4/samples_OntarioD.grd"), format="raster",overwrite=TRUE)
#not enough memory
writeRaster(stack1[[175:199]], filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 4/samples_OntarioE.grd"), format="raster",overwrite=TRUE)
#not enough memory
stack1<-dropLayer(stack1,151:199)
gc()
writeRaster(stack1[[1:50]], filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 4/samples_OntarioA.grd"), format="raster",overwrite=TRUE)
#success
writeRaster(stack1[[51:100]], filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 4/samples_OntarioB.grd"), format="raster",overwrite=TRUE)
#success
writeRaster(stack1[[101:150]], filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 4/samples_OntarioC.grd"), format="raster",overwrite=TRUE)
#out of memory
stack1<-dropLayer(stack1,1:100)
nlayers(stack1)#50
gc()
writeRaster(stack1[[1:50]], filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 4/samples_OntarioC.grd"), format="raster",overwrite=TRUE)
#corresponds to the original 101:150 layers

stack1<-stack(rast)
names(stack1)[1]<-"model estimate"

for(i in 151:nsamples){
  
  cat("loop",i,"\n") # this prints the loop number on console to track function progress
  
  brt=readRDS(paste0("4_BRT_outputs/alces_200_model/pred_CI/bootstrap_model",i,".R"))
  
  rast <- predict(pred.data,
                  brt,
                  type = "response",
                  n.trees = brt$n.trees)
  
  stack1 <- addLayer(stack1, rast)
  #names(stack1)[i+1]<-paste0("sample",i)
  #Otherwise, Error in `names<-`(`*tmp*`, value = `*vtmp*`) : 
  #incorrect number of layer names
  
}
rm(brt)
gc()
nlayers(stack1)
writeRaster(stack1[[2:51]], filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 4/samples_OntarioD.grd"), format="raster",overwrite=TRUE)
#corresponds to loops 151:200
writeRaster(stack1[[52:101]], filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 4/samples_OntarioE.grd"), format="raster",overwrite=TRUE)
#corresponds to loops 201:250

rm(pred.data, stack1)
gc()
stackA<-brick(paste0(z, "/WOTH Predictions/Year 2060 Simulation 4/samples_OntarioA.grd"))
stackB<-brick(paste0(z, "/WOTH Predictions/Year 2060 Simulation 4/samples_OntarioB.grd"))
stackC<-brick(paste0(z, "/WOTH Predictions/Year 2060 Simulation 4/samples_OntarioC.grd"))
stackD<-brick(paste0(z, "/WOTH Predictions/Year 2060 Simulation 4/samples_OntarioD.grd"))
stackE<-brick(paste0(z, "/WOTH Predictions/Year 2060 Simulation 4/samples_OntarioE.grd"))

stack1<-stack(stackA,stackB,stackC,stackD,stackE)

fun0.05 <- function(x) {quantile(x, probs = 0.05, na.rm = TRUE)}
lower<- calc(stack1,fun0.05)
fun0.95 <- function(x) {quantile(x, probs = 0.95, na.rm = TRUE)}
upper<- calc(stack1,fun0.95)
meanDens<-mean(stack1, na.rm = TRUE)
fun0.50 <- function(x) {quantile(x, probs = 0.50, na.rm = TRUE)}
medianDens<-calc(stack1, fun0.50)
fun0.sd <- function(x) {sd(x, na.rm = TRUE)}
sdDens<-calc(stack1, fun0.sd)

writeRaster(meanDens, filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 4/mean_WOTH_Ontario.tif"), format="GTiff",overwrite=TRUE)
writeRaster(lower, filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 4/confint_lower_Ontario.tif"), format="GTiff",overwrite=TRUE)
writeRaster(upper, filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 4/confint_upper_Ontario.tif"), format="GTiff",overwrite=TRUE)
writeRaster(medianDens, filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 4/median_WOTH_Ontario.tif"), format="GTiff",overwrite=TRUE)
writeRaster(sdDens, filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 4/sd_WOTH_Ontario.tif"), format="GTiff",overwrite=TRUE)

rm(stack1, stackA, stackB, stackC, stackD, stackE, lower, upper, meanDens, medianDens, sdDens)
gc()


#Year 50 (2060, but actually 2070) - Simulation Run 5
#Predicted density + uncertainty for southern Ontario
#Restart

brtmodel=readRDS("4_BRT_outputs/alces_200_model/pred_CI/bootstrap_model1.R")

pred_ontario<-brick("3_ALCES Online Outputs/Predictor Stacks/Year 2060 Simulation 5/pred_on_AO2060.5.grd")
pred.data=pred_ontario
nsamples=250
output.folder = "4_BRT_outputs/alces_200_model/pred_CI"
rm(pred_ontario)
gc()
rast <-  predict(pred.data,
                 brtmodel,
                 type = "response",
                 n.trees = brtmodel$n.trees)

stack1<-stack(rast)
names(stack1)[1]<-"model estimate"

z <- output.folder
rm(brtmodel)
gc()

for(i in 1:nsamples){
  
  cat("loop",i,"\n") # this prints the loop number on console to track function progress
  
  brt=readRDS(paste0("4_BRT_outputs/alces_200_model/pred_CI/bootstrap_model",i,".R"))
  
  rast <- predict(pred.data,
                  brt,
                  type = "response",
                  n.trees = brt$n.trees)
  
  stack1 <- addLayer(stack1, rast)
  names(stack1)[i+1]<-paste0("sample",i)
  
}
rm(brt)
gc()
writeRaster(stack1[[1:50]], filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 5/samples_OntarioA.grd"), format="raster",overwrite=TRUE)
#success
writeRaster(stack1[[51:100]], filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 5/samples_OntarioB.grd"), format="raster",overwrite=TRUE)
#out of memory
writeRaster(stack1[[101:151]], filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 5/samples_OntarioC.grd"), format="raster",overwrite=TRUE)
#out of memory
stack1<-dropLayer(stack1, 1:50)
gc()
nlayers(stack1)#101
writeRaster(stack1[[1:50]], filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 5/samples_OntarioB.grd"), format="raster",overwrite=TRUE)
#corresponds to loop 51:100
writeRaster(stack1[[51:101]], filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 5/samples_OntarioC.grd"), format="raster",overwrite=TRUE)
#corresponds to loop 101:151


stack1<-stack(rast)
names(stack1)[1]<-"model estimate"

z <- output.folder
rm(brtmodel)
gc()

for(i in 152:nsamples){
  
  cat("loop",i,"\n") # this prints the loop number on console to track function progress
  
  brt=readRDS(paste0("4_BRT_outputs/alces_200_model/pred_CI/bootstrap_model",i,".R"))
  
  rast <- predict(pred.data,
                  brt,
                  type = "response",
                  n.trees = brt$n.trees)
  
  stack1 <- addLayer(stack1, rast)
  #names(stack1)[i+1]<-paste0("sample",i)
  
}
rm(brt)
gc()
nlayers(stack1)
writeRaster(stack1[[2:50]], filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 5/samples_OntarioD.grd"), format="raster",overwrite=TRUE)
#corresponds to loops 152:200
writeRaster(stack1[[51:100]], filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 5/samples_OntarioE.grd"), format="raster",overwrite=TRUE)
#corresponds to loops 201:250


rm(pred.data, stack1)
gc()
stackA<-brick(paste0(z, "/WOTH Predictions/Year 2060 Simulation 5/samples_OntarioA.grd"))
stackB<-brick(paste0(z, "/WOTH Predictions/Year 2060 Simulation 5/samples_OntarioB.grd"))
stackC<-brick(paste0(z, "/WOTH Predictions/Year 2060 Simulation 5/samples_OntarioC.grd"))
stackD<-brick(paste0(z, "/WOTH Predictions/Year 2060 Simulation 5/samples_OntarioD.grd"))
stackE<-brick(paste0(z, "/WOTH Predictions/Year 2060 Simulation 5/samples_OntarioE.grd"))

stack1<-stack(stackA,stackB,stackC,stackD,stackE)

fun0.05 <- function(x) {quantile(x, probs = 0.05, na.rm = TRUE)}
lower<- calc(stack1,fun0.05)
fun0.95 <- function(x) {quantile(x, probs = 0.95, na.rm = TRUE)}
upper<- calc(stack1,fun0.95)
meanDens<-mean(stack1, na.rm = TRUE)
fun0.50 <- function(x) {quantile(x, probs = 0.50, na.rm = TRUE)}
medianDens<-calc(stack1, fun0.50)
fun0.sd <- function(x) {sd(x, na.rm = TRUE)}
sdDens<-calc(stack1, fun0.sd)

writeRaster(meanDens, filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 5/mean_WOTH_Ontario.tif"), format="GTiff",overwrite=TRUE)
writeRaster(lower, filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 5/confint_lower_Ontario.tif"), format="GTiff",overwrite=TRUE)
writeRaster(upper, filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 5/confint_upper_Ontario.tif"), format="GTiff",overwrite=TRUE)
writeRaster(medianDens, filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 5/median_WOTH_Ontario.tif"), format="GTiff",overwrite=TRUE)
writeRaster(sdDens, filename=paste0(z, "/WOTH Predictions/Year 2060 Simulation 5/sd_WOTH_Ontario.tif"), format="GTiff",overwrite=TRUE)

rm(stack1, stackA, stackB, stackC, stackD, stackE, lower, upper, meanDens, medianDens, sdDens)
gc()


