memory.limit(size=56000)

library(raster)
library(sf)
library(sp)
library(rgeos)
library(rgdal)

#Step 1
#For each predictor whose rasters were downloaded from ALCES Online 
#(except forest age for now), import the separate rasters for each
#FMU or BCR and stitch them together with the mosaic or merge function.
#For BCR 13, first cut out the bits that occur within other FMUs, then
#resample from 500 m to 200 m resolution. After merging, there should
#be a single layer for each predictor, with the extent of the
#Wood Thrush's range in Ontario.

#Step 2
#Similar to step 1, but now focusing on the forest age rasters from a 
#given time step (2010 - 2060, which actually corresponds to 2020 - 2070).
#After stitching is done, there will be a single forest age layer for each
#time step, so there will be six layers for forest age.

#Step 3
#Import topography variables and run moving window analyses on the stitched predictor
#layers created in step 1 that do not depend on the forest age layers
#created in step 2.

#Step 4
#Use the forest age from a given time step to create the 
#actual shrubland, swamp, and forest variables that you will be using. For example,
#the forest age for each pixel will be used to classify the pixel
#as shrubland or forest, if there is any forest present. If there
#is no forest present at all, forest age will be set to 0 since
#it was allowed to increase everywhere when the baseline scenario
#was running. Dense Decid, Dense Conifer, Dense Mixed, 
#Sparse or Undifferentiated Forest, and Treed Wetland will
#be reclassified as shrubland if forest age < 20, and as their
#respective forest types if forest age > 20 in a given time step.

#Moving window analyses will then be performed on different layers.

#Step 5
#For a given time step stack together all of the stitched predictor
#layers created in step 3 with one of the stitched forest age-dependent layers
#created in step 4.


#Some layers like different road types will be added together. Each 
#pixel can then be classified as 1 or 0 to indicate if there is a road
#within 150 m.

#Once I have 6 predictor raster stacks created. I will be able to
#use them with the 250 resampled BRTs to predict Wood Thrush abundance
#in Ontario across the species' range. I can then clip out
#the part of the range that is covered by Landis scenarios to make
#comparisons of population size and trajectory.

ROOT<-"D:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/3_ALCES Online Outputs/Baseline Scenario/"
FMUS<-c("Abitibi Forest",
        "Algoma Forest",
        "Algonquin Forest",
        "Bancroft Minden Forest",
        "Black Spruce Forest",
        "Boundary Waters Forest",
        "French Severn Forest",
        "Gorden Cosens Forest",
        "Hearst Forest",
        "Kenora Forest",
        "Lakehead Forest",
        "Mazinaw Lanark Forest",
        "Missinaibi Forest",
        "Nagagami Forest",
        "Nipissing Forest",
        "Northshore Forest",
        "Ottawa Valley Forest",
        "Pic Forest",
        "Pineland Forest",
        "Romeo Malette Forest",
        "Spanish Forest",
        "Sudbury Forest",
        "Temagami Forest",
        "Timiskaming Forest",
        "White River Forest")
#read in shapefile that will be used to remove border pieces from BCR13
WOTHxFMU<-readOGR("D:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/3_ALCES Online Outputs/WOTHxFMU/WOTHxFMU","WOTHxFMU")
WOTHxFMU.rp<-spTransform(WOTHxFMU, CRSobj="+proj=lcc +lat_0=0 +lon_0=-85 +lat_1=44.5 +lat_2=53.5 +x_0=930000 +y_0=6430000 +datum=NAD83 +units=m +no_defs")

#########################################
#                                       #
#                                       #
#             STEP ONE                  #
#           UNITY LAND COVER 200 m      #
#                                       #
#########################################

#Single layer for Dense Decid ON
#create empty list for storing rasters
rasterlist<-list()#empty list each time we draw a new number of samples

#read rasters for a specific predictor into list
for (j in FMUS){
  tempras<-raster(paste0(ROOT,j,"/year 2010/simulation 1/AO-dense-deciduous-on-2010.tif")) #temporary raster
  #rasters must all have common origin for mosaic function to work
  origin(tempras)<-0
  rasterlist[[j]]<-tempras#B#append temporary raster at each loop iteration to the list
}
plot(rasterlist[[1]])
plot(rasterlist[[2]])
rasterlist$fun<-mean
rasterlist$na.rm<-TRUE
#combine those separate rasters into a single layer
drawnresults<-mosaic(rasterlist$`Abitibi Forest`,
                     rasterlist$`Algoma Forest`,
                     rasterlist$`Algonquin Forest`,
                     rasterlist$`Bancroft Minden Forest`,
                     rasterlist$`Black Spruce Forest`,
                     rasterlist$`Boundary Waters Forest`,
                     rasterlist$`French Severn Forest`,
                     rasterlist$`Gorden Cosens Forest`,
                     rasterlist$`Hearst Forest`,
                     rasterlist$`Kenora Forest`,
                     rasterlist$`Lakehead Forest`,
                     rasterlist$`Mazinaw Lanark Forest`,
                     rasterlist$`Missinaibi Forest`,
                     rasterlist$`Nagagami Forest`,
                     rasterlist$`Nipissing Forest`,
                     rasterlist$`Northshore Forest`,
                     rasterlist$`Ottawa Valley Forest`,
                     rasterlist$`Pic Forest`,
                     rasterlist$`Pineland Forest`,
                     rasterlist$`Romeo Malette Forest`,
                     rasterlist$`Spanish Forest`,
                     rasterlist$`Sudbury Forest`,
                     rasterlist$`Temagami Forest`,
                     rasterlist$`Timiskaming Forest`,
                     rasterlist$`White River Forest`,
                     fun=mean)
plot(drawnresults)

#now get same predictor for BCR 13, 
bcr13.ras<-raster(paste0(ROOT,"BCR 13/year 2010/simulation 1/AO-dense-deciduous-on-2010.tif")) #temporary raster
origin(bcr13.ras)<-0
#cut out the bits in BCR 13 that are in "drawnresults",
#the reverse-clip or inverse mask is supposed to get rid of the parts of the 
#raster within the shapefile area
bcr13.ras.CL <- mask(bcr13.ras, WOTHxFMU.rp, inverse = TRUE)
plot(bcr13.ras.CL)
plot(bcr13.ras)
plot(bcr13.ras.CL)
#works!
drawnresultsB<-mosaic(drawnresults, bcr13.ras.CL, fun=mean)
plot(drawnresultsB)
drawnresultsC<-drawnresultsB/100#change units from percentage to proportion
plot(drawnresultsC)
writeRaster(drawnresultsC, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/DenseDecidWOTHxFMU.tif", overwrite=TRUE)

#Single layer for Dense Conifer ON
#create empty list for storing rasters
rasterlist<-list()#empty list each time we draw a new number of samples

#read rasters for a specific predictor into list
for (j in FMUS){
  tempras<-raster(paste0(ROOT,j,"/year 2010/simulation 1/AO-dense-conifer-on-2010.tif")) #temporary raster
  #rasters must all have common origin for mosaic function to work
  origin(tempras)<-0
  rasterlist[[j]]<-tempras#B#append temporary raster at each loop iteration to the list
}

#combine those separate rasters into a single layer
drawnresults<-mosaic(rasterlist$`Abitibi Forest`,
                     rasterlist$`Algoma Forest`,
                     rasterlist$`Algonquin Forest`,
                     rasterlist$`Bancroft Minden Forest`,
                     rasterlist$`Black Spruce Forest`,
                     rasterlist$`Boundary Waters Forest`,
                     rasterlist$`French Severn Forest`,
                     rasterlist$`Gorden Cosens Forest`,
                     rasterlist$`Hearst Forest`,
                     rasterlist$`Kenora Forest`,
                     rasterlist$`Lakehead Forest`,
                     rasterlist$`Mazinaw Lanark Forest`,
                     rasterlist$`Missinaibi Forest`,
                     rasterlist$`Nagagami Forest`,
                     rasterlist$`Nipissing Forest`,
                     rasterlist$`Northshore Forest`,
                     rasterlist$`Ottawa Valley Forest`,
                     rasterlist$`Pic Forest`,
                     rasterlist$`Pineland Forest`,
                     rasterlist$`Romeo Malette Forest`,
                     rasterlist$`Spanish Forest`,
                     rasterlist$`Sudbury Forest`,
                     rasterlist$`Temagami Forest`,
                     rasterlist$`Timiskaming Forest`,
                     rasterlist$`White River Forest`,
                     fun=mean)
plot(drawnresults)

#now get same predictor for BCR 13, 
bcr13.ras<-raster(paste0(ROOT,"BCR 13/year 2010/simulation 1/AO-dense-conifer-on-2010.tif")) #temporary raster
origin(bcr13.ras)<-0
#cut out the bits in BCR 13 that are in "drawnresults",
#the reverse-clip or inverse mask is supposed to get rid of the parts of the 
#raster within the shapefile area
bcr13.ras.CL <- mask(bcr13.ras, WOTHxFMU.rp, inverse = TRUE)
plot(bcr13.ras.CL)
plot(bcr13.ras)
plot(bcr13.ras.CL)
#works!
drawnresultsB<-mosaic(drawnresults, bcr13.ras.CL, fun=mean)
plot(drawnresultsB)
drawnresultsB[values(drawnresultsB)<0]<-0#get rid of negative values
drawnresultsC<-drawnresultsB/100#change units from percentage to proportion
plot(drawnresultsC)
writeRaster(drawnresultsC, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/DenseConifWOTHxFMU.tif", overwrite=TRUE)


#Single layer for Dense Mixed ON
#create empty list for storing rasters
rasterlist<-list()#empty list each time we draw a new number of samples

#read rasters for a specific predictor into list
for (j in FMUS){
  tempras<-raster(paste0(ROOT,j,"/year 2010/simulation 1/AO-dense-mixed-on-2010.tif")) #temporary raster
  #rasters must all have common origin for mosaic function to work
  origin(tempras)<-0
  rasterlist[[j]]<-tempras#B#append temporary raster at each loop iteration to the list
}

#combine those separate rasters into a single layer
drawnresults<-mosaic(rasterlist$`Abitibi Forest`,
                     rasterlist$`Algoma Forest`,
                     rasterlist$`Algonquin Forest`,
                     rasterlist$`Bancroft Minden Forest`,
                     rasterlist$`Black Spruce Forest`,
                     rasterlist$`Boundary Waters Forest`,
                     rasterlist$`French Severn Forest`,
                     rasterlist$`Gorden Cosens Forest`,
                     rasterlist$`Hearst Forest`,
                     rasterlist$`Kenora Forest`,
                     rasterlist$`Lakehead Forest`,
                     rasterlist$`Mazinaw Lanark Forest`,
                     rasterlist$`Missinaibi Forest`,
                     rasterlist$`Nagagami Forest`,
                     rasterlist$`Nipissing Forest`,
                     rasterlist$`Northshore Forest`,
                     rasterlist$`Ottawa Valley Forest`,
                     rasterlist$`Pic Forest`,
                     rasterlist$`Pineland Forest`,
                     rasterlist$`Romeo Malette Forest`,
                     rasterlist$`Spanish Forest`,
                     rasterlist$`Sudbury Forest`,
                     rasterlist$`Temagami Forest`,
                     rasterlist$`Timiskaming Forest`,
                     rasterlist$`White River Forest`,
                     fun=mean)
plot(drawnresults)

#now get same predictor for BCR 13, 
bcr13.ras<-raster(paste0(ROOT,"BCR 13/year 2010/simulation 1/AO-dense-mixed-on-2010.tif")) #temporary raster
origin(bcr13.ras)<-0
#cut out the bits in BCR 13 that are in "drawnresults",
#the reverse-clip or inverse mask is supposed to get rid of the parts of the 
#raster within the shapefile area
bcr13.ras.CL <- mask(bcr13.ras, WOTHxFMU.rp, inverse = TRUE)
plot(bcr13.ras.CL)
plot(bcr13.ras)
plot(bcr13.ras.CL)
#works!
#now attach to the rest of the FMUs
drawnresultsB<-mosaic(drawnresults, bcr13.ras.CL, fun=mean)
plot(drawnresultsB)
drawnresultsB[values(drawnresultsB)<0]<-0#get rid of negative values
drawnresultsC<-drawnresultsB/100#change units from percentage to proportion
plot(drawnresultsC)
writeRaster(drawnresultsC, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/DenseMixedWOTHxFMU.tif", overwrite=TRUE)


#Single layer for Sparse/undifferentiated forest ON
#create empty list for storing rasters
rasterlist<-list()#empty list each time we draw a new number of samples

#read rasters for a specific predictor into list
for (j in FMUS){
  tempras<-raster(paste0(ROOT,j,"/year 2010/simulation 1/AO-sparse-or-undifferentiated-forest-on-2010.tif")) #temporary raster
  #rasters must all have common origin for mosaic function to work
  origin(tempras)<-0
  rasterlist[[j]]<-tempras#B#append temporary raster at each loop iteration to the list
}

#combine those separate rasters into a single layer
drawnresults<-mosaic(rasterlist$`Abitibi Forest`,
                     rasterlist$`Algoma Forest`,
                     rasterlist$`Algonquin Forest`,
                     rasterlist$`Bancroft Minden Forest`,
                     rasterlist$`Black Spruce Forest`,
                     rasterlist$`Boundary Waters Forest`,
                     rasterlist$`French Severn Forest`,
                     rasterlist$`Gorden Cosens Forest`,
                     rasterlist$`Hearst Forest`,
                     rasterlist$`Kenora Forest`,
                     rasterlist$`Lakehead Forest`,
                     rasterlist$`Mazinaw Lanark Forest`,
                     rasterlist$`Missinaibi Forest`,
                     rasterlist$`Nagagami Forest`,
                     rasterlist$`Nipissing Forest`,
                     rasterlist$`Northshore Forest`,
                     rasterlist$`Ottawa Valley Forest`,
                     rasterlist$`Pic Forest`,
                     rasterlist$`Pineland Forest`,
                     rasterlist$`Romeo Malette Forest`,
                     rasterlist$`Spanish Forest`,
                     rasterlist$`Sudbury Forest`,
                     rasterlist$`Temagami Forest`,
                     rasterlist$`Timiskaming Forest`,
                     rasterlist$`White River Forest`,
                     fun=mean)
plot(drawnresults)

#now get same predictor for BCR 13, 
bcr13.ras<-raster(paste0(ROOT,"BCR 13/year 2010/simulation 1/AO-sparse-or-undifferentiated-forest-on-2010.tif")) #temporary raster
origin(bcr13.ras)<-0
#cut out the bits in BCR 13 that are in "drawnresults",
#the reverse-clip or inverse mask is supposed to get rid of the parts of the 
#raster within the shapefile area
bcr13.ras.CL <- mask(bcr13.ras, WOTHxFMU.rp, inverse = TRUE)
plot(bcr13.ras.CL)
plot(bcr13.ras)
plot(bcr13.ras.CL)
#works!
#now attach to the rest of the FMUs
drawnresultsB<-mosaic(drawnresults, bcr13.ras.CL, fun=mean)
plot(drawnresultsB)
drawnresultsB[values(drawnresultsB)<0]<-0#get rid of negative values
drawnresultsC<-drawnresultsB/100#change units from percentage to proportion
plot(drawnresultsC)
writeRaster(drawnresultsC, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/SparseUndifferentiatedForestWOTHxFMU.tif", overwrite=TRUE)


#Single layer for Treed Wetland ON
#create empty list for storing rasters
rasterlist<-list()#empty list each time we draw a new number of samples

#read rasters for a specific predictor into list
for (j in FMUS){
  tempras<-raster(paste0(ROOT,j,"/year 2010/simulation 1/AO-treed-wetland-on-2010.tif")) #temporary raster
  #rasters must all have common origin for mosaic function to work
  origin(tempras)<-0
  rasterlist[[j]]<-tempras#B#append temporary raster at each loop iteration to the list
}

#combine those separate rasters into a single layer
drawnresults<-mosaic(rasterlist$`Abitibi Forest`,
                     rasterlist$`Algoma Forest`,
                     rasterlist$`Algonquin Forest`,
                     rasterlist$`Bancroft Minden Forest`,
                     rasterlist$`Black Spruce Forest`,
                     rasterlist$`Boundary Waters Forest`,
                     rasterlist$`French Severn Forest`,
                     rasterlist$`Gorden Cosens Forest`,
                     rasterlist$`Hearst Forest`,
                     rasterlist$`Kenora Forest`,
                     rasterlist$`Lakehead Forest`,
                     rasterlist$`Mazinaw Lanark Forest`,
                     rasterlist$`Missinaibi Forest`,
                     rasterlist$`Nagagami Forest`,
                     rasterlist$`Nipissing Forest`,
                     rasterlist$`Northshore Forest`,
                     rasterlist$`Ottawa Valley Forest`,
                     rasterlist$`Pic Forest`,
                     rasterlist$`Pineland Forest`,
                     rasterlist$`Romeo Malette Forest`,
                     rasterlist$`Spanish Forest`,
                     rasterlist$`Sudbury Forest`,
                     rasterlist$`Temagami Forest`,
                     rasterlist$`Timiskaming Forest`,
                     rasterlist$`White River Forest`,
                     fun=mean)
plot(drawnresults)

#now get same predictor for BCR 13, 
bcr13.ras<-raster(paste0(ROOT,"BCR 13/year 2010/simulation 1/AO-treed-wetland-on-2010.tif")) #temporary raster
origin(bcr13.ras)<-0
#cut out the bits in BCR 13 that are in "drawnresults",
#the reverse-clip or inverse mask is supposed to get rid of the parts of the 
#raster within the shapefile area
bcr13.ras.CL <- mask(bcr13.ras, WOTHxFMU.rp, inverse = TRUE)
plot(bcr13.ras.CL)
plot(bcr13.ras)
plot(bcr13.ras.CL)
#works!
#now attach to the rest of the FMUs
drawnresultsB<-mosaic(drawnresults, bcr13.ras.CL, fun=mean)
plot(drawnresultsB)
drawnresultsB[values(drawnresultsB)<0]<-0#get rid of negative values
drawnresultsC<-drawnresultsB/100#change units from percentage to proportion
plot(drawnresultsC)
writeRaster(drawnresultsC, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/TreedWetlandWOTHxFMU.tif", overwrite=TRUE)

#All Wooded Areas Combined
A<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/DenseConifWOTHxFMU.tif")
B<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/DenseDecidWOTHxFMU.tif")
C<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/DenseMixedWOTHxFMU.tif")
D<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/SparseUndifferentiatedForestWOTHxFMU.tif")
E<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/TreedWetlandWOTHxFMU.tif")

Anywooded<-A+B+C+D+E
plot(Anywooded)
writeRaster(Anywooded, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/AllWoodedAreasWOTHxFMU.tif", overwrite=TRUE)

#Single layer for Open or Non-Treed Wetland ON
#create empty list for storing rasters
rasterlist<-list()#empty list each time we draw a new number of samples

#read rasters for a specific predictor into list
for (j in FMUS){
  tempras<-raster(paste0(ROOT,j,"/year 2010/simulation 1/AO-open-wetland-on-2010.tif")) #temporary raster
  #rasters must all have common origin for mosaic function to work
  origin(tempras)<-0
  rasterlist[[j]]<-tempras#B#append temporary raster at each loop iteration to the list
}

#combine those separate rasters into a single layer
drawnresults<-mosaic(rasterlist$`Abitibi Forest`,
                     rasterlist$`Algoma Forest`,
                     rasterlist$`Algonquin Forest`,
                     rasterlist$`Bancroft Minden Forest`,
                     rasterlist$`Black Spruce Forest`,
                     rasterlist$`Boundary Waters Forest`,
                     rasterlist$`French Severn Forest`,
                     rasterlist$`Gorden Cosens Forest`,
                     rasterlist$`Hearst Forest`,
                     rasterlist$`Kenora Forest`,
                     rasterlist$`Lakehead Forest`,
                     rasterlist$`Mazinaw Lanark Forest`,
                     rasterlist$`Missinaibi Forest`,
                     rasterlist$`Nagagami Forest`,
                     rasterlist$`Nipissing Forest`,
                     rasterlist$`Northshore Forest`,
                     rasterlist$`Ottawa Valley Forest`,
                     rasterlist$`Pic Forest`,
                     rasterlist$`Pineland Forest`,
                     rasterlist$`Romeo Malette Forest`,
                     rasterlist$`Spanish Forest`,
                     rasterlist$`Sudbury Forest`,
                     rasterlist$`Temagami Forest`,
                     rasterlist$`Timiskaming Forest`,
                     rasterlist$`White River Forest`,
                     fun=mean)
plot(drawnresults)

#now get same predictor for BCR 13, 
bcr13.ras<-raster(paste0(ROOT,"BCR 13/year 2010/simulation 1/AO-open-wetland-on-2010.tif")) #temporary raster
origin(bcr13.ras)<-0
#cut out the bits in BCR 13 that are in "drawnresults",
#the reverse-clip or inverse mask is supposed to get rid of the parts of the 
#raster within the shapefile area
bcr13.ras.CL <- mask(bcr13.ras, WOTHxFMU.rp, inverse = TRUE)
plot(bcr13.ras.CL)
plot(bcr13.ras)
plot(bcr13.ras.CL)
#works!
#now attach to the rest of the FMUs
drawnresultsB<-mosaic(drawnresults, bcr13.ras.CL, fun=mean)
plot(drawnresultsB)
drawnresultsB[values(drawnresultsB)<0]<-0#get rid of negative values
drawnresultsC<-drawnresultsB/100#change units from percentage to proportion
plot(drawnresultsC)
writeRaster(drawnresultsC, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/OpenWetlandWOTHxFMU.tif", overwrite=TRUE)

#All Wetland Combined
F2<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/OpenWetlandWOTHxFMU.tif")

Anywetland<-E+F2#not F since F=FALSE
plot(Anywetland)
writeRaster(Anywetland, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/AllWetlandWOTHxFMU.tif", overwrite=TRUE)



##Water-Natural
#create empty list for storing rasters
rasterlist<-list()#empty list each time we draw a new number of samples

#read rasters for a specific predictor into list
for (j in FMUS){
  tempras<-raster(paste0(ROOT,j,"/year 2010/simulation 1/AO-water-natural-on-2010.tif")) #temporary raster
  #rasters must all have common origin for mosaic function to work
  origin(tempras)<-0
  rasterlist[[j]]<-tempras#B#append temporary raster at each loop iteration to the list
}

#combine those separate rasters into a single layer
drawnresults<-mosaic(rasterlist$`Abitibi Forest`,
                     rasterlist$`Algoma Forest`,
                     rasterlist$`Algonquin Forest`,
                     rasterlist$`Bancroft Minden Forest`,
                     rasterlist$`Black Spruce Forest`,
                     rasterlist$`Boundary Waters Forest`,
                     rasterlist$`French Severn Forest`,
                     rasterlist$`Gorden Cosens Forest`,
                     rasterlist$`Hearst Forest`,
                     rasterlist$`Kenora Forest`,
                     rasterlist$`Lakehead Forest`,
                     rasterlist$`Mazinaw Lanark Forest`,
                     rasterlist$`Missinaibi Forest`,
                     rasterlist$`Nagagami Forest`,
                     rasterlist$`Nipissing Forest`,
                     rasterlist$`Northshore Forest`,
                     rasterlist$`Ottawa Valley Forest`,
                     rasterlist$`Pic Forest`,
                     rasterlist$`Pineland Forest`,
                     rasterlist$`Romeo Malette Forest`,
                     rasterlist$`Spanish Forest`,
                     rasterlist$`Sudbury Forest`,
                     rasterlist$`Temagami Forest`,
                     rasterlist$`Timiskaming Forest`,
                     rasterlist$`White River Forest`,
                     fun=mean)
plot(drawnresults)

#now get same predictor for BCR 13, 
bcr13.ras<-raster(paste0(ROOT,"BCR 13/year 2010/simulation 1/AO-water-natural-on-2010.tif")) #temporary raster
origin(bcr13.ras)<-0
#cut out the bits in BCR 13 that are in "drawnresults",
#the reverse-clip or inverse mask is supposed to get rid of the parts of the 
#raster within the shapefile area
bcr13.ras.CL <- mask(bcr13.ras, WOTHxFMU.rp, inverse = TRUE)
plot(bcr13.ras.CL)
plot(bcr13.ras)
plot(bcr13.ras.CL)
#works!
#now attach to the rest of the FMUs
drawnresultsB<-mosaic(drawnresults, bcr13.ras.CL, fun=mean)
plot(drawnresultsB)
drawnresultsB[values(drawnresultsB)<0]<-0#get rid of negative values
drawnresultsC<-drawnresultsB/100#change units from percentage to proportion
plot(drawnresultsC)
writeRaster(drawnresultsC, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/WaterNaturalWOTHxFMU.tif", overwrite=TRUE)

##Water-Anthropogenic
#create empty list for storing rasters
rasterlist<-list()#empty list each time we draw a new number of samples

#read rasters for a specific predictor into list
for (j in FMUS){
  tempras<-raster(paste0(ROOT,j,"/year 2010/simulation 1/AO-water-anthropogenic-on-2010.tif")) #temporary raster
  #rasters must all have common origin for mosaic function to work
  origin(tempras)<-0
  rasterlist[[j]]<-tempras#B#append temporary raster at each loop iteration to the list
}

#combine those separate rasters into a single layer
drawnresults<-mosaic(rasterlist$`Abitibi Forest`,
                     rasterlist$`Algoma Forest`,
                     rasterlist$`Algonquin Forest`,
                     rasterlist$`Bancroft Minden Forest`,
                     rasterlist$`Black Spruce Forest`,
                     rasterlist$`Boundary Waters Forest`,
                     rasterlist$`French Severn Forest`,
                     rasterlist$`Gorden Cosens Forest`,
                     rasterlist$`Hearst Forest`,
                     rasterlist$`Kenora Forest`,
                     rasterlist$`Lakehead Forest`,
                     rasterlist$`Mazinaw Lanark Forest`,
                     rasterlist$`Missinaibi Forest`,
                     rasterlist$`Nagagami Forest`,
                     rasterlist$`Nipissing Forest`,
                     rasterlist$`Northshore Forest`,
                     rasterlist$`Ottawa Valley Forest`,
                     rasterlist$`Pic Forest`,
                     rasterlist$`Pineland Forest`,
                     rasterlist$`Romeo Malette Forest`,
                     rasterlist$`Spanish Forest`,
                     rasterlist$`Sudbury Forest`,
                     rasterlist$`Temagami Forest`,
                     rasterlist$`Timiskaming Forest`,
                     rasterlist$`White River Forest`,
                     fun=mean)
plot(drawnresults)

#now get same predictor for BCR 13, 
bcr13.ras<-raster(paste0(ROOT,"BCR 13/year 2010/simulation 1/AO-water-anthropogenic-on-2010.tif")) #temporary raster
origin(bcr13.ras)<-0
#cut out the bits in BCR 13 that are in "drawnresults",
#the reverse-clip or inverse mask is supposed to get rid of the parts of the 
#raster within the shapefile area
bcr13.ras.CL <- mask(bcr13.ras, WOTHxFMU.rp, inverse = TRUE)
plot(bcr13.ras.CL)
plot(bcr13.ras)
plot(bcr13.ras.CL)
#works!
#now attach to the rest of the FMUs
drawnresultsB<-mosaic(drawnresults, bcr13.ras.CL, fun=mean)
plot(drawnresultsB)
drawnresultsB[values(drawnresultsB)<0]<-0#get rid of negative values
drawnresultsC<-drawnresultsB/100#change units from percentage to proportion
plot(drawnresultsC)
writeRaster(drawnresultsC, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/WaterAnthropogenicWOTHxFMU.tif", overwrite=TRUE)

G<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/WaterNaturalWOTHxFMU.tif")
H<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/WaterAnthropogenicWOTHxFMU.tif")
OpenWater<-G+H
writeRaster(OpenWater, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/OpenWaterWOTHxFMU.tif", overwrite=TRUE)

#Grassland ON
#create empty list for storing rasters
rasterlist<-list()#empty list each time we draw a new number of samples

#read rasters for a specific predictor into list
for (j in FMUS){
  tempras<-raster(paste0(ROOT,j,"/year 2010/simulation 1/AO-grass-on-2010.tif")) #temporary raster
  #rasters must all have common origin for mosaic function to work
  origin(tempras)<-0
  rasterlist[[j]]<-tempras#B#append temporary raster at each loop iteration to the list
}

#combine those separate rasters into a single layer
drawnresults<-mosaic(rasterlist$`Abitibi Forest`,
                     rasterlist$`Algoma Forest`,
                     rasterlist$`Algonquin Forest`,
                     rasterlist$`Bancroft Minden Forest`,
                     rasterlist$`Black Spruce Forest`,
                     rasterlist$`Boundary Waters Forest`,
                     rasterlist$`French Severn Forest`,
                     rasterlist$`Gorden Cosens Forest`,
                     rasterlist$`Hearst Forest`,
                     rasterlist$`Kenora Forest`,
                     rasterlist$`Lakehead Forest`,
                     rasterlist$`Mazinaw Lanark Forest`,
                     rasterlist$`Missinaibi Forest`,
                     rasterlist$`Nagagami Forest`,
                     rasterlist$`Nipissing Forest`,
                     rasterlist$`Northshore Forest`,
                     rasterlist$`Ottawa Valley Forest`,
                     rasterlist$`Pic Forest`,
                     rasterlist$`Pineland Forest`,
                     rasterlist$`Romeo Malette Forest`,
                     rasterlist$`Spanish Forest`,
                     rasterlist$`Sudbury Forest`,
                     rasterlist$`Temagami Forest`,
                     rasterlist$`Timiskaming Forest`,
                     rasterlist$`White River Forest`,
                     fun=mean)
plot(drawnresults)

#now get same predictor for BCR 13, 
bcr13.ras<-raster(paste0(ROOT,"BCR 13/year 2010/simulation 1/AO-grass-on-2010.tif")) #temporary raster
origin(bcr13.ras)<-0
#cut out the bits in BCR 13 that are in "drawnresults",
#the reverse-clip or inverse mask is supposed to get rid of the parts of the 
#raster within the shapefile area
bcr13.ras.CL <- mask(bcr13.ras, WOTHxFMU.rp, inverse = TRUE)
plot(bcr13.ras.CL)
plot(bcr13.ras)
plot(bcr13.ras.CL)
#works!
#now attach to the rest of the FMUs
drawnresultsB<-mosaic(drawnresults, bcr13.ras.CL, fun=mean)
plot(drawnresultsB)
drawnresultsB[values(drawnresultsB)<0]<-0#get rid of negative values
drawnresultsC<-drawnresultsB/100#change units from percentage to proportion
plot(drawnresultsC)
writeRaster(drawnresultsC, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/GrasslandWOTHxFMU.tif", overwrite=TRUE)


#Alvar ON
#create empty list for storing rasters
rasterlist<-list()#empty list each time we draw a new number of samples

#read rasters for a specific predictor into list
for (j in FMUS){
  tempras<-raster(paste0(ROOT,j,"/year 2010/simulation 1/AO-alvar-on-2010.tif")) #temporary raster
  #rasters must all have common origin for mosaic function to work
  origin(tempras)<-0
  rasterlist[[j]]<-tempras#B#append temporary raster at each loop iteration to the list
}

#combine those separate rasters into a single layer
drawnresults<-mosaic(rasterlist$`Abitibi Forest`,
                     rasterlist$`Algoma Forest`,
                     rasterlist$`Algonquin Forest`,
                     rasterlist$`Bancroft Minden Forest`,
                     rasterlist$`Black Spruce Forest`,
                     rasterlist$`Boundary Waters Forest`,
                     rasterlist$`French Severn Forest`,
                     rasterlist$`Gorden Cosens Forest`,
                     rasterlist$`Hearst Forest`,
                     rasterlist$`Kenora Forest`,
                     rasterlist$`Lakehead Forest`,
                     rasterlist$`Mazinaw Lanark Forest`,
                     rasterlist$`Missinaibi Forest`,
                     rasterlist$`Nagagami Forest`,
                     rasterlist$`Nipissing Forest`,
                     rasterlist$`Northshore Forest`,
                     rasterlist$`Ottawa Valley Forest`,
                     rasterlist$`Pic Forest`,
                     rasterlist$`Pineland Forest`,
                     rasterlist$`Romeo Malette Forest`,
                     rasterlist$`Spanish Forest`,
                     rasterlist$`Sudbury Forest`,
                     rasterlist$`Temagami Forest`,
                     rasterlist$`Timiskaming Forest`,
                     rasterlist$`White River Forest`,
                     fun=mean)
plot(drawnresults)

#now get same predictor for BCR 13, 
bcr13.ras<-raster(paste0(ROOT,"BCR 13/year 2010/simulation 1/AO-alvar-on-2010.tif")) #temporary raster
origin(bcr13.ras)<-0
#cut out the bits in BCR 13 that are in "drawnresults",
#the reverse-clip or inverse mask is supposed to get rid of the parts of the 
#raster within the shapefile area
bcr13.ras.CL <- mask(bcr13.ras, WOTHxFMU.rp, inverse = TRUE)
plot(bcr13.ras.CL)
plot(bcr13.ras)
plot(bcr13.ras.CL)
#works!
#now attach to the rest of the FMUs
drawnresultsB<-mosaic(drawnresults, bcr13.ras.CL, fun=mean)
plot(drawnresultsB)
drawnresultsB[values(drawnresultsB)<0]<-0#get rid of negative values
drawnresultsC<-drawnresultsB/100#change units from percentage to proportion
plot(drawnresultsC)
writeRaster(drawnresultsC, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/AlvarWOTHxFMU.tif", overwrite=TRUE)

#Rock ON
#create empty list for storing rasters
rasterlist<-list()#empty list each time we draw a new number of samples

#read rasters for a specific predictor into list
for (j in FMUS){
  tempras<-raster(paste0(ROOT,j,"/year 2010/simulation 1/AO-rock-on-2010.tif")) #temporary raster
  #rasters must all have common origin for mosaic function to work
  origin(tempras)<-0
  rasterlist[[j]]<-tempras#B#append temporary raster at each loop iteration to the list
}

#combine those separate rasters into a single layer
drawnresults<-mosaic(rasterlist$`Abitibi Forest`,
                     rasterlist$`Algoma Forest`,
                     rasterlist$`Algonquin Forest`,
                     rasterlist$`Bancroft Minden Forest`,
                     rasterlist$`Black Spruce Forest`,
                     rasterlist$`Boundary Waters Forest`,
                     rasterlist$`French Severn Forest`,
                     rasterlist$`Gorden Cosens Forest`,
                     rasterlist$`Hearst Forest`,
                     rasterlist$`Kenora Forest`,
                     rasterlist$`Lakehead Forest`,
                     rasterlist$`Mazinaw Lanark Forest`,
                     rasterlist$`Missinaibi Forest`,
                     rasterlist$`Nagagami Forest`,
                     rasterlist$`Nipissing Forest`,
                     rasterlist$`Northshore Forest`,
                     rasterlist$`Ottawa Valley Forest`,
                     rasterlist$`Pic Forest`,
                     rasterlist$`Pineland Forest`,
                     rasterlist$`Romeo Malette Forest`,
                     rasterlist$`Spanish Forest`,
                     rasterlist$`Sudbury Forest`,
                     rasterlist$`Temagami Forest`,
                     rasterlist$`Timiskaming Forest`,
                     rasterlist$`White River Forest`,
                     fun=mean)
plot(drawnresults)

#now get same predictor for BCR 13, 
bcr13.ras<-raster(paste0(ROOT,"BCR 13/year 2010/simulation 1/AO-rock-on-2010.tif")) #temporary raster
origin(bcr13.ras)<-0
#cut out the bits in BCR 13 that are in "drawnresults",
#the reverse-clip or inverse mask is supposed to get rid of the parts of the 
#raster within the shapefile area
bcr13.ras.CL <- mask(bcr13.ras, WOTHxFMU.rp, inverse = TRUE)
plot(bcr13.ras.CL)
plot(bcr13.ras)
plot(bcr13.ras.CL)
#works!
#now attach to the rest of the FMUs
drawnresultsB<-mosaic(drawnresults, bcr13.ras.CL, fun=mean)
plot(drawnresultsB)
drawnresultsB[values(drawnresultsB)<0]<-0#get rid of negative values
drawnresultsC<-drawnresultsB/100#change units from percentage to proportion
plot(drawnresultsC)
writeRaster(drawnresultsC, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/RockWOTHxFMU.tif", overwrite=TRUE)


#Sand and Gravel ON
#create empty list for storing rasters
rasterlist<-list()#empty list each time we draw a new number of samples

#read rasters for a specific predictor into list
for (j in FMUS){
  tempras<-raster(paste0(ROOT,j,"/year 2010/simulation 1/AO-sand-and-gravel-on-2010.tif")) #temporary raster
  #rasters must all have common origin for mosaic function to work
  origin(tempras)<-0
  rasterlist[[j]]<-tempras#B#append temporary raster at each loop iteration to the list
}

#combine those separate rasters into a single layer
drawnresults<-mosaic(rasterlist$`Abitibi Forest`,
                     rasterlist$`Algoma Forest`,
                     rasterlist$`Algonquin Forest`,
                     rasterlist$`Bancroft Minden Forest`,
                     rasterlist$`Black Spruce Forest`,
                     rasterlist$`Boundary Waters Forest`,
                     rasterlist$`French Severn Forest`,
                     rasterlist$`Gorden Cosens Forest`,
                     rasterlist$`Hearst Forest`,
                     rasterlist$`Kenora Forest`,
                     rasterlist$`Lakehead Forest`,
                     rasterlist$`Mazinaw Lanark Forest`,
                     rasterlist$`Missinaibi Forest`,
                     rasterlist$`Nagagami Forest`,
                     rasterlist$`Nipissing Forest`,
                     rasterlist$`Northshore Forest`,
                     rasterlist$`Ottawa Valley Forest`,
                     rasterlist$`Pic Forest`,
                     rasterlist$`Pineland Forest`,
                     rasterlist$`Romeo Malette Forest`,
                     rasterlist$`Spanish Forest`,
                     rasterlist$`Sudbury Forest`,
                     rasterlist$`Temagami Forest`,
                     rasterlist$`Timiskaming Forest`,
                     rasterlist$`White River Forest`,
                     fun=mean)
plot(drawnresults)

#now get same predictor for BCR 13, 
bcr13.ras<-raster(paste0(ROOT,"BCR 13/year 2010/simulation 1/AO-sand-and-gravel-on-2010.tif")) #temporary raster
origin(bcr13.ras)<-0
#cut out the bits in BCR 13 that are in "drawnresults",
#the reverse-clip or inverse mask is supposed to get rid of the parts of the 
#raster within the shapefile area
bcr13.ras.CL <- mask(bcr13.ras, WOTHxFMU.rp, inverse = TRUE)
plot(bcr13.ras.CL)
plot(bcr13.ras)
plot(bcr13.ras.CL)
#works!
#now attach to the rest of the FMUs
drawnresultsB<-mosaic(drawnresults, bcr13.ras.CL, fun=mean)
plot(drawnresultsB)
drawnresultsB[values(drawnresultsB)<0]<-0#get rid of negative values
drawnresultsC<-drawnresultsB/100#change units from percentage to proportion
plot(drawnresultsC)
writeRaster(drawnresultsC, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/SandGravelWOTHxFMU.tif", overwrite=TRUE)


#Waste ON
#create empty list for storing rasters
rasterlist<-list()#empty list each time we draw a new number of samples

#read rasters for a specific predictor into list
for (j in FMUS){
  tempras<-raster(paste0(ROOT,j,"/year 2010/simulation 1/AO-waste-on-2010.tif")) #temporary raster
  #rasters must all have common origin for mosaic function to work
  origin(tempras)<-0
  rasterlist[[j]]<-tempras#B#append temporary raster at each loop iteration to the list
}

#combine those separate rasters into a single layer
drawnresults<-mosaic(rasterlist$`Abitibi Forest`,
                     rasterlist$`Algoma Forest`,
                     rasterlist$`Algonquin Forest`,
                     rasterlist$`Bancroft Minden Forest`,
                     rasterlist$`Black Spruce Forest`,
                     rasterlist$`Boundary Waters Forest`,
                     rasterlist$`French Severn Forest`,
                     rasterlist$`Gorden Cosens Forest`,
                     rasterlist$`Hearst Forest`,
                     rasterlist$`Kenora Forest`,
                     rasterlist$`Lakehead Forest`,
                     rasterlist$`Mazinaw Lanark Forest`,
                     rasterlist$`Missinaibi Forest`,
                     rasterlist$`Nagagami Forest`,
                     rasterlist$`Nipissing Forest`,
                     rasterlist$`Northshore Forest`,
                     rasterlist$`Ottawa Valley Forest`,
                     rasterlist$`Pic Forest`,
                     rasterlist$`Pineland Forest`,
                     rasterlist$`Romeo Malette Forest`,
                     rasterlist$`Spanish Forest`,
                     rasterlist$`Sudbury Forest`,
                     rasterlist$`Temagami Forest`,
                     rasterlist$`Timiskaming Forest`,
                     rasterlist$`White River Forest`,
                     fun=mean)
plot(drawnresults)

#now get same predictor for BCR 13, 
bcr13.ras<-raster(paste0(ROOT,"BCR 13/year 2010/simulation 1/AO-waste-on-2010.tif")) #temporary raster
origin(bcr13.ras)<-0
#cut out the bits in BCR 13 that are in "drawnresults",
#the reverse-clip or inverse mask is supposed to get rid of the parts of the 
#raster within the shapefile area
bcr13.ras.CL <- mask(bcr13.ras, WOTHxFMU.rp, inverse = TRUE)
plot(bcr13.ras.CL)
plot(bcr13.ras)
plot(bcr13.ras.CL)
#works!
#now attach to the rest of the FMUs
drawnresultsB<-mosaic(drawnresults, bcr13.ras.CL, fun=mean)
plot(drawnresultsB)
drawnresultsB[values(drawnresultsB)<0]<-0#get rid of negative values
drawnresultsC<-drawnresultsB/100#change units from percentage to proportion
plot(drawnresultsC)
writeRaster(drawnresultsC, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/WasteWOTHxFMU.tif", overwrite=TRUE)

#Total Barren Lands
I<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/AlvarWOTHxFMU.tif")
J<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/RockWOTHxFMU.tif")
K<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/SandGravelWOTHxFMU.tif")
L<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/WasteWOTHxFMU.tif")
Barren<-I+J+K+L
writeRaster(Barren, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/BarrenWOTHxFMU.tif", overwrite=TRUE)


#Agriculture ON
#create empty list for storing rasters
rasterlist<-list()#empty list each time we draw a new number of samples

#read rasters for a specific predictor into list
for (j in FMUS){
  tempras<-raster(paste0(ROOT,j,"/year 2010/simulation 1/AO-agriculture-on-2010.tif")) #temporary raster
  #rasters must all have common origin for mosaic function to work
  origin(tempras)<-0
  rasterlist[[j]]<-tempras#B#append temporary raster at each loop iteration to the list
}

#combine those separate rasters into a single layer
drawnresults<-mosaic(rasterlist$`Abitibi Forest`,
                     rasterlist$`Algoma Forest`,
                     rasterlist$`Algonquin Forest`,
                     rasterlist$`Bancroft Minden Forest`,
                     rasterlist$`Black Spruce Forest`,
                     rasterlist$`Boundary Waters Forest`,
                     rasterlist$`French Severn Forest`,
                     rasterlist$`Gorden Cosens Forest`,
                     rasterlist$`Hearst Forest`,
                     rasterlist$`Kenora Forest`,
                     rasterlist$`Lakehead Forest`,
                     rasterlist$`Mazinaw Lanark Forest`,
                     rasterlist$`Missinaibi Forest`,
                     rasterlist$`Nagagami Forest`,
                     rasterlist$`Nipissing Forest`,
                     rasterlist$`Northshore Forest`,
                     rasterlist$`Ottawa Valley Forest`,
                     rasterlist$`Pic Forest`,
                     rasterlist$`Pineland Forest`,
                     rasterlist$`Romeo Malette Forest`,
                     rasterlist$`Spanish Forest`,
                     rasterlist$`Sudbury Forest`,
                     rasterlist$`Temagami Forest`,
                     rasterlist$`Timiskaming Forest`,
                     rasterlist$`White River Forest`,
                     fun=mean)
plot(drawnresults)

#now get same predictor for BCR 13, 
bcr13.ras<-raster(paste0(ROOT,"BCR 13/year 2010/simulation 1/AO-agriculture-on-2010.tif")) #temporary raster
origin(bcr13.ras)<-0
#cut out the bits in BCR 13 that are in "drawnresults",
#the reverse-clip or inverse mask is supposed to get rid of the parts of the 
#raster within the shapefile area
bcr13.ras.CL <- mask(bcr13.ras, WOTHxFMU.rp, inverse = TRUE)
plot(bcr13.ras.CL)
plot(bcr13.ras)
plot(bcr13.ras.CL)
#works!
#now attach to the rest of the FMUs
drawnresultsB<-mosaic(drawnresults, bcr13.ras.CL, fun=mean)
plot(drawnresultsB)
drawnresultsB[values(drawnresultsB)<0]<-0#get rid of negative values
drawnresultsC<-drawnresultsB/100#change units from percentage to proportion
plot(drawnresultsC)
writeRaster(drawnresultsC, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/AgricultureWOTHxFMU.tif", overwrite=TRUE)


#Airport ON
#create empty list for storing rasters
rasterlist<-list()#empty list each time we draw a new number of samples

#read rasters for a specific predictor into list
for (j in FMUS){
  tempras<-raster(paste0(ROOT,j,"/year 2010/simulation 1/AO-airport-on-2010.tif")) #temporary raster
  #rasters must all have common origin for mosaic function to work
  origin(tempras)<-0
  rasterlist[[j]]<-tempras#B#append temporary raster at each loop iteration to the list
}

#combine those separate rasters into a single layer
drawnresults<-mosaic(rasterlist$`Abitibi Forest`,
                     rasterlist$`Algoma Forest`,
                     rasterlist$`Algonquin Forest`,
                     rasterlist$`Bancroft Minden Forest`,
                     rasterlist$`Black Spruce Forest`,
                     rasterlist$`Boundary Waters Forest`,
                     rasterlist$`French Severn Forest`,
                     rasterlist$`Gorden Cosens Forest`,
                     rasterlist$`Hearst Forest`,
                     rasterlist$`Kenora Forest`,
                     rasterlist$`Lakehead Forest`,
                     rasterlist$`Mazinaw Lanark Forest`,
                     rasterlist$`Missinaibi Forest`,
                     rasterlist$`Nagagami Forest`,
                     rasterlist$`Nipissing Forest`,
                     rasterlist$`Northshore Forest`,
                     rasterlist$`Ottawa Valley Forest`,
                     rasterlist$`Pic Forest`,
                     rasterlist$`Pineland Forest`,
                     rasterlist$`Romeo Malette Forest`,
                     rasterlist$`Spanish Forest`,
                     rasterlist$`Sudbury Forest`,
                     rasterlist$`Temagami Forest`,
                     rasterlist$`Timiskaming Forest`,
                     rasterlist$`White River Forest`,
                     fun=mean)
plot(drawnresults)

#now get same predictor for BCR 13, 
bcr13.ras<-raster(paste0(ROOT,"BCR 13/year 2010/simulation 1/AO-airport-on-2010.tif")) #temporary raster
origin(bcr13.ras)<-0
#cut out the bits in BCR 13 that are in "drawnresults",
#the reverse-clip or inverse mask is supposed to get rid of the parts of the 
#raster within the shapefile area
bcr13.ras.CL <- mask(bcr13.ras, WOTHxFMU.rp, inverse = TRUE)
plot(bcr13.ras.CL)
plot(bcr13.ras)
plot(bcr13.ras.CL)
#works!
#now attach to the rest of the FMUs
drawnresultsB<-mosaic(drawnresults, bcr13.ras.CL, fun=mean)
plot(drawnresultsB)
drawnresultsB[values(drawnresultsB)<0]<-0#get rid of negative values
drawnresultsC<-drawnresultsB/100#change units from percentage to proportion
plot(drawnresultsC)
writeRaster(drawnresultsC, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/AirportWOTHxFMU.tif", overwrite=TRUE)

#Settlement and Infrastructure ON
#create empty list for storing rasters
rasterlist<-list()#empty list each time we draw a new number of samples

#read rasters for a specific predictor into list
for (j in FMUS){
  tempras<-raster(paste0(ROOT,j,"/year 2010/simulation 1/AO-settlement-and-infrastructure-on-2010.tif")) #temporary raster
  #rasters must all have common origin for mosaic function to work
  origin(tempras)<-0
  rasterlist[[j]]<-tempras#B#append temporary raster at each loop iteration to the list
}

#combine those separate rasters into a single layer
drawnresults<-mosaic(rasterlist$`Abitibi Forest`,
                     rasterlist$`Algoma Forest`,
                     rasterlist$`Algonquin Forest`,
                     rasterlist$`Bancroft Minden Forest`,
                     rasterlist$`Black Spruce Forest`,
                     rasterlist$`Boundary Waters Forest`,
                     rasterlist$`French Severn Forest`,
                     rasterlist$`Gorden Cosens Forest`,
                     rasterlist$`Hearst Forest`,
                     rasterlist$`Kenora Forest`,
                     rasterlist$`Lakehead Forest`,
                     rasterlist$`Mazinaw Lanark Forest`,
                     rasterlist$`Missinaibi Forest`,
                     rasterlist$`Nagagami Forest`,
                     rasterlist$`Nipissing Forest`,
                     rasterlist$`Northshore Forest`,
                     rasterlist$`Ottawa Valley Forest`,
                     rasterlist$`Pic Forest`,
                     rasterlist$`Pineland Forest`,
                     rasterlist$`Romeo Malette Forest`,
                     rasterlist$`Spanish Forest`,
                     rasterlist$`Sudbury Forest`,
                     rasterlist$`Temagami Forest`,
                     rasterlist$`Timiskaming Forest`,
                     rasterlist$`White River Forest`,
                     fun=mean)
plot(drawnresults)

#now get same predictor for BCR 13, 
bcr13.ras<-raster(paste0(ROOT,"BCR 13/year 2010/simulation 1/AO-settlement-and-infrastructure-on-2010.tif")) #temporary raster
origin(bcr13.ras)<-0
#cut out the bits in BCR 13 that are in "drawnresults",
#the reverse-clip or inverse mask is supposed to get rid of the parts of the 
#raster within the shapefile area
bcr13.ras.CL <- mask(bcr13.ras, WOTHxFMU.rp, inverse = TRUE)
plot(bcr13.ras.CL)
plot(bcr13.ras)
plot(bcr13.ras.CL)
#works!
#now attach to the rest of the FMUs
drawnresultsB<-mosaic(drawnresults, bcr13.ras.CL, fun=mean)
plot(drawnresultsB)
drawnresultsB[values(drawnresultsB)<0]<-0#get rid of negative values
drawnresultsC<-drawnresultsB/100#change units from percentage to proportion
plot(drawnresultsC)
writeRaster(drawnresultsC, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/SettlementInfrastructureWOTHxFMU.tif", overwrite=TRUE)

#Total Urban
M<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/AirportWOTHxFMU.tif")
N<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/SettlementInfrastructureWOTHxFMU.tif")
Urban<-M+N
writeRaster(Urban, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/UrbanWOTHxFMU.tif", overwrite=TRUE)


#Primary Roads
#create empty list for storing rasters
rasterlist<-list()#empty list each time we draw a new number of samples

#read rasters for a specific predictor into list
for (j in FMUS){
  tempras<-raster(paste0(ROOT,j,"/year 2010/simulation 1/AO-road-primary-on-2010.tif")) #temporary raster
  #rasters must all have common origin for mosaic function to work
  origin(tempras)<-0
  rasterlist[[j]]<-tempras#B#append temporary raster at each loop iteration to the list
}

#combine those separate rasters into a single layer
drawnresults<-mosaic(rasterlist$`Abitibi Forest`,
                     rasterlist$`Algoma Forest`,
                     rasterlist$`Algonquin Forest`,
                     rasterlist$`Bancroft Minden Forest`,
                     rasterlist$`Black Spruce Forest`,
                     rasterlist$`Boundary Waters Forest`,
                     rasterlist$`French Severn Forest`,
                     rasterlist$`Gorden Cosens Forest`,
                     rasterlist$`Hearst Forest`,
                     rasterlist$`Kenora Forest`,
                     rasterlist$`Lakehead Forest`,
                     rasterlist$`Mazinaw Lanark Forest`,
                     rasterlist$`Missinaibi Forest`,
                     rasterlist$`Nagagami Forest`,
                     rasterlist$`Nipissing Forest`,
                     rasterlist$`Northshore Forest`,
                     rasterlist$`Ottawa Valley Forest`,
                     rasterlist$`Pic Forest`,
                     rasterlist$`Pineland Forest`,
                     rasterlist$`Romeo Malette Forest`,
                     rasterlist$`Spanish Forest`,
                     rasterlist$`Sudbury Forest`,
                     rasterlist$`Temagami Forest`,
                     rasterlist$`Timiskaming Forest`,
                     rasterlist$`White River Forest`,
                     fun=mean)
plot(drawnresults)

#now get same predictor for BCR 13, 
bcr13.ras<-raster(paste0(ROOT,"BCR 13/year 2010/simulation 1/AO-road-primary-on-2010.tif")) #temporary raster
origin(bcr13.ras)<-0
#cut out the bits in BCR 13 that are in "drawnresults",
#the reverse-clip or inverse mask is supposed to get rid of the parts of the 
#raster within the shapefile area
bcr13.ras.CL <- mask(bcr13.ras, WOTHxFMU.rp, inverse = TRUE)
plot(bcr13.ras.CL)
plot(bcr13.ras)
plot(bcr13.ras.CL)
#works!
#now attach to the rest of the FMUs
drawnresultsB<-mosaic(drawnresults, bcr13.ras.CL, fun=mean)
plot(drawnresultsB)
drawnresultsB[values(drawnresultsB)<0]<-0#get rid of negative values
drawnresultsC<-drawnresultsB/100#change units from percentage to proportion
plot(drawnresultsC)
writeRaster(drawnresultsC, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/RoadPrimaryWOTHxFMU.tif", overwrite=TRUE)


#Secondary and All-season Roads
#create empty list for storing rasters
rasterlist<-list()#empty list each time we draw a new number of samples

#read rasters for a specific predictor into list
for (j in FMUS){
  tempras<-raster(paste0(ROOT,j,"/year 2010/simulation 1/AO-road-secondaryall-season-on-2010.tif")) #temporary raster
  #rasters must all have common origin for mosaic function to work
  origin(tempras)<-0
  rasterlist[[j]]<-tempras#B#append temporary raster at each loop iteration to the list
}

#combine those separate rasters into a single layer
drawnresults<-mosaic(rasterlist$`Abitibi Forest`,
                     rasterlist$`Algoma Forest`,
                     rasterlist$`Algonquin Forest`,
                     rasterlist$`Bancroft Minden Forest`,
                     rasterlist$`Black Spruce Forest`,
                     rasterlist$`Boundary Waters Forest`,
                     rasterlist$`French Severn Forest`,
                     rasterlist$`Gorden Cosens Forest`,
                     rasterlist$`Hearst Forest`,
                     rasterlist$`Kenora Forest`,
                     rasterlist$`Lakehead Forest`,
                     rasterlist$`Mazinaw Lanark Forest`,
                     rasterlist$`Missinaibi Forest`,
                     rasterlist$`Nagagami Forest`,
                     rasterlist$`Nipissing Forest`,
                     rasterlist$`Northshore Forest`,
                     rasterlist$`Ottawa Valley Forest`,
                     rasterlist$`Pic Forest`,
                     rasterlist$`Pineland Forest`,
                     rasterlist$`Romeo Malette Forest`,
                     rasterlist$`Spanish Forest`,
                     rasterlist$`Sudbury Forest`,
                     rasterlist$`Temagami Forest`,
                     rasterlist$`Timiskaming Forest`,
                     rasterlist$`White River Forest`,
                     fun=mean)
plot(drawnresults)

#now get same predictor for BCR 13, 
bcr13.ras<-raster(paste0(ROOT,"BCR 13/year 2010/simulation 1/AO-road-secondaryall-season-on-2010.tif")) #temporary raster
origin(bcr13.ras)<-0
#cut out the bits in BCR 13 that are in "drawnresults",
#the reverse-clip or inverse mask is supposed to get rid of the parts of the 
#raster within the shapefile area
bcr13.ras.CL <- mask(bcr13.ras, WOTHxFMU.rp, inverse = TRUE)
plot(bcr13.ras.CL)
plot(bcr13.ras)
plot(bcr13.ras.CL)
#works!
#now attach to the rest of the FMUs
drawnresultsB<-mosaic(drawnresults, bcr13.ras.CL, fun=mean)
plot(drawnresultsB)
drawnresultsB[values(drawnresultsB)<0]<-0#get rid of negative values
drawnresultsC<-drawnresultsB/100#change units from percentage to proportion
plot(drawnresultsC)
writeRaster(drawnresultsC, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/RoadSecondaryAllSeasonWOTHxFMU.tif", overwrite=TRUE)


#Tertiary Resource Roads
#create empty list for storing rasters
rasterlist<-list()#empty list each time we draw a new number of samples

#read rasters for a specific predictor into list
for (j in FMUS){
  tempras<-raster(paste0(ROOT,j,"/year 2010/simulation 1/AO-road-tertiaryresource-on-2010.tif")) #temporary raster
  #rasters must all have common origin for mosaic function to work
  origin(tempras)<-0
  rasterlist[[j]]<-tempras#B#append temporary raster at each loop iteration to the list
}

#combine those separate rasters into a single layer
drawnresults<-mosaic(rasterlist$`Abitibi Forest`,
                     rasterlist$`Algoma Forest`,
                     rasterlist$`Algonquin Forest`,
                     rasterlist$`Bancroft Minden Forest`,
                     rasterlist$`Black Spruce Forest`,
                     rasterlist$`Boundary Waters Forest`,
                     rasterlist$`French Severn Forest`,
                     rasterlist$`Gorden Cosens Forest`,
                     rasterlist$`Hearst Forest`,
                     rasterlist$`Kenora Forest`,
                     rasterlist$`Lakehead Forest`,
                     rasterlist$`Mazinaw Lanark Forest`,
                     rasterlist$`Missinaibi Forest`,
                     rasterlist$`Nagagami Forest`,
                     rasterlist$`Nipissing Forest`,
                     rasterlist$`Northshore Forest`,
                     rasterlist$`Ottawa Valley Forest`,
                     rasterlist$`Pic Forest`,
                     rasterlist$`Pineland Forest`,
                     rasterlist$`Romeo Malette Forest`,
                     rasterlist$`Spanish Forest`,
                     rasterlist$`Sudbury Forest`,
                     rasterlist$`Temagami Forest`,
                     rasterlist$`Timiskaming Forest`,
                     rasterlist$`White River Forest`,
                     fun=mean)
plot(drawnresults)

#now get same predictor for BCR 13, 
bcr13.ras<-raster(paste0(ROOT,"BCR 13/year 2010/simulation 1/AO-road-tertiaryresource-on-2010.tif")) #temporary raster
origin(bcr13.ras)<-0
#cut out the bits in BCR 13 that are in "drawnresults",
#the reverse-clip or inverse mask is supposed to get rid of the parts of the 
#raster within the shapefile area
bcr13.ras.CL <- mask(bcr13.ras, WOTHxFMU.rp, inverse = TRUE)
plot(bcr13.ras.CL)
plot(bcr13.ras)
plot(bcr13.ras.CL)
#works!
#now attach to the rest of the FMUs
drawnresultsB<-mosaic(drawnresults, bcr13.ras.CL, fun=mean)
plot(drawnresultsB)
drawnresultsB[values(drawnresultsB)<0]<-0#get rid of negative values
drawnresultsC<-drawnresultsB/100#change units from percentage to proportion
plot(drawnresultsC)
writeRaster(drawnresultsC, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/RoadTertiaryResourceWOTHxFMU.tif", overwrite=TRUE)



#Winter Roads
#create empty list for storing rasters
rasterlist<-list()#empty list each time we draw a new number of samples

#read rasters for a specific predictor into list
for (j in FMUS){
  tempras<-raster(paste0(ROOT,j,"/year 2010/simulation 1/AO-road-winter-on-2010.tif")) #temporary raster
  #rasters must all have common origin for mosaic function to work
  origin(tempras)<-0
  rasterlist[[j]]<-tempras#B#append temporary raster at each loop iteration to the list
}

#combine those separate rasters into a single layer
drawnresults<-mosaic(rasterlist$`Abitibi Forest`,
                     rasterlist$`Algoma Forest`,
                     rasterlist$`Algonquin Forest`,
                     rasterlist$`Bancroft Minden Forest`,
                     rasterlist$`Black Spruce Forest`,
                     rasterlist$`Boundary Waters Forest`,
                     rasterlist$`French Severn Forest`,
                     rasterlist$`Gorden Cosens Forest`,
                     rasterlist$`Hearst Forest`,
                     rasterlist$`Kenora Forest`,
                     rasterlist$`Lakehead Forest`,
                     rasterlist$`Mazinaw Lanark Forest`,
                     rasterlist$`Missinaibi Forest`,
                     rasterlist$`Nagagami Forest`,
                     rasterlist$`Nipissing Forest`,
                     rasterlist$`Northshore Forest`,
                     rasterlist$`Ottawa Valley Forest`,
                     rasterlist$`Pic Forest`,
                     rasterlist$`Pineland Forest`,
                     rasterlist$`Romeo Malette Forest`,
                     rasterlist$`Spanish Forest`,
                     rasterlist$`Sudbury Forest`,
                     rasterlist$`Temagami Forest`,
                     rasterlist$`Timiskaming Forest`,
                     rasterlist$`White River Forest`,
                     fun=mean)
plot(drawnresults)

#now get same predictor for BCR 13, 
bcr13.ras<-raster(paste0(ROOT,"BCR 13/year 2010/simulation 1/AO-road-winter-on-2010.tif")) #temporary raster
origin(bcr13.ras)<-0
#cut out the bits in BCR 13 that are in "drawnresults",
#the reverse-clip or inverse mask is supposed to get rid of the parts of the 
#raster within the shapefile area
bcr13.ras.CL <- mask(bcr13.ras, WOTHxFMU.rp, inverse = TRUE)
plot(bcr13.ras.CL)
plot(bcr13.ras)
plot(bcr13.ras.CL)
#works!
#now attach to the rest of the FMUs
drawnresultsB<-mosaic(drawnresults, bcr13.ras.CL, fun=mean)
plot(drawnresultsB)
drawnresultsB[values(drawnresultsB)<0]<-0#get rid of negative values
drawnresultsC<-drawnresultsB/100#change units from percentage to proportion
plot(drawnresultsC)
writeRaster(drawnresultsC, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/RoadWinterWOTHxFMU.tif", overwrite=TRUE)


#Railways
#create empty list for storing rasters
rasterlist<-list()#empty list each time we draw a new number of samples

#read rasters for a specific predictor into list
for (j in FMUS){
  tempras<-raster(paste0(ROOT,j,"/year 2010/simulation 1/AO-railway-on-2010.tif")) #temporary raster
  #rasters must all have common origin for mosaic function to work
  origin(tempras)<-0
  rasterlist[[j]]<-tempras#B#append temporary raster at each loop iteration to the list
}

#combine those separate rasters into a single layer
drawnresults<-mosaic(rasterlist$`Abitibi Forest`,
                     rasterlist$`Algoma Forest`,
                     rasterlist$`Algonquin Forest`,
                     rasterlist$`Bancroft Minden Forest`,
                     rasterlist$`Black Spruce Forest`,
                     rasterlist$`Boundary Waters Forest`,
                     rasterlist$`French Severn Forest`,
                     rasterlist$`Gorden Cosens Forest`,
                     rasterlist$`Hearst Forest`,
                     rasterlist$`Kenora Forest`,
                     rasterlist$`Lakehead Forest`,
                     rasterlist$`Mazinaw Lanark Forest`,
                     rasterlist$`Missinaibi Forest`,
                     rasterlist$`Nagagami Forest`,
                     rasterlist$`Nipissing Forest`,
                     rasterlist$`Northshore Forest`,
                     rasterlist$`Ottawa Valley Forest`,
                     rasterlist$`Pic Forest`,
                     rasterlist$`Pineland Forest`,
                     rasterlist$`Romeo Malette Forest`,
                     rasterlist$`Spanish Forest`,
                     rasterlist$`Sudbury Forest`,
                     rasterlist$`Temagami Forest`,
                     rasterlist$`Timiskaming Forest`,
                     rasterlist$`White River Forest`,
                     fun=mean)
plot(drawnresults)

#now get same predictor for BCR 13, 
bcr13.ras<-raster(paste0(ROOT,"BCR 13/year 2010/simulation 1/AO-railway-on-2010.tif")) #temporary raster
origin(bcr13.ras)<-0
#cut out the bits in BCR 13 that are in "drawnresults",
#the reverse-clip or inverse mask is supposed to get rid of the parts of the 
#raster within the shapefile area
bcr13.ras.CL <- mask(bcr13.ras, WOTHxFMU.rp, inverse = TRUE)
plot(bcr13.ras.CL)
plot(bcr13.ras)
plot(bcr13.ras.CL)
#works!
#now attach to the rest of the FMUs
drawnresultsB<-mosaic(drawnresults, bcr13.ras.CL, fun=mean)
plot(drawnresultsB)
drawnresultsB[values(drawnresultsB)<0]<-0#get rid of negative values
drawnresultsC<-drawnresultsB/100#change units from percentage to proportion
plot(drawnresultsC)
writeRaster(drawnresultsC, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/RailwayWOTHxFMU.tif", overwrite=TRUE)


#Any Road (incl. Railway)
O<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/RoadPrimaryWOTHxFMU.tif")
P<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/RoadSecondaryAllSeasonWOTHxFMU.tif")
Q<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/RoadTertiaryResourceWOTHxFMU.tif")
R<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/RoadWinterWOTHxFMU.tif")
S<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/RailwayWOTHxFMU.tif")
Anyroad<-O+P+Q+R+S
writeRaster(Anyroad, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/AnyroadWOTHxFMU.tif", overwrite=TRUE)


#########################################
#                                       #
#                                       #
#             STEP TWO                  #
#           FOREST AGE 200 m            #
#                                       #
#########################################

#Import the "Anywooded" raster: needed for resetting forest age to
#zero in any pixels lacking forest (e.g. cropland, urban, open water)
Anywooded<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/AllWoodedAreasWOTHxFMU.tif")

#2010 (actually 2020) - Simulation Run 1
#Unlike the other years, I think the forest age raster
#doesn't change across simulations 1-5 because this is
#Year 0 of simulations in ALCES Online. So there is no 
#need to create separate predictor stacks for year 2010.

#create empty list for storing rasters
rasterlist<-list()#empty list each time we draw a new number of samples

#read rasters for a specific predictor into list
for (j in FMUS){
  tempras<-raster(paste0(ROOT,j,"/year 2010/simulation 1/AO-forest-age-2020-2010.tif")) #temporary raster
  #rasters must all have common origin for mosaic function to work
  origin(tempras)<-0
  rasterlist[[j]]<-tempras#B#append temporary raster at each loop iteration to the list
}

#combine those separate rasters into a single layer
drawnresults<-mosaic(rasterlist$`Abitibi Forest`,
                     rasterlist$`Algoma Forest`,
                     rasterlist$`Algonquin Forest`,
                     rasterlist$`Bancroft Minden Forest`,
                     rasterlist$`Black Spruce Forest`,
                     rasterlist$`Boundary Waters Forest`,
                     rasterlist$`French Severn Forest`,
                     rasterlist$`Gorden Cosens Forest`,
                     rasterlist$`Hearst Forest`,
                     rasterlist$`Kenora Forest`,
                     rasterlist$`Lakehead Forest`,
                     rasterlist$`Mazinaw Lanark Forest`,
                     rasterlist$`Missinaibi Forest`,
                     rasterlist$`Nagagami Forest`,
                     rasterlist$`Nipissing Forest`,
                     rasterlist$`Northshore Forest`,
                     rasterlist$`Ottawa Valley Forest`,
                     rasterlist$`Pic Forest`,
                     rasterlist$`Pineland Forest`,
                     rasterlist$`Romeo Malette Forest`,
                     rasterlist$`Spanish Forest`,
                     rasterlist$`Sudbury Forest`,
                     rasterlist$`Temagami Forest`,
                     rasterlist$`Timiskaming Forest`,
                     rasterlist$`White River Forest`,
                     fun=mean)
plot(drawnresults)

#now get same predictor for BCR 13, 
bcr13.ras<-raster(paste0(ROOT,"BCR 13/year 2010/simulation 1/AO-forest-age-2020-2010.tif")) #temporary raster
origin(bcr13.ras)<-0
#cut out the bits in BCR 13 that are in "drawnresults",
#the reverse-clip or inverse mask is supposed to get rid of the parts of the 
#raster within the shapefile area
bcr13.ras.CL <- mask(bcr13.ras, WOTHxFMU.rp, inverse = TRUE)
plot(bcr13.ras.CL)
plot(bcr13.ras)
plot(bcr13.ras.CL)
#works!
#now attach to the rest of the FMUs
drawnresultsB<-mosaic(drawnresults, bcr13.ras.CL, fun=mean)
plot(drawnresultsB)
drawnresultsB[values(drawnresultsB)<0]<-0#get rid of negative values
drawnresultsB[values(Anywooded)==0]<-0#resets forest age to 0 anywhere there is no forest to age
plot(drawnresultsB)
writeRaster(drawnresultsB, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/ForestAge2010WOTHxFMU.tif", overwrite=TRUE)

#2020 (actually 2030) - Simulation Run 1-5
for (i in 1:5){
  #create empty list for storing rasters
  rasterlist<-list()#empty list each time we draw a new number of samples
  
  #read rasters for a specific predictor into list
  for (j in FMUS){
    tempras<-raster(paste0(ROOT,j,"/year 2020/simulation ",i,"/AO-forest-age-2020-2020.tif")) #temporary raster
    #rasters must all have common origin for mosaic function to work
    origin(tempras)<-0
    rasterlist[[j]]<-tempras#B#append temporary raster at each loop iteration to the list
  }
  
  #combine those separate rasters into a single layer
  drawnresults<-mosaic(rasterlist$`Abitibi Forest`,
                       rasterlist$`Algoma Forest`,
                       rasterlist$`Algonquin Forest`,
                       rasterlist$`Bancroft Minden Forest`,
                       rasterlist$`Black Spruce Forest`,
                       rasterlist$`Boundary Waters Forest`,
                       rasterlist$`French Severn Forest`,
                       rasterlist$`Gorden Cosens Forest`,
                       rasterlist$`Hearst Forest`,
                       rasterlist$`Kenora Forest`,
                       rasterlist$`Lakehead Forest`,
                       rasterlist$`Mazinaw Lanark Forest`,
                       rasterlist$`Missinaibi Forest`,
                       rasterlist$`Nagagami Forest`,
                       rasterlist$`Nipissing Forest`,
                       rasterlist$`Northshore Forest`,
                       rasterlist$`Ottawa Valley Forest`,
                       rasterlist$`Pic Forest`,
                       rasterlist$`Pineland Forest`,
                       rasterlist$`Romeo Malette Forest`,
                       rasterlist$`Spanish Forest`,
                       rasterlist$`Sudbury Forest`,
                       rasterlist$`Temagami Forest`,
                       rasterlist$`Timiskaming Forest`,
                       rasterlist$`White River Forest`,
                       fun=mean)
  plot(drawnresults)
  
  #now get same predictor for BCR 13, 
  bcr13.ras<-raster(paste0(ROOT,"BCR 13/year 2020/simulation ",i,"/AO-forest-age-2020-2020.tif")) #temporary raster
  origin(bcr13.ras)<-0
  #cut out the bits in BCR 13 that are in "drawnresults",
  #the reverse-clip or inverse mask is supposed to get rid of the parts of the 
  #raster within the shapefile area
  bcr13.ras.CL <- mask(bcr13.ras, WOTHxFMU.rp, inverse = TRUE)
  plot(bcr13.ras.CL)
  plot(bcr13.ras)
  plot(bcr13.ras.CL)
  #works!
  #now attach to the rest of the FMUs
  drawnresultsB<-mosaic(drawnresults, bcr13.ras.CL, fun=mean)
  plot(drawnresultsB)
  drawnresultsB[values(drawnresultsB)<0]<-0#get rid of negative values
  drawnresultsB[values(Anywooded)==0]<-0#resets forest age to 0 anywhere there is no forest to age
  plot(drawnresultsB)
  writeRaster(drawnresultsB, filename=paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2020 Simulation ",i,"/ForestAge2020WOTHxFMU.tif"), overwrite=TRUE)
}


#2030 (actually 2040) - Simulation Run 1-5
for (i in 1:5){
  #create empty list for storing rasters
  rasterlist<-list()#empty list each time we draw a new number of samples
  
  #read rasters for a specific predictor into list
  for (j in FMUS){
    tempras<-raster(paste0(ROOT,j,"/year 2030/simulation ",i,"/AO-forest-age-2020-2030.tif")) #temporary raster
    #rasters must all have common origin for mosaic function to work
    origin(tempras)<-0
    rasterlist[[j]]<-tempras#B#append temporary raster at each loop iteration to the list
  }
  
  #combine those separate rasters into a single layer
  drawnresults<-mosaic(rasterlist$`Abitibi Forest`,
                       rasterlist$`Algoma Forest`,
                       rasterlist$`Algonquin Forest`,
                       rasterlist$`Bancroft Minden Forest`,
                       rasterlist$`Black Spruce Forest`,
                       rasterlist$`Boundary Waters Forest`,
                       rasterlist$`French Severn Forest`,
                       rasterlist$`Gorden Cosens Forest`,
                       rasterlist$`Hearst Forest`,
                       rasterlist$`Kenora Forest`,
                       rasterlist$`Lakehead Forest`,
                       rasterlist$`Mazinaw Lanark Forest`,
                       rasterlist$`Missinaibi Forest`,
                       rasterlist$`Nagagami Forest`,
                       rasterlist$`Nipissing Forest`,
                       rasterlist$`Northshore Forest`,
                       rasterlist$`Ottawa Valley Forest`,
                       rasterlist$`Pic Forest`,
                       rasterlist$`Pineland Forest`,
                       rasterlist$`Romeo Malette Forest`,
                       rasterlist$`Spanish Forest`,
                       rasterlist$`Sudbury Forest`,
                       rasterlist$`Temagami Forest`,
                       rasterlist$`Timiskaming Forest`,
                       rasterlist$`White River Forest`,
                       fun=mean)
  plot(drawnresults)
  
  #now get same predictor for BCR 13, 
  bcr13.ras<-raster(paste0(ROOT,"BCR 13/year 2030/simulation ",i,"/AO-forest-age-2020-2030.tif")) #temporary raster
  origin(bcr13.ras)<-0
  #cut out the bits in BCR 13 that are in "drawnresults",
  #the reverse-clip or inverse mask is supposed to get rid of the parts of the 
  #raster within the shapefile area
  bcr13.ras.CL <- mask(bcr13.ras, WOTHxFMU.rp, inverse = TRUE)
  plot(bcr13.ras.CL)
  plot(bcr13.ras)
  plot(bcr13.ras.CL)
  #works!
  #now attach to the rest of the FMUs
  drawnresultsB<-mosaic(drawnresults, bcr13.ras.CL, fun=mean)
  plot(drawnresultsB)
  drawnresultsB[values(drawnresultsB)<0]<-0#get rid of negative values
  drawnresultsB[values(Anywooded)==0]<-0#resets forest age to 0 anywhere there is no forest to age
  plot(drawnresultsB)
  writeRaster(drawnresultsB, filename=paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2030 Simulation ",i,"/ForestAge2030WOTHxFMU.tif"), overwrite=TRUE)
}


#2040 (actually 2050) - Simulation Run 1-5
for (i in 1:5){
  #create empty list for storing rasters
  rasterlist<-list()#empty list each time we draw a new number of samples
  
  #read rasters for a specific predictor into list
  for (j in FMUS){
    tempras<-raster(paste0(ROOT,j,"/year 2040/simulation ",i,"/AO-forest-age-2020-2040.tif")) #temporary raster
    #rasters must all have common origin for mosaic function to work
    origin(tempras)<-0
    rasterlist[[j]]<-tempras#B#append temporary raster at each loop iteration to the list
  }
  
  #combine those separate rasters into a single layer
  drawnresults<-mosaic(rasterlist$`Abitibi Forest`,
                       rasterlist$`Algoma Forest`,
                       rasterlist$`Algonquin Forest`,
                       rasterlist$`Bancroft Minden Forest`,
                       rasterlist$`Black Spruce Forest`,
                       rasterlist$`Boundary Waters Forest`,
                       rasterlist$`French Severn Forest`,
                       rasterlist$`Gorden Cosens Forest`,
                       rasterlist$`Hearst Forest`,
                       rasterlist$`Kenora Forest`,
                       rasterlist$`Lakehead Forest`,
                       rasterlist$`Mazinaw Lanark Forest`,
                       rasterlist$`Missinaibi Forest`,
                       rasterlist$`Nagagami Forest`,
                       rasterlist$`Nipissing Forest`,
                       rasterlist$`Northshore Forest`,
                       rasterlist$`Ottawa Valley Forest`,
                       rasterlist$`Pic Forest`,
                       rasterlist$`Pineland Forest`,
                       rasterlist$`Romeo Malette Forest`,
                       rasterlist$`Spanish Forest`,
                       rasterlist$`Sudbury Forest`,
                       rasterlist$`Temagami Forest`,
                       rasterlist$`Timiskaming Forest`,
                       rasterlist$`White River Forest`,
                       fun=mean)
  plot(drawnresults)
  
  #now get same predictor for BCR 13, 
  bcr13.ras<-raster(paste0(ROOT,"BCR 13/year 2040/simulation ",i,"/AO-forest-age-2020-2040.tif")) #temporary raster
  origin(bcr13.ras)<-0
  #cut out the bits in BCR 13 that are in "drawnresults",
  #the reverse-clip or inverse mask is supposed to get rid of the parts of the 
  #raster within the shapefile area
  bcr13.ras.CL <- mask(bcr13.ras, WOTHxFMU.rp, inverse = TRUE)
  plot(bcr13.ras.CL)
  plot(bcr13.ras)
  plot(bcr13.ras.CL)
  #works!
  #now attach to the rest of the FMUs
  drawnresultsB<-mosaic(drawnresults, bcr13.ras.CL, fun=mean)
  plot(drawnresultsB)
  drawnresultsB[values(drawnresultsB)<0]<-0#get rid of negative values
  drawnresultsB[values(Anywooded)==0]<-0#resets forest age to 0 anywhere there is no forest to age
  plot(drawnresultsB)
  writeRaster(drawnresultsB, filename=paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2040 Simulation ",i,"/ForestAge2040WOTHxFMU.tif"), overwrite=TRUE)
}


#2050 (actually 2060) - Simulation Run 1-5
for (i in 1:5){
  #create empty list for storing rasters
  rasterlist<-list()#empty list each time we draw a new number of samples
  
  #read rasters for a specific predictor into list
  for (j in FMUS){
    tempras<-raster(paste0(ROOT,j,"/year 2050/simulation ",i,"/AO-forest-age-2020-2050.tif")) #temporary raster
    #rasters must all have common origin for mosaic function to work
    origin(tempras)<-0
    rasterlist[[j]]<-tempras#B#append temporary raster at each loop iteration to the list
  }
  
  #combine those separate rasters into a single layer
  drawnresults<-mosaic(rasterlist$`Abitibi Forest`,
                       rasterlist$`Algoma Forest`,
                       rasterlist$`Algonquin Forest`,
                       rasterlist$`Bancroft Minden Forest`,
                       rasterlist$`Black Spruce Forest`,
                       rasterlist$`Boundary Waters Forest`,
                       rasterlist$`French Severn Forest`,
                       rasterlist$`Gorden Cosens Forest`,
                       rasterlist$`Hearst Forest`,
                       rasterlist$`Kenora Forest`,
                       rasterlist$`Lakehead Forest`,
                       rasterlist$`Mazinaw Lanark Forest`,
                       rasterlist$`Missinaibi Forest`,
                       rasterlist$`Nagagami Forest`,
                       rasterlist$`Nipissing Forest`,
                       rasterlist$`Northshore Forest`,
                       rasterlist$`Ottawa Valley Forest`,
                       rasterlist$`Pic Forest`,
                       rasterlist$`Pineland Forest`,
                       rasterlist$`Romeo Malette Forest`,
                       rasterlist$`Spanish Forest`,
                       rasterlist$`Sudbury Forest`,
                       rasterlist$`Temagami Forest`,
                       rasterlist$`Timiskaming Forest`,
                       rasterlist$`White River Forest`,
                       fun=mean)
  plot(drawnresults)
  
  #now get same predictor for BCR 13, 
  bcr13.ras<-raster(paste0(ROOT,"BCR 13/year 2050/simulation ",i,"/AO-forest-age-2020-2050.tif")) #temporary raster
  origin(bcr13.ras)<-0
  #cut out the bits in BCR 13 that are in "drawnresults",
  #the reverse-clip or inverse mask is supposed to get rid of the parts of the 
  #raster within the shapefile area
  bcr13.ras.CL <- mask(bcr13.ras, WOTHxFMU.rp, inverse = TRUE)
  plot(bcr13.ras.CL)
  plot(bcr13.ras)
  plot(bcr13.ras.CL)
  #works!
  #now attach to the rest of the FMUs
  drawnresultsB<-mosaic(drawnresults, bcr13.ras.CL, fun=mean)
  plot(drawnresultsB)
  drawnresultsB[values(drawnresultsB)<0]<-0#get rid of negative values
  drawnresultsB[values(Anywooded)==0]<-0#resets forest age to 0 anywhere there is no forest to age
  plot(drawnresultsB)
  writeRaster(drawnresultsB, filename=paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2050 Simulation ",i,"/ForestAge2050WOTHxFMU.tif"), overwrite=TRUE)
}


#2060 (actually 2070) - Simulation Run 1-5
for (i in 1:5){
  #create empty list for storing rasters
  rasterlist<-list()#empty list each time we draw a new number of samples
  
  #read rasters for a specific predictor into list
  for (j in FMUS){
    tempras<-raster(paste0(ROOT,j,"/year 2060/simulation ",i,"/AO-forest-age-2020-2060.tif")) #temporary raster
    #rasters must all have common origin for mosaic function to work
    origin(tempras)<-0
    rasterlist[[j]]<-tempras#B#append temporary raster at each loop iteration to the list
  }
  
  #combine those separate rasters into a single layer
  drawnresults<-mosaic(rasterlist$`Abitibi Forest`,
                       rasterlist$`Algoma Forest`,
                       rasterlist$`Algonquin Forest`,
                       rasterlist$`Bancroft Minden Forest`,
                       rasterlist$`Black Spruce Forest`,
                       rasterlist$`Boundary Waters Forest`,
                       rasterlist$`French Severn Forest`,
                       rasterlist$`Gorden Cosens Forest`,
                       rasterlist$`Hearst Forest`,
                       rasterlist$`Kenora Forest`,
                       rasterlist$`Lakehead Forest`,
                       rasterlist$`Mazinaw Lanark Forest`,
                       rasterlist$`Missinaibi Forest`,
                       rasterlist$`Nagagami Forest`,
                       rasterlist$`Nipissing Forest`,
                       rasterlist$`Northshore Forest`,
                       rasterlist$`Ottawa Valley Forest`,
                       rasterlist$`Pic Forest`,
                       rasterlist$`Pineland Forest`,
                       rasterlist$`Romeo Malette Forest`,
                       rasterlist$`Spanish Forest`,
                       rasterlist$`Sudbury Forest`,
                       rasterlist$`Temagami Forest`,
                       rasterlist$`Timiskaming Forest`,
                       rasterlist$`White River Forest`,
                       fun=mean)
  plot(drawnresults)
  
  #now get same predictor for BCR 13, 
  bcr13.ras<-raster(paste0(ROOT,"BCR 13/year 2060/simulation ",i,"/AO-forest-age-2020-2060.tif")) #temporary raster
  origin(bcr13.ras)<-0
  #cut out the bits in BCR 13 that are in "drawnresults",
  #the reverse-clip or inverse mask is supposed to get rid of the parts of the 
  #raster within the shapefile area
  bcr13.ras.CL <- mask(bcr13.ras, WOTHxFMU.rp, inverse = TRUE)
  plot(bcr13.ras.CL)
  plot(bcr13.ras)
  plot(bcr13.ras.CL)
  #works!
  #now attach to the rest of the FMUs
  drawnresultsB<-mosaic(drawnresults, bcr13.ras.CL, fun=mean)
  plot(drawnresultsB)
  drawnresultsB[values(drawnresultsB)<0]<-0#get rid of negative values
  drawnresultsB[values(Anywooded)==0]<-0#resets forest age to 0 anywhere there is no forest to age
  plot(drawnresultsB)
  writeRaster(drawnresultsB, filename=paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2060 Simulation ",i,"/ForestAge2060WOTHxFMU.tif"), overwrite=TRUE)
}


###############################################
#                                             #
#                                             #
#             STEP THREE                      #
#         CREATE THE NONWOODY PREDICTORS      #
#                                             #
###############################################

#Get moving window analyses: these layers correspond to actual BRT 
#model predictors at the appopriate spatial scale
ras<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/BarrenWOTHxFMU.tif")
## sigma = 2000m
fw2000<-focalWeight(x=ras,d=2000,type="Gauss")
barren.2000m<-focal(ras,w=fw2000,na.rm=TRUE)
plot(barren.2000m)
writeRaster(barren.2000m, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/barren.2000m.tif",overwrite=TRUE)

ras<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/UrbanWOTHxFMU.tif")
## sigma = 2000m
fw2000<-focalWeight(x=ras,d=2000,type="Gauss")
urban.2000m<-focal(ras,w=fw2000,na.rm=TRUE)
plot(urban.2000m)
writeRaster(urban.2000m, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/urban.2000m.tif",overwrite=TRUE)

ras<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/AllWetlandWOTHxFMU.tif")
## sigma = 2000m
fw2000<-focalWeight(x=ras,d=2000,type="Gauss")
wetland.2000m<-focal(ras,w=fw2000,na.rm=TRUE)
plot(wetland.2000m)
writeRaster(wetland.2000m, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/wetland.2000m.tif",overwrite=TRUE)

ras<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/OpenWaterWOTHxFMU.tif")
## sigma = 2000m
fw2000<-focalWeight(x=ras,d=2000,type="Gauss")
water.2000m<-focal(ras,w=fw2000,na.rm=TRUE)
plot(water.2000m)
writeRaster(water.2000m, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/water.2000m.tif",overwrite=TRUE)

#orchard 2000 m (Orchards are not in the ALCES Online 
#unity data set. But this variable had 0% relative influence
#on BRT output. Since the layer still needs to be included
#for making predictions, I've created a blank layer for 
#orchard.2000m)

orchard.2000m<-water.2000m
values(orchard.2000m)<-0
writeRaster(orchard.2000m, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/orchard.2000m.tif",overwrite=TRUE)


ras<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/AgricultureWOTHxFMU.tif")
## sigma = 1000m
fw1000<-focalWeight(x=ras,d=1000,type="Gauss")
cult.1000m<-focal(ras,w=fw1000,na.rm=TRUE)
plot(cult.1000m)
writeRaster(cult.1000m, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/cult.1000m.tif",overwrite=TRUE)

ras<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/GrasslandWOTHxFMU.tif")
## sigma = 1000m
fw1000<-focalWeight(x=ras,d=1000,type="Gauss")
grassland.1000m<-focal(ras,w=fw1000,na.rm=TRUE)
plot(grassland.1000m)
writeRaster(grassland.1000m, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/grassland.1000m.tif",overwrite=TRUE)

#MajorRoad150 (actually a binary variable)
ras<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/RoadPrimaryWOTHxFMU.tif")
plot(ras)
ras[values(ras)>0]<-1
plot(ras)
## sigma = 150m
fw150<-focalWeight(x=ras,d=150,type="Gauss")
MajorRoad150<-focal(ras,w=fw150,na.rm=TRUE)
plot(MajorRoad150)
MajorRoad150[values(MajorRoad150)>0]<-1
plot(MajorRoad150)
writeRaster(MajorRoad150, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/MajorRoad150.tif",overwrite=TRUE)

#Roadside150 (a binary variable)
ras<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/AnyRoadWOTHxFMU.tif")
plot(ras)
ras[values(ras)>0]<-1
plot(ras)
## sigma = 150m
fw150<-focalWeight(x=ras,d=150,type="Gauss")
Roadside150<-focal(ras,w=fw150,na.rm=TRUE)
plot(Roadside150)
Roadside150[values(Roadside150)>0]<-1
plot(Roadside150)
writeRaster(Roadside150, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/Roadside150.tif",overwrite=TRUE)

#Topography variables (already resampled to 200 m for BRTs)

elev<-raster("0_data/processed/prediction rasters/Ontario/on.elev.grd")
TPI<-raster("0_data/processed/prediction rasters/Ontario/on.TPI.grd")
TRI<-raster("0_data/processed/prediction rasters/Ontario/on.TRI.grd")
slope<-raster("0_data/processed/prediction rasters/Ontario/on.slope.grd")
plot(elev)
plot(TPI)
plot(TRI)
plot(slope)
#These layers will need to be reprojected and masked to other layers
#before stacking

elev.rp<-projectRaster(elev, cult.1000m)
elev.cr <- crop(elev.rp,cult.1000m)
elev.m <- mask(elev.cr,cult.1000m)
elev<-elev.m
plot(elev)
writeRaster(elev, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/elev.tif",overwrite=TRUE)


TPI.rp<-projectRaster(TPI, cult.1000m)
TPI.cr <- crop(TPI.rp,cult.1000m)
TPI.m <- mask(TPI.cr,cult.1000m)
TPI<-TPI.m
plot(TPI)
writeRaster(TPI, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/TPI.tif",overwrite=TRUE)

TRI.rp<-projectRaster(TRI, cult.1000m)
TRI.cr <- crop(TRI.rp,cult.1000m)
TRI.m <- mask(TRI.cr,cult.1000m)
TRI<-TRI.m
plot(TRI)
writeRaster(TRI, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/TRI.tif",overwrite=TRUE)

slope.rp<-projectRaster(slope, cult.1000m)
slope.cr <- crop(slope.rp,cult.1000m)
slope.m <- mask(slope.cr,cult.1000m)
slope<-slope.m
plot(slope)
writeRaster(slope, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/slope.tif",overwrite=TRUE)

####################################################
#                                                  #
#                                                  #
#             STEP FOUR                            #
# CREATE SHRUB, FOREST, SWAMP, AGE PREDICTORS      #
#                                                  #
####################################################

#2010 - since this is Year 0 there is no need to
#create separate woody predictors for simulation runs 2-5

Structure_Stand_Age<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/ForestAge2010WOTHxFMU.tif")
## sigma = 2000m
fw2000<-focalWeight(x=Structure_Stand_Age,d=2000,type="Gauss")
Structure_Stand_Age.2000m<-focal(Structure_Stand_Age,w=fw2000,na.rm=TRUE)
plot(Structure_Stand_Age.2000m)
writeRaster(Structure_Stand_Age.2000m, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/Structure_Stand_Age.2000m.tif",overwrite=TRUE)

ras<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/DenseConifWOTHxFMU.tif")
plot(ras)
ras[values(Structure_Stand_Age)<20]<-0
#resets coniferous forest amount to zero for areas <20 years old
#because these areas will be reclassified as shrubland
plot(ras)
## sigma = 2000m
fw2000<-focalWeight(x=ras,d=2000,type="Gauss")
conif.2000m<-focal(ras,w=fw2000,na.rm=TRUE)
plot(conif.2000m)
writeRaster(conif.2000m, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/conif.2000m.tif",overwrite=TRUE)

ras<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/DenseMixedWOTHxFMU.tif")
plot(ras)
ras[values(Structure_Stand_Age)<20]<-0
#resets mixed forest amount to zero for areas <20 years old
#because these areas will be reclassified as shrubland
plot(ras)
## sigma = 2000m
fw2000<-focalWeight(x=ras,d=2000,type="Gauss")
mixed.2000m<-focal(ras,w=fw2000,na.rm=TRUE)
plot(mixed.2000m)
writeRaster(mixed.2000m, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/mixed.2000m.tif",overwrite=TRUE)

ras<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/TreedWetlandWOTHxFMU.tif")
plot(ras)
ras[values(Structure_Stand_Age)<20]<-0
#resets swamp amount to zero for areas <20 years old
#because these areas will be reclassified as shrubland
plot(ras)
## sigma = 150m
fw150<-focalWeight(x=ras,d=150,type="Gauss")
swamp.150m<-focal(ras,w=fw150,na.rm=TRUE)
plot(swamp.150m)
writeRaster(swamp.150m, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/swamp.150m.tif",overwrite=TRUE)


ras<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/DenseDecidWOTHxFMU.tif")
plot(ras)
ras[values(Structure_Stand_Age)<20]<-0
#resets deciduous forest amount to zero for areas <20 years old
#because these areas will be reclassified as shrubland
plot(ras)
## sigma = 150m
fw150<-focalWeight(x=ras,d=150,type="Gauss")
decid.150m<-focal(ras,w=fw150,na.rm=TRUE)
plot(decid.150m)
writeRaster(decid.150m, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/decid.150m.tif",overwrite=TRUE)


ras<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/AllWoodedAreasWOTHxFMU.tif")
plot(ras)
ras[values(Structure_Stand_Age)>20]<-0
#resets shrubland amount to zero for areas >20 years old
#because these areas will be treated as different forest types
plot(ras)
## sigma = 2000m
fw2000<-focalWeight(x=ras,d=2000,type="Gauss")
shrub.2000m<-focal(ras,w=fw2000,na.rm=TRUE)
plot(shrub.2000m)
writeRaster(shrub.2000m, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/shrub.2000m.tif",overwrite=TRUE)

#2020
for (i in 1:5){
  Structure_Stand_Age<-raster(paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2020 Simulation ",i,"/ForestAge2020WOTHxFMU.tif"))
  ## sigma = 2000m
  fw2000<-focalWeight(x=Structure_Stand_Age,d=2000,type="Gauss")
  Structure_Stand_Age.2000m<-focal(Structure_Stand_Age,w=fw2000,na.rm=TRUE)
  plot(Structure_Stand_Age.2000m)
  writeRaster(Structure_Stand_Age.2000m, filename=paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2020 Simulation ",i,"/Structure_Stand_Age.2000m.tif"),overwrite=TRUE)
  
  Structure_Stand_Age<-raster(paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2020 Simulation ",i,"/ForestAge2020WOTHxFMU.tif"))
  
  ras<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/DenseConifWOTHxFMU.tif")
  plot(ras)
  ras[values(Structure_Stand_Age)<20]<-0
  #resets coniferous forest amount to zero for areas <20 years old
  #because these areas will be reclassified as shrubland
  plot(ras)
  ## sigma = 2000m
  fw2000<-focalWeight(x=ras,d=2000,type="Gauss")
  conif.2000m<-focal(ras,w=fw2000,na.rm=TRUE)
  plot(conif.2000m)
  writeRaster(conif.2000m, filename=paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2020 Simulation ",i,"/conif.2000m.tif"),overwrite=TRUE)
  
  ras<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/DenseMixedWOTHxFMU.tif")
  plot(ras)
  ras[values(Structure_Stand_Age)<20]<-0
  #resets mixed forest amount to zero for areas <20 years old
  #because these areas will be reclassified as shrubland
  plot(ras)
  ## sigma = 2000m
  fw2000<-focalWeight(x=ras,d=2000,type="Gauss")
  mixed.2000m<-focal(ras,w=fw2000,na.rm=TRUE)
  plot(mixed.2000m)
  writeRaster(mixed.2000m, filename=paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2020 Simulation ",i,"/mixed.2000m.tif"),overwrite=TRUE)
  
  ras<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/TreedWetlandWOTHxFMU.tif")
  plot(ras)
  ras[values(Structure_Stand_Age)<20]<-0
  #resets swamp amount to zero for areas <20 years old
  #because these areas will be reclassified as shrubland
  plot(ras)
  ## sigma = 150m
  fw150<-focalWeight(x=ras,d=150,type="Gauss")
  swamp.150m<-focal(ras,w=fw150,na.rm=TRUE)
  plot(swamp.150m)
  writeRaster(swamp.150m, filename=paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2020 Simulation ",i,"/swamp.150m.tif"),overwrite=TRUE)
  
  
  ras<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/DenseDecidWOTHxFMU.tif")
  plot(ras)
  ras[values(Structure_Stand_Age)<20]<-0
  #resets deciduous forest amount to zero for areas <20 years old
  #because these areas will be reclassified as shrubland
  plot(ras)
  ## sigma = 150m
  fw150<-focalWeight(x=ras,d=150,type="Gauss")
  decid.150m<-focal(ras,w=fw150,na.rm=TRUE)
  plot(decid.150m) 
  writeRaster(decid.150m, filename=paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2020 Simulation ",i,"/decid.150m.tif"),overwrite=TRUE)
  
  
  ras<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/AllWoodedAreasWOTHxFMU.tif")
  plot(ras)
  ras[values(Structure_Stand_Age)>20]<-0
  #resets shrubland amount to zero for areas >20 years old
  #because these areas will be treated as different forest types
  plot(ras)
  ## sigma = 2000m
  fw2000<-focalWeight(x=ras,d=2000,type="Gauss")
  shrub.2000m<-focal(ras,w=fw2000,na.rm=TRUE)
  plot(shrub.2000m)
  writeRaster(shrub.2000m, filename=paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2020 Simulation ",i,"/shrub.2000m.tif"),overwrite=TRUE)
}



#2030
for (i in 1:5){
  Structure_Stand_Age<-raster(paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2030 Simulation ",i,"/ForestAge2030WOTHxFMU.tif"))
  ## sigma = 2000m
  fw2000<-focalWeight(x=Structure_Stand_Age,d=2000,type="Gauss")
  Structure_Stand_Age.2000m<-focal(Structure_Stand_Age,w=fw2000,na.rm=TRUE)
  plot(Structure_Stand_Age.2000m)
  writeRaster(Structure_Stand_Age.2000m, filename=paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2030 Simulation ",i,"/Structure_Stand_Age.2000m.tif"),overwrite=TRUE)
  
  Structure_Stand_Age<-raster(paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2030 Simulation ",i,"/ForestAge2030WOTHxFMU.tif"))
  
  ras<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/DenseConifWOTHxFMU.tif")
  plot(ras)
  ras[values(Structure_Stand_Age)<20]<-0
  #resets coniferous forest amount to zero for areas <20 years old
  #because these areas will be reclassified as shrubland
  plot(ras)
  ## sigma = 2000m
  fw2000<-focalWeight(x=ras,d=2000,type="Gauss")
  conif.2000m<-focal(ras,w=fw2000,na.rm=TRUE)
  plot(conif.2000m)
  writeRaster(conif.2000m, filename=paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2030 Simulation ",i,"/conif.2000m.tif"),overwrite=TRUE)
  
  ras<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/DenseMixedWOTHxFMU.tif")
  plot(ras)
  ras[values(Structure_Stand_Age)<20]<-0
  #resets mixed forest amount to zero for areas <20 years old
  #because these areas will be reclassified as shrubland
  plot(ras)
  ## sigma = 2000m
  fw2000<-focalWeight(x=ras,d=2000,type="Gauss")
  mixed.2000m<-focal(ras,w=fw2000,na.rm=TRUE)
  plot(mixed.2000m)
  writeRaster(mixed.2000m, filename=paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2030 Simulation ",i,"/mixed.2000m.tif"),overwrite=TRUE)
  
  ras<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/TreedWetlandWOTHxFMU.tif")
  plot(ras)
  ras[values(Structure_Stand_Age)<20]<-0
  #resets swamp amount to zero for areas <20 years old
  #because these areas will be reclassified as shrubland
  plot(ras)
  ## sigma = 150m
  fw150<-focalWeight(x=ras,d=150,type="Gauss")
  swamp.150m<-focal(ras,w=fw150,na.rm=TRUE)
  plot(swamp.150m)
  writeRaster(swamp.150m, filename=paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2030 Simulation ",i,"/swamp.150m.tif"),overwrite=TRUE)
  
  
  ras<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/DenseDecidWOTHxFMU.tif")
  plot(ras)
  ras[values(Structure_Stand_Age)<20]<-0
  #resets deciduous forest amount to zero for areas <20 years old
  #because these areas will be reclassified as shrubland
  plot(ras)
  ## sigma = 150m
  fw150<-focalWeight(x=ras,d=150,type="Gauss")
  decid.150m<-focal(ras,w=fw150,na.rm=TRUE)
  plot(decid.150m) 
  writeRaster(decid.150m, filename=paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2030 Simulation ",i,"/decid.150m.tif"),overwrite=TRUE)
  
  
  ras<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/AllWoodedAreasWOTHxFMU.tif")
  plot(ras)
  ras[values(Structure_Stand_Age)>20]<-0
  #resets shrubland amount to zero for areas >20 years old
  #because these areas will be treated as different forest types
  plot(ras)
  ## sigma = 2000m
  fw2000<-focalWeight(x=ras,d=2000,type="Gauss")
  shrub.2000m<-focal(ras,w=fw2000,na.rm=TRUE)
  plot(shrub.2000m)
  writeRaster(shrub.2000m, filename=paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2030 Simulation ",i,"/shrub.2000m.tif"),overwrite=TRUE)
}



#2040
for (i in 1:5){
  Structure_Stand_Age<-raster(paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2040 Simulation ",i,"/ForestAge2040WOTHxFMU.tif"))
  ## sigma = 2000m
  fw2000<-focalWeight(x=Structure_Stand_Age,d=2000,type="Gauss")
  Structure_Stand_Age.2000m<-focal(Structure_Stand_Age,w=fw2000,na.rm=TRUE)
  plot(Structure_Stand_Age.2000m)
  writeRaster(Structure_Stand_Age.2000m, filename=paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2040 Simulation ",i,"/Structure_Stand_Age.2000m.tif"),overwrite=TRUE)
  
  Structure_Stand_Age<-raster(paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2040 Simulation ",i,"/ForestAge2040WOTHxFMU.tif"))
  
  ras<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/DenseConifWOTHxFMU.tif")
  plot(ras)
  ras[values(Structure_Stand_Age)<20]<-0
  #resets coniferous forest amount to zero for areas <20 years old
  #because these areas will be reclassified as shrubland
  plot(ras)
  ## sigma = 2000m
  fw2000<-focalWeight(x=ras,d=2000,type="Gauss")
  conif.2000m<-focal(ras,w=fw2000,na.rm=TRUE)
  plot(conif.2000m)
  writeRaster(conif.2000m, filename=paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2040 Simulation ",i,"/conif.2000m.tif"),overwrite=TRUE)
  
  ras<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/DenseMixedWOTHxFMU.tif")
  plot(ras)
  ras[values(Structure_Stand_Age)<20]<-0
  #resets mixed forest amount to zero for areas <20 years old
  #because these areas will be reclassified as shrubland
  plot(ras)
  ## sigma = 2000m
  fw2000<-focalWeight(x=ras,d=2000,type="Gauss")
  mixed.2000m<-focal(ras,w=fw2000,na.rm=TRUE)
  plot(mixed.2000m)
  writeRaster(mixed.2000m, filename=paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2040 Simulation ",i,"/mixed.2000m.tif"),overwrite=TRUE)
  
  ras<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/TreedWetlandWOTHxFMU.tif")
  plot(ras)
  ras[values(Structure_Stand_Age)<20]<-0
  #resets swamp amount to zero for areas <20 years old
  #because these areas will be reclassified as shrubland
  plot(ras)
  ## sigma = 150m
  fw150<-focalWeight(x=ras,d=150,type="Gauss")
  swamp.150m<-focal(ras,w=fw150,na.rm=TRUE)
  plot(swamp.150m)
  writeRaster(swamp.150m, filename=paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2040 Simulation ",i,"/swamp.150m.tif"),overwrite=TRUE)
  
  
  ras<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/DenseDecidWOTHxFMU.tif")
  plot(ras)
  ras[values(Structure_Stand_Age)<20]<-0
  #resets deciduous forest amount to zero for areas <20 years old
  #because these areas will be reclassified as shrubland
  plot(ras)
  ## sigma = 150m
  fw150<-focalWeight(x=ras,d=150,type="Gauss")
  decid.150m<-focal(ras,w=fw150,na.rm=TRUE)
  plot(decid.150m) 
  writeRaster(decid.150m, filename=paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2040 Simulation ",i,"/decid.150m.tif"),overwrite=TRUE)
  
  
  ras<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/AllWoodedAreasWOTHxFMU.tif")
  plot(ras)
  ras[values(Structure_Stand_Age)>20]<-0
  #resets shrubland amount to zero for areas >20 years old
  #because these areas will be treated as different forest types
  plot(ras)
  ## sigma = 2000m
  fw2000<-focalWeight(x=ras,d=2000,type="Gauss")
  shrub.2000m<-focal(ras,w=fw2000,na.rm=TRUE)
  plot(shrub.2000m)
  writeRaster(shrub.2000m, filename=paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2040 Simulation ",i,"/shrub.2000m.tif"),overwrite=TRUE)
}


#2050
for (i in 1:5){
  Structure_Stand_Age<-raster(paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2050 Simulation ",i,"/ForestAge2050WOTHxFMU.tif"))
  ## sigma = 2000m
  fw2000<-focalWeight(x=Structure_Stand_Age,d=2000,type="Gauss")
  Structure_Stand_Age.2000m<-focal(Structure_Stand_Age,w=fw2000,na.rm=TRUE)
  plot(Structure_Stand_Age.2000m)
  writeRaster(Structure_Stand_Age.2000m, filename=paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2050 Simulation ",i,"/Structure_Stand_Age.2000m.tif"),overwrite=TRUE)
  
  Structure_Stand_Age<-raster(paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2050 Simulation ",i,"/ForestAge2050WOTHxFMU.tif"))
  
  ras<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/DenseConifWOTHxFMU.tif")
  plot(ras)
  ras[values(Structure_Stand_Age)<20]<-0
  #resets coniferous forest amount to zero for areas <20 years old
  #because these areas will be reclassified as shrubland
  plot(ras)
  ## sigma = 2000m
  fw2000<-focalWeight(x=ras,d=2000,type="Gauss")
  conif.2000m<-focal(ras,w=fw2000,na.rm=TRUE)
  plot(conif.2000m)
  writeRaster(conif.2000m, filename=paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2050 Simulation ",i,"/conif.2000m.tif"),overwrite=TRUE)
  
  ras<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/DenseMixedWOTHxFMU.tif")
  plot(ras)
  ras[values(Structure_Stand_Age)<20]<-0
  #resets mixed forest amount to zero for areas <20 years old
  #because these areas will be reclassified as shrubland
  plot(ras)
  ## sigma = 2000m
  fw2000<-focalWeight(x=ras,d=2000,type="Gauss")
  mixed.2000m<-focal(ras,w=fw2000,na.rm=TRUE)
  plot(mixed.2000m)
  writeRaster(mixed.2000m, filename=paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2050 Simulation ",i,"/mixed.2000m.tif"),overwrite=TRUE)
  
  ras<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/TreedWetlandWOTHxFMU.tif")
  plot(ras)
  ras[values(Structure_Stand_Age)<20]<-0
  #resets swamp amount to zero for areas <20 years old
  #because these areas will be reclassified as shrubland
  plot(ras)
  ## sigma = 150m
  fw150<-focalWeight(x=ras,d=150,type="Gauss")
  swamp.150m<-focal(ras,w=fw150,na.rm=TRUE)
  plot(swamp.150m)
  writeRaster(swamp.150m, filename=paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2050 Simulation ",i,"/swamp.150m.tif"),overwrite=TRUE)
  
  
  ras<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/DenseDecidWOTHxFMU.tif")
  plot(ras)
  ras[values(Structure_Stand_Age)<20]<-0
  #resets deciduous forest amount to zero for areas <20 years old
  #because these areas will be reclassified as shrubland
  plot(ras)
  ## sigma = 150m
  fw150<-focalWeight(x=ras,d=150,type="Gauss")
  decid.150m<-focal(ras,w=fw150,na.rm=TRUE)
  plot(decid.150m) 
  writeRaster(decid.150m, filename=paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2050 Simulation ",i,"/decid.150m.tif"),overwrite=TRUE)
  
  
  ras<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/AllWoodedAreasWOTHxFMU.tif")
  plot(ras)
  ras[values(Structure_Stand_Age)>20]<-0
  #resets shrubland amount to zero for areas >20 years old
  #because these areas will be treated as different forest types
  plot(ras)
  ## sigma = 2000m
  fw2000<-focalWeight(x=ras,d=2000,type="Gauss")
  shrub.2000m<-focal(ras,w=fw2000,na.rm=TRUE)
  plot(shrub.2000m)
  writeRaster(shrub.2000m, filename=paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2050 Simulation ",i,"/shrub.2000m.tif"),overwrite=TRUE)
}



#2060 - loop through simulations 1 to 5

for (i in 1:5){
  Structure_Stand_Age<-raster(paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2060 Simulation ",i,"/ForestAge2060WOTHxFMU.tif"))
  ## sigma = 2000m
  fw2000<-focalWeight(x=Structure_Stand_Age,d=2000,type="Gauss")
  Structure_Stand_Age.2000m<-focal(Structure_Stand_Age,w=fw2000,na.rm=TRUE)
  plot(Structure_Stand_Age.2000m)
  writeRaster(Structure_Stand_Age.2000m, filename=paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2060 Simulation ",i,"/Structure_Stand_Age.2000m.tif"),overwrite=TRUE)

  Structure_Stand_Age<-raster(paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2060 Simulation ",i,"/ForestAge2060WOTHxFMU.tif"))
  
  ras<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/DenseConifWOTHxFMU.tif")
  plot(ras)
  ras[values(Structure_Stand_Age)<20]<-0
  #resets coniferous forest amount to zero for areas <20 years old
  #because these areas will be reclassified as shrubland
  plot(ras)
  ## sigma = 2000m
  fw2000<-focalWeight(x=ras,d=2000,type="Gauss")
  conif.2000m<-focal(ras,w=fw2000,na.rm=TRUE)
  plot(conif.2000m)
  writeRaster(conif.2000m, filename=paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2060 Simulation ",i,"/conif.2000m.tif"),overwrite=TRUE)
   
  ras<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/DenseMixedWOTHxFMU.tif")
  plot(ras)
  ras[values(Structure_Stand_Age)<20]<-0
  #resets mixed forest amount to zero for areas <20 years old
  #because these areas will be reclassified as shrubland
  plot(ras)
  ## sigma = 2000m
  fw2000<-focalWeight(x=ras,d=2000,type="Gauss")
  mixed.2000m<-focal(ras,w=fw2000,na.rm=TRUE)
  plot(mixed.2000m)
  writeRaster(mixed.2000m, filename=paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2060 Simulation ",i,"/mixed.2000m.tif"),overwrite=TRUE)
  
  ras<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/TreedWetlandWOTHxFMU.tif")
  plot(ras)
  ras[values(Structure_Stand_Age)<20]<-0
  #resets swamp amount to zero for areas <20 years old
  #because these areas will be reclassified as shrubland
  plot(ras)
  ## sigma = 150m
  fw150<-focalWeight(x=ras,d=150,type="Gauss")
  swamp.150m<-focal(ras,w=fw150,na.rm=TRUE)
  plot(swamp.150m)
  writeRaster(swamp.150m, filename=paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2060 Simulation ",i,"/swamp.150m.tif"),overwrite=TRUE)
  
   
  ras<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/DenseDecidWOTHxFMU.tif")
  plot(ras)
  ras[values(Structure_Stand_Age)<20]<-0
  #resets deciduous forest amount to zero for areas <20 years old
  #because these areas will be reclassified as shrubland
  plot(ras)
  ## sigma = 150m
  fw150<-focalWeight(x=ras,d=150,type="Gauss")
  decid.150m<-focal(ras,w=fw150,na.rm=TRUE)
  plot(decid.150m) 
  writeRaster(decid.150m, filename=paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2060 Simulation ",i,"/decid.150m.tif"),overwrite=TRUE)
  
  
  ras<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/AllWoodedAreasWOTHxFMU.tif")
  plot(ras)
  ras[values(Structure_Stand_Age)>20]<-0
  #resets shrubland amount to zero for areas >20 years old
  #because these areas will be treated as different forest types
  plot(ras)
  ## sigma = 2000m
  fw2000<-focalWeight(x=ras,d=2000,type="Gauss")
  shrub.2000m<-focal(ras,w=fw2000,na.rm=TRUE)
  plot(shrub.2000m)
  writeRaster(shrub.2000m, filename=paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2060 Simulation ",i,"/shrub.2000m.tif"),overwrite=TRUE)
}



#########################################
#                                       #
#                                       #
#             STEP FIVE                 #
#           CREATE THE RASTER STACKS    #
#                                       #
#########################################

#Baseline 2010 - Simulation Run 1
barren.2000m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/barren.2000m.tif")
conif.2000m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/conif.2000m.tif")
cult.1000m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/cult.1000m.tif")
decid.150m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/decid.150m.tif")
elev<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/elev.tif")
grassland.1000m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/grassland.1000m.tif")
MajorRoad150<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/MajorRoad150.tif")
mixed.2000m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/mixed.2000m.tif")
orchard.2000m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/orchard.2000m.tif")
Roadside150<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/Roadside150.tif")
shrub.2000m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/shrub.2000m.tif")
slope<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/slope.tif")
Structure_Stand_Age.2000m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/Structure_Stand_Age.2000m.tif")
swamp.150m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/swamp.150m.tif")
TPI<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/TPI.tif")
TRI<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/TRI.tif")
urban.2000m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/urban.2000m.tif")
water.2000m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/water.2000m.tif")
wetland.2000m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/wetland.2000m.tif")

stack2010.1<-stack(barren.2000m,
                   conif.2000m,
                   cult.1000m,
                   decid.150m,
                   elev,
                   grassland.1000m,
                   MajorRoad150,
                   mixed.2000m,
                   orchard.2000m,
                   Roadside150,
                   shrub.2000m,
                   slope,
                   Structure_Stand_Age.2000m,
                   swamp.150m,
                   TPI,
                   TRI,
                   urban.2000m,
                   water.2000m,
                   wetland.2000m,
                   quick=TRUE)
writeRaster(stack2010.1, filename="3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/pred_on_AO2010.1.grd", format="raster",overwrite=TRUE)

#Baseline 2020 - Simulation Run 1 - 5
for (k in 1:5){
  barren.2000m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/barren.2000m.tif")
  conif.2000m<-raster(paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2020 Simulation ",k,"/conif.2000m.tif"))
  cult.1000m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/cult.1000m.tif")
  decid.150m<-raster(paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2020 Simulation ",k,"/decid.150m.tif"))
  elev<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/elev.tif")
  grassland.1000m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/grassland.1000m.tif")
  MajorRoad150<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/MajorRoad150.tif")
  mixed.2000m<-raster(paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2020 Simulation ",k,"/mixed.2000m.tif"))
  orchard.2000m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/orchard.2000m.tif")
  Roadside150<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/Roadside150.tif")
  shrub.2000m<-raster(paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2020 Simulation ",k,"/shrub.2000m.tif"))
  slope<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/slope.tif")
  Structure_Stand_Age.2000m<-raster(paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2020 Simulation ",k,"/Structure_Stand_Age.2000m.tif"))
  swamp.150m<-raster(paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2020 Simulation ",k,"/swamp.150m.tif"))
  TPI<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/TPI.tif")
  TRI<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/TRI.tif")
  urban.2000m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/urban.2000m.tif")
  water.2000m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/water.2000m.tif")
  wetland.2000m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/wetland.2000m.tif")
  
  stack2020<-stack(barren.2000m,
                   conif.2000m,
                   cult.1000m,
                   decid.150m,
                   elev,
                   grassland.1000m,
                   MajorRoad150,
                   mixed.2000m,
                   orchard.2000m,
                   Roadside150,
                   shrub.2000m,
                   slope,
                   Structure_Stand_Age.2000m,
                   swamp.150m,
                   TPI,
                   TRI,
                   urban.2000m,
                   water.2000m,
                   wetland.2000m,
                   quick=TRUE)
  writeRaster(stack2020, filename=paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2020 Simulation ",k,"/pred_on_AO2020.",k,".grd"), format="raster",overwrite=TRUE)
}



#Baseline 2030 - Simulation Run 1 - 5
for (k in 1:5){
  barren.2000m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/barren.2000m.tif")
  conif.2000m<-raster(paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2030 Simulation ",k,"/conif.2000m.tif"))
  cult.1000m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/cult.1000m.tif")
  decid.150m<-raster(paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2030 Simulation ",k,"/decid.150m.tif"))
  elev<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/elev.tif")
  grassland.1000m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/grassland.1000m.tif")
  MajorRoad150<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/MajorRoad150.tif")
  mixed.2000m<-raster(paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2030 Simulation ",k,"/mixed.2000m.tif"))
  orchard.2000m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/orchard.2000m.tif")
  Roadside150<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/Roadside150.tif")
  shrub.2000m<-raster(paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2030 Simulation ",k,"/shrub.2000m.tif"))
  slope<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/slope.tif")
  Structure_Stand_Age.2000m<-raster(paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2030 Simulation ",k,"/Structure_Stand_Age.2000m.tif"))
  swamp.150m<-raster(paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2030 Simulation ",k,"/swamp.150m.tif"))
  TPI<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/TPI.tif")
  TRI<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/TRI.tif")
  urban.2000m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/urban.2000m.tif")
  water.2000m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/water.2000m.tif")
  wetland.2000m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/wetland.2000m.tif")
  
  stack2030<-stack(barren.2000m,
                   conif.2000m,
                   cult.1000m,
                   decid.150m,
                   elev,
                   grassland.1000m,
                   MajorRoad150,
                   mixed.2000m,
                   orchard.2000m,
                   Roadside150,
                   shrub.2000m,
                   slope,
                   Structure_Stand_Age.2000m,
                   swamp.150m,
                   TPI,
                   TRI,
                   urban.2000m,
                   water.2000m,
                   wetland.2000m,
                   quick=TRUE)
  writeRaster(stack2030, filename=paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2030 Simulation ",k,"/pred_on_AO2030.",k,".grd"), format="raster",overwrite=TRUE)
}


#Baseline 2040 - Simulation Run 1 - 5
for (k in 2:5){
  barren.2000m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/barren.2000m.tif")
  conif.2000m<-raster(paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2040 Simulation ",k,"/conif.2000m.tif"))
  cult.1000m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/cult.1000m.tif")
  decid.150m<-raster(paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2040 Simulation ",k,"/decid.150m.tif"))
  elev<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/elev.tif")
  grassland.1000m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/grassland.1000m.tif")
  MajorRoad150<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/MajorRoad150.tif")
  mixed.2000m<-raster(paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2040 Simulation ",k,"/mixed.2000m.tif"))
  orchard.2000m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/orchard.2000m.tif")
  Roadside150<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/Roadside150.tif")
  shrub.2000m<-raster(paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2040 Simulation ",k,"/shrub.2000m.tif"))
  slope<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/slope.tif")
  Structure_Stand_Age.2000m<-raster(paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2040 Simulation ",k,"/Structure_Stand_Age.2000m.tif"))
  swamp.150m<-raster(paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2040 Simulation ",k,"/swamp.150m.tif"))
  TPI<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/TPI.tif")
  TRI<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/TRI.tif")
  urban.2000m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/urban.2000m.tif")
  water.2000m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/water.2000m.tif")
  wetland.2000m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/wetland.2000m.tif")
  
  stack2040<-stack(barren.2000m,
                   conif.2000m,
                   cult.1000m,
                   decid.150m,
                   elev,
                   grassland.1000m,
                   MajorRoad150,
                   mixed.2000m,
                   orchard.2000m,
                   Roadside150,
                   shrub.2000m,
                   slope,
                   Structure_Stand_Age.2000m,
                   swamp.150m,
                   TPI,
                   TRI,
                   urban.2000m,
                   water.2000m,
                   wetland.2000m,
                   quick=TRUE)
  writeRaster(stack2040, filename=paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2040 Simulation ",k,"/pred_on_AO2040.",k,".grd"), format="raster",overwrite=TRUE)
}



#Baseline 2050 - Simulation Run 1-5
for (k in 1:5){
  barren.2000m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/barren.2000m.tif")
  conif.2000m<-raster(paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2050 Simulation ",k,"/conif.2000m.tif"))
  cult.1000m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/cult.1000m.tif")
  decid.150m<-raster(paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2050 Simulation ",k,"/decid.150m.tif"))
  elev<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/elev.tif")
  grassland.1000m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/grassland.1000m.tif")
  MajorRoad150<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/MajorRoad150.tif")
  mixed.2000m<-raster(paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2050 Simulation ",k,"/mixed.2000m.tif"))
  orchard.2000m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/orchard.2000m.tif")
  Roadside150<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/Roadside150.tif")
  shrub.2000m<-raster(paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2050 Simulation ",k,"/shrub.2000m.tif"))
  slope<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/slope.tif")
  Structure_Stand_Age.2000m<-raster(paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2050 Simulation ",k,"/Structure_Stand_Age.2000m.tif"))
  swamp.150m<-raster(paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2050 Simulation ",k,"/swamp.150m.tif"))
  TPI<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/TPI.tif")
  TRI<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/TRI.tif")
  urban.2000m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/urban.2000m.tif")
  water.2000m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/water.2000m.tif")
  wetland.2000m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/wetland.2000m.tif")
  
  stack2050<-stack(barren.2000m,
                   conif.2000m,
                   cult.1000m,
                   decid.150m,
                   elev,
                   grassland.1000m,
                   MajorRoad150,
                   mixed.2000m,
                   orchard.2000m,
                   Roadside150,
                   shrub.2000m,
                   slope,
                   Structure_Stand_Age.2000m,
                   swamp.150m,
                   TPI,
                   TRI,
                   urban.2000m,
                   water.2000m,
                   wetland.2000m,
                   quick=TRUE)
  writeRaster(stack2050, filename=paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2050 Simulation ",k,"/pred_on_AO2050.",k,".grd"), format="raster",overwrite=TRUE)
}

#Baseline 2060 - Simulation Run 1 through 5

for (k in 1:5){
  barren.2000m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/barren.2000m.tif")
  conif.2000m<-raster(paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2060 Simulation ",k,"/conif.2000m.tif"))
  cult.1000m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/cult.1000m.tif")
  decid.150m<-raster(paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2060 Simulation ",k,"/decid.150m.tif"))
  elev<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/elev.tif")
  grassland.1000m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/grassland.1000m.tif")
  MajorRoad150<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/MajorRoad150.tif")
  mixed.2000m<-raster(paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2060 Simulation ",k,"/mixed.2000m.tif"))
  orchard.2000m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/orchard.2000m.tif")
  Roadside150<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/Roadside150.tif")
  shrub.2000m<-raster(paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2060 Simulation ",k,"/shrub.2000m.tif"))
  slope<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/slope.tif")
  Structure_Stand_Age.2000m<-raster(paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2060 Simulation ",k,"/Structure_Stand_Age.2000m.tif"))
  swamp.150m<-raster(paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2060 Simulation ",k,"/swamp.150m.tif"))
  TPI<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/TPI.tif")
  TRI<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/TRI.tif")
  urban.2000m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/urban.2000m.tif")
  water.2000m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/water.2000m.tif")
  wetland.2000m<-raster("3_ALCES Online Outputs/Predictor Stacks/Year 2010 Simulation 1/wetland.2000m.tif")
  
  stack2060<-stack(barren.2000m,
                     conif.2000m,
                     cult.1000m,
                     decid.150m,
                     elev,
                     grassland.1000m,
                     MajorRoad150,
                     mixed.2000m,
                     orchard.2000m,
                     Roadside150,
                     shrub.2000m,
                     slope,
                     Structure_Stand_Age.2000m,
                     swamp.150m,
                     TPI,
                     TRI,
                     urban.2000m,
                     water.2000m,
                     wetland.2000m,
                     quick=TRUE)
  writeRaster(stack2060, filename=paste0("3_ALCES Online Outputs/Predictor Stacks/Year 2060 Simulation ",k,"/pred_on_AO2060.",k,".grd"), format="raster",overwrite=TRUE)
}

