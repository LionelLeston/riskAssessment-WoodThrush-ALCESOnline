#Note: This script is for estimating area and size class distributions
#of fire outbreak areas within Ontario Wood Thrush range. These layers aren't
#used as variables in the BRT or GLM models for ALCES Online scenarios
#but are necessary for modeling changes in forest age structure in the simulations.

#I am using GIS data updated as recently as 2020 by the Ontario Ministry of 
#Natural Resources' Forest Research Inventory. Fire outbreak polygons were intersected in
#ArcGIS with Bird Conservation Region and FMU polygons, so that I can get separate area and
#size class distributions by BCR or FMU and see where fire outbreaks are concentrated.

#I will start by importing a csv files containing the areas of individual outbreak polygons
#limited to those within the updated Wood Thrush range in Ontario.

library(raster)
library(dismo)
library(rpart)
library(maptools)
library(data.table)
library(rgdal)
library(dplyr)
library(ggplot2)
library(spatial)
library(rasterVis)
library(RColorBrewer)

OUTB<-read.csv("2_GIS outputs for ALCES Online/forest disturbance metrics/FireXYearXBCRXFMU.csv")

###############################################################################################
#                                                                                             #
#                                                                                             #
#                                FIRE                                                   #
#                                                                                             #
###############################################################################################
str(OUTB)
nrow(OUTB)#1437: far fewer fires than insect outbreaks within Wood Thrush Ontario study area

#So I'll generate summaries for each FMU. 
#I am only interested in the 10 most recent years (2010-2019) in the data
levels(as.factor(OUTB$FIRE_YEAR))
OUTB10<-OUTB[OUTB$FIRE_YEAR>2009,]
nrow(OUTB10)#90

OUTB10firesumm<-OUTB10 %>%
  group_by(FMU_NAME) %>%
  summarise(TotalArea=sum(Recalc_Ha), 
            MeanCutSize=mean(Recalc_Ha),
            MaxCutSize=max(Recalc_Ha))

#   FMU_NAME               TotalArea MeanCutSize MaxCutSize
# <chr>                      <dbl>       <dbl>      <dbl>
# 1 Abitibi River Forest       392.       131.        175. 
# 2 Algoma Forest             3259.      1086.       1888. 
# 3 Algonquin Park Forest       45.4       45.4        45.4
# 4 Boundary Waters Forest     453.         9.63       93.5
# 5 French-Severn Forest      6458.      3229.       6449. 
# 6 Missinaibi Forest         1724.       575.       1558. 
# 7 Nipissing Forest          2898.       966.       2476. 
# 8 Ottawa Valley Forest       973.       243.        694. 
# 9 Pic Forest                 271.       271.        271. 
# 10 Pineland Forest            193.       193.        193. 
# 11 Romeo Malette Forest     21804.      4361.      21332. 
# 12 Spanish Forest              50.1       50.1        50.1
# 13 Sudbury Forest            5217.      1739.       4604. 
# 14 Temagami Forest           7789.       865.       5624. 
# 15 Timiskaming Forest        1738.       869.       1606. 
# 16 White River Forest         118.        59.2        60.2

OUTB10firesumm.10.19<-data.frame(OUTB10firesumm)
write.csv(OUTB10firesumm.10.19, file="2_GIS outputs for ALCES Online/fire.10.19xFMU.csv")

#Note: for now, fire is only being simulated as a disturbance in 3 Forest Management Units
#lacking recent harvest or budworm GIS data for simulating those disturbances. Those
#FMUs are the Missinaibi, Pic, and Boundary Waters Forest Management Units. Fire is 
#not being modelled as a disturbance in other FMUs because it was not thought to be
#significant in those areas (based on a Wood Thrush team decision back in July 2021).

#No fire is being simulated as a disturbance in Bird Conservation Region 13 either.


