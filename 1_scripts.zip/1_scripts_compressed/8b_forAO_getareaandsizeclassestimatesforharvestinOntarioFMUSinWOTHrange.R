#Note: This script is for estimating area and size class distributions
#of clear-cut, shelterwood, and selectively logged areas within Ontario 
#Wood Thrush range. These layers aren't
#used as variables in the BRT or GLM models for ALCES Online scenarios
#but are necessary for modeling realistic harvest amounts in the simulations.

#I am using GIS data updated as recently as 2019 by the Ontario Ministry of 
#Natural Resources Forest Research Institute (Email: info.mnrfscience@ontario.ca).
#Clear-cut, shelterwood, and selectively-logged forest polygons were intersected in
#ArcGIS with Forest Management Unit polygons, so that I can get separate area and
#size class distributions by FMU and see where each type of harvest is concentrated.

#Note: one of the Ontario BCRs (Great Lakes/St. Lawrence Plain) occurs outside of the
#FMUs where there is GIS data from info.mnrfscience@ontario.ca, so harvest in that
#BCR (in private woodlots) is accounted for separately, from reports and published papers.

#I will start by importing three csv files containing the areas of individual harvest polygons
#limited to those within the updated Wood Thrush range in Ontario.

library(raster)
library(dismo)
library(rpart)
library(maptools)
library(data.table)
library(rgdal)
library(dplyr)
library(ggplot2)
library(spatial)
library(rasterVis)
library(RColorBrewer)

#changed nested folder from "forest disturbance metrics" to "Recent Harvest"
CC<-read.csv("2_GIS outputs for ALCES Online/Recent Harvest/Harvest X Year X BCR/ClearcutXYearXBCRXFMU.csv")
SH<-read.csv("2_GIS outputs for ALCES Online/Recent Harvest/Harvest X Year X BCR/ShelterwoodXYearXBCRXFMU.csv")
SEL<-read.csv("2_GIS outputs for ALCES Online/Recent Harvest/Harvest X Year X BCR/SelectiveXYearXBCRXFMU.csv")
FMUNAMES<-read.csv("2_GIS outputs for ALCES Online/Recent Harvest/Harvest X Year X BCR/FMUNAMES.csv")
FMUNAMES$MUNO<-FMUNAMES$Management.unit

###############################################################################################
#                                                                                             #
#                                                                                             #
#                                CLEAR-CUTS                                                   #
#                                                                                             #
###############################################################################################
str(CC)
nrow(CC)#77095
#So I'll generate summaries for each FMU. I am only interested in the 10 most recent years (2010-2019)
levels(as.factor(CC$AR_YEAR))
CC10<-CC[CC$AR_YEAR>2009,]
nrow(CC10)#35013

CC10summ<-CC10 %>%
  group_by(MUNO) %>%
  summarise(TotalArea=sum(RecalcHa), 
            MeanCutSize=mean(RecalcHa),
            MaxCutSize=max(RecalcHa))

CC10summ<-data.frame(CC10summ)

#    MUNO  TotalArea MeanCutSize MaxCutSize
# 1    35  2454.7026    6.762266  137.56941
# 2    60 18342.3369    5.583664  144.09057
# 3    67  2285.7668   10.296247  142.01505
# 4   110 33166.8289   11.682574  229.44393
# 5   140  1252.6147    1.930069   35.27762
# 6   210 15272.1310    8.021077  266.78120
# 7   220  6620.6930    8.327916  126.75313
# 8   280  5782.1669   10.807789  141.74656
# 9   360  1088.1059    9.629256   74.98355
# 10  390 19421.4825   10.759824  217.65195
# 11  405 21034.1734    6.020084  110.18807
# 12  421  9989.1147    5.157003  111.25910
# 13  438  9916.8203    6.769161  172.16004
# 14  451  1985.1754    3.781286   61.17318
# 15  509  2765.6494    7.682360  149.37298
# 16  565  2877.5955   15.554570  145.78422
# 17  601  5644.4374    2.374606   83.06038
# 18  615  5151.2929    6.612700  130.05994
# 19  644   166.8375    9.268748   50.73483
# 20  680 22775.9644    8.977518  233.10444
# 21  754 17929.7908   12.289096  182.76593
# 22  780  8950.2335    5.182532   78.58676
# 23  796  5006.9710    3.283260   82.48477
# 24  889 13257.2455   18.037069  482.19249
# 25  898  4466.2433   18.155460  407.28958
# 26  930 22294.2202    7.663878  187.06218
# 27  965  3615.1611    9.986633  136.08096

CC10summB<-merge(CC10summ, FMUNAMES, by="MUNO")
write.csv(CC10summB, file="2_GIS outputs for ALCES Online/clearcut.09.19xFMU.csv")

library(hrbrthemes)
#in Ottawa Valley Forest
p.OVF <- CC10 %>%
  filter(MUNO == 780)%>%
  ggplot( aes(x=RecalcHa, fill=MUNO)) +
  geom_histogram(binwidth=10, color="#e9ecef", alpha=0.6, position = 'identity') +
  #scale_fill_manual(values=c("#69b3a2", "#404080")) +
  theme_ipsum() +
  labs(fill="") #Virtually all cutblocks < 30 ha 

tiff('2_GIS outputs for ALCES Online/CC_OttawaValleyForest.tiff', units="in", width=12, height=8, res=300)
CC10 %>%
  filter(MUNO == 780)%>%
  ggplot( aes(x=RecalcHa, fill=MUNO)) +
  geom_histogram(binwidth=10, color="#e9ecef", alpha=0.6, position = 'identity') +
  #scale_fill_manual(values=c("#69b3a2", "#404080")) +
  theme_ipsum() +
  labs(fill="")
dev.off()

p.OVF40 <- CC10 %>%
  filter(MUNO == 780)%>%
  filter(RecalcHa < 40)%>%
  ggplot( aes(x=RecalcHa, ..count../sum(..count..), fill=MUNO)) +
  geom_histogram(binwidth=10, boundary=0, color="#e9ecef", alpha=0.6, position = 'identity') +
  #scale_fill_manual(values=c("#69b3a2", "#404080")) +
  theme_ipsum() +
  labs(fill="")

tiff('2_GIS outputs for ALCES Online/CC_OttawaValleyForest_40andbelow.tiff', units="in", width=12, height=8, res=300)
CC10 %>%
  filter(MUNO == 780)%>%
  filter(RecalcHa < 40)%>%
  ggplot( aes(x=RecalcHa, ..count../sum(..count..), fill=MUNO)) +
  geom_histogram(binwidth=10, boundary=0, color="#e9ecef", alpha=0.6, position = 'identity') +
  #scale_fill_manual(values=c("#69b3a2", "#404080")) +
  theme_ipsum() +
  labs(fill="")
dev.off()

#Nippissing Forest
tiff('2_GIS outputs for ALCES Online/CC_NippissingForest.tiff', units="in", width=12, height=8, res=300)
CC10 %>%
  filter(MUNO == 754)%>%
  ggplot( aes(x=RecalcHa, fill=MUNO)) +
  geom_histogram(binwidth=10, color="#e9ecef", alpha=0.6, position = 'identity') +
  #scale_fill_manual(values=c("#69b3a2", "#404080")) +
  theme_ipsum() +
  labs(fill="")
dev.off()

tiff('2_GIS outputs for ALCES Online/CC_NippissingForest_120andbelow.tiff', units="in", width=12, height=8, res=300)
CC10 %>%
  filter(MUNO == 754)%>%
  filter(RecalcHa < 120)%>%
  ggplot( aes(x=RecalcHa, ..count../sum(..count..), fill=MUNO)) +
  geom_histogram(binwidth=10, boundary=0, color="#e9ecef", alpha=0.6, position = 'identity') +
  #scale_fill_manual(values=c("#69b3a2", "#404080")) +
  theme_ipsum() +
  labs(fill="")
dev.off()

###############################################################################################
#                                                                                             #
#                                                                                             #
#                                SHELTERWOOD                                                  #
#                                                                                             #
###############################################################################################
str(SH)
nrow(SH)#34585
#In ArcGIS, shelterwood nearly all occurred in the Boreal Hardwood Transition BCR.
#Shelterwood would mostly be used in mixedwood and deciduous.
#So I'll generate summaries for each FMU. I am only interested in the 10 most recent years (2010-2019)
levels(as.factor(SH$AR_YEAR))
SH10<-SH[SH$AR_YEAR>2009,]
nrow(SH10)#17001

SH10summ<-SH10 %>%
  group_by(MUNO) %>%
  summarise(TotalArea=sum(RecalcHa), 
            MeanCutSize=mean(RecalcHa),
            MaxCutSize=max(RecalcHa))

SH10summ<-data.frame(SH10summ)

#    MUNO    TotalArea MeanCutSize MaxCutSize
# 1   140  6621.988705    1.951662  47.375635
# 2   210    80.116335    5.722595  40.876539
# 3   220  6953.209413   10.881392 179.157126
# 4   360 21845.722993   11.515932 443.157519
# 5   421    28.164486   14.082243  19.190437
# 6   451 27436.451061    3.871377 337.074153
# 7   615  9766.060645   12.918070 280.443148
# 8   680  8336.831375   10.701966 166.203587
# 9   754 10596.675867   11.960131 181.232439
# 10  780  7045.004841    5.920172  89.696711
# 11  889  4419.886854   10.701905 140.229315
# 12  898     7.555514    2.518505   5.304675

SH10summB<-merge(SH10summ, FMUNAMES, by="MUNO")
write.csv(SH10summB, file="2_GIS outputs for ALCES Online/shelterwood.09.19xFMU.csv")

library(hrbrthemes)
#in Ottawa Valley Forest
p.bht <- SH10 %>%
  filter(MUNO == 780)%>%
  ggplot( aes(x=RecalcHa, fill=MUNO)) +
  geom_histogram(binwidth=10, color="#e9ecef", alpha=0.6, position = 'identity') +
  #scale_fill_manual(values=c("#69b3a2", "#404080")) +
  theme_ipsum() +
  labs(fill="") 

tiff('2_GIS outputs for ALCES Online/SH_OttawaValleyForest.tiff', units="in", width=12, height=8, res=300)
SH10 %>%
  filter(MUNO == 780)%>%
  ggplot( aes(x=RecalcHa, fill=MUNO)) +
  geom_histogram(binwidth=10, color="#e9ecef", alpha=0.6, position = 'identity') +
  #scale_fill_manual(values=c("#69b3a2", "#404080")) +
  theme_ipsum() +
  labs(fill="") #Virtually all cutblocks < 40 ha 
dev.off()

p.OVF60 <- SH10 %>%
  filter(MUNO == 780)%>%
  filter(RecalcHa < 60)%>%
  ggplot( aes(x=RecalcHa, ..count../sum(..count..), fill=MUNO)) +
  geom_histogram(binwidth=10, boundary=0, color="#e9ecef", alpha=0.6, position = 'identity') +
  #scale_fill_manual(values=c("#69b3a2", "#404080")) +
  theme_ipsum() +
  labs(fill="")

tiff('2_GIS outputs for ALCES Online/SH_OttawaValleyForest_60andbelow.tiff', units="in", width=12, height=8, res=300)
SH10 %>%
  filter(MUNO == 780)%>%
  filter(RecalcHa < 60)%>%
  ggplot( aes(x=RecalcHa, ..count../sum(..count..), fill=MUNO)) +
  geom_histogram(binwidth=10, boundary=0, color="#e9ecef", alpha=0.6, position = 'identity') +
  #scale_fill_manual(values=c("#69b3a2", "#404080")) +
  theme_ipsum() +
  labs(fill="")
dev.off()


#Nippissing Forest
tiff('2_GIS outputs for ALCES Online/SH_NippissingForest.tiff', units="in", width=12, height=8, res=300)
SH10 %>%
  filter(MUNO == 754)%>%
  ggplot( aes(x=RecalcHa, fill=MUNO)) +
  geom_histogram(binwidth=10, color="#e9ecef", alpha=0.6, position = 'identity') +
  #scale_fill_manual(values=c("#69b3a2", "#404080")) +
  theme_ipsum() +
  labs(fill="")
dev.off()

tiff('2_GIS outputs for ALCES Online/SH_NippissingForest_120andbelow.tiff', units="in", width=12, height=8, res=300)
SH10 %>%
  filter(MUNO == 754)%>%
  filter(RecalcHa < 120)%>%
  ggplot( aes(x=RecalcHa, ..count../sum(..count..), fill=MUNO)) +
  geom_histogram(binwidth=10, boundary=0, color="#e9ecef", alpha=0.6, position = 'identity') +
  #scale_fill_manual(values=c("#69b3a2", "#404080")) +
  theme_ipsum() +
  labs(fill="")
dev.off()

###############################################################################################
#                                                                                             #
#                                                                                             #
#                                SELECTIVE LOGGING                                            #
#                                                                                             #
###############################################################################################
str(SEL)
nrow(SEL)#20956
#In ArcGIS, selective logging nearly all occurred in the Boreal Hardwood Transition BCR.
#Shelterwood would mostly be used in mixedwood and deciduous.
#So I'll generate summaries for each BCR. I am only interested in the 10 most recent years (2010-2019)
levels(as.factor(SEL$AR_YEAR))
SEL10<-SEL[SEL$AR_YEAR>2009,]
nrow(SEL10)#9964

SEL10summ<-SEL10 %>%
  group_by(MUNO) %>%
  summarise(TotalArea=sum(RecalcHa), 
            MeanCutSize=mean(RecalcHa),
            MaxCutSize=max(RecalcHa))

SEL10summ<-data.frame(SEL10summ)

#    MUNO    TotalArea MeanCutSize MaxCutSize
# 1   140  4499.14051    2.100439  70.964147
# 2   220  9124.79354   11.307055 227.218691
# 3   360 15761.15553   17.358101 491.191108
# 4   451 27581.27730    5.673992 205.790043
# 5   615 15374.70489   19.028100 337.174189
# 6   680  1158.25714   13.014125  77.786267
# 7   754  1644.59552   25.301470 172.580869
# 8   780  2043.59095    6.744525  76.524691
# 9   889   129.27229   12.927229  36.236531
# 10  898    10.44335    2.610837   4.130444

SEL10summB<-merge(SEL10summ, FMUNAMES, by="MUNO")
write.csv(SEL10summB, file="2_GIS outputs for ALCES Online/selective.09.19xFMU.csv")

library(hrbrthemes)
#in Ottawa Valley Forest
p.OVF <- SEL10 %>%
  filter(MUNO == 780)%>%
  ggplot( aes(x=RecalcHa, fill=MUNO)) +
  geom_histogram(binwidth=10, color="#e9ecef", alpha=0.6, position = 'identity') +
  #scale_fill_manual(values=c("#69b3a2", "#404080")) +
  theme_ipsum() +
  labs(fill="") 

tiff('2_GIS outputs for ALCES Online/SEL_OttawaValleyForest.tiff', units="in", width=12, height=8, res=300)
SEL10 %>%
  filter(MUNO == 780)%>%
  ggplot( aes(x=RecalcHa, fill=MUNO)) +
  geom_histogram(binwidth=10, color="#e9ecef", alpha=0.6, position = 'identity') +
  #scale_fill_manual(values=c("#69b3a2", "#404080")) +
  theme_ipsum() +
  labs(fill="")
dev.off()

p.OVF60 <- SEL10 %>%
  filter(MUNO == 780)%>%
  filter(RecalcHa < 60)%>%
  ggplot( aes(x=RecalcHa, ..count../sum(..count..), fill=MUNO)) +
  geom_histogram(binwidth=10, boundary=0, color="#e9ecef", alpha=0.6, position = 'identity') +
  #scale_fill_manual(values=c("#69b3a2", "#404080")) +
  theme_ipsum() +
  labs(fill="")

tiff('2_GIS outputs for ALCES Online/SEL_OttawaValleyForest_60andbelow.tiff', units="in", width=12, height=8, res=300)
SEL10 %>%
  filter(MUNO == 780)%>%
  filter(RecalcHa < 60)%>%
  ggplot( aes(x=RecalcHa, ..count../sum(..count..), fill=MUNO)) +
  geom_histogram(binwidth=10, boundary=0, color="#e9ecef", alpha=0.6, position = 'identity') +
  #scale_fill_manual(values=c("#69b3a2", "#404080")) +
  theme_ipsum() +
  labs(fill="")
dev.off()


#Nippissing Forest
tiff('2_GIS outputs for ALCES Online/SEL_NippissingForest.tiff', units="in", width=12, height=8, res=300)
SEL10 %>%
  filter(MUNO == 754)%>%
  ggplot( aes(x=RecalcHa, fill=MUNO)) +
  geom_histogram(binwidth=10, color="#e9ecef", alpha=0.6, position = 'identity') +
  #scale_fill_manual(values=c("#69b3a2", "#404080")) +
  theme_ipsum() +
  labs(fill="")
dev.off()

tiff('2_GIS outputs for ALCES Online/SEL_NippissingForest_180andbelow.tiff', units="in", width=12, height=8, res=300)
SEL10 %>%
  filter(MUNO == 754)%>%
  filter(RecalcHa < 180)%>%
  ggplot( aes(x=RecalcHa, ..count../sum(..count..), fill=MUNO)) +
  geom_histogram(binwidth=10, boundary=0, color="#e9ecef", alpha=0.6, position = 'identity') +
  #scale_fill_manual(values=c("#69b3a2", "#404080")) +
  theme_ipsum() +
  labs(fill="")
dev.off()

#Considering the large number of FMUs for which I am running simulations, and
#the arbritrary decisions of how to bin size classes in each FMU, I decided to just
#use mean harvest size rather than a size class distribution in each FMU,
#unlike what I am doing (size classes for harvest) in the much larger Bird
#Conservation Region 13.