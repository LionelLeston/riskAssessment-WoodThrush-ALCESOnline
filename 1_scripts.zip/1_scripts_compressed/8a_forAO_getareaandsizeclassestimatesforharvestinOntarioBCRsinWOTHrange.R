#Note: This script is for estimating area and size class distributions
#of clear-cut, shelterwood, and selectively logged areas within Ontario 
#Wood Thrush range. These layers aren't
#used as variables in the BRT or GLM models for ALCES Online scenarios
#but are necessary for modeling realistic harvest amounts in the simulations.

#I am using GIS data updated as recently as 2019 by the Ontario Ministry of 
#Natural Resources Forest Research Institute (Email: info.mnrfscience@ontario.ca).
#Clear-cut, shelterwood, and selectively-logged forest polygons were intersected in
#ArcGIS with Bird Conservation Region polygons, so that I can get separate area and
#size class distributions by BCR and see where each type of harvest is concentrated.

#Note: one of the Ontario BCRs (Great Lakes/St. Lawrence Plain) occurs outside of the
#FMUs where there is GIS data from info.mnrfscience@ontario.ca, so harvest in that
#BCR (in private woodlots) is accounted for separately, from reports and published papers.

#I will start by importing three csv files containing the areas of individual harvest polygons
#limited to those within the updated Wood Thrush range in Ontario.

library(raster)
library(dismo)
library(rpart)
library(maptools)
library(data.table)
library(rgdal)
library(dplyr)
library(ggplot2)
library(spatial)
library(rasterVis)
library(RColorBrewer)

#changed nested folder from "forest disturbance metrics" to "Recent Harvest"
CC<-read.csv("2_GIS outputs for ALCES Online/Recent Harvest/Harvest X Year X BCR/ClearcutXYearXBCRXWOTH.csv")
SH<-read.csv("2_GIS outputs for ALCES Online/Recent Harvest/Harvest X Year X BCR/ShelterwoodXYearXBCRXWOTH.csv")
SEL<-read.csv("2_GIS outputs for ALCES Online/Recent Harvest/Harvest X Year X BCR/SelectiveXYearXBCRXWOTH.csv")

###############################################################################################
#                                                                                             #
#                                                                                             #
#                                CLEAR-CUTS                                                   #
#                                                                                             #
###############################################################################################
str(CC)
nrow(CC)#77095
#In ArcGIS, clearcuts occurred in both Boreal Softwood Shield and Boreal Hardwood Transition.
#Clearcuts would mostly occur in conifer-dominated stands but would be recommended for aspen/poplar as 
#well.
#So I'll generate summaries for each BCR. I am only interested in the 10 most recent years (2010-2019)
levels(as.factor(CC$AR_YEAR))
CC10<-CC[CC$AR_YEAR>2009,]
nrow(CC10)#35013

CC10summ<-CC10 %>%
  group_by(BCRNAME) %>%
  summarise(TotalArea=sum(RecalcHa), 
            MeanCutSize=mean(RecalcHa),
            MaxCutSize=max(RecalcHa))

#BCRNAME                               TotalArea          MeanCutSize MaxCutSize
#1 BOREAL HARDWOOD TRANSITION            148238.00 (57%)         7.29     482.00
#2 BOREAL SOFTWOOD SHIELD                112650.00  (43%)        7.67     229.00
#3 LOWER GREAT LAKES/ ST. LAWRENCE PLAIN      4.18               4.18       4.18

#Total Harvested=260888 ha

library(hrbrthemes)
#in Boreal Hardwood Transition BCR
p.bht <- CC10 %>%
  filter(BCRNAME == "BOREAL HARDWOOD TRANSITION")%>%
  ggplot( aes(x=RecalcHa, fill=BCRNAME)) +
  geom_histogram( color="#e9ecef", alpha=0.6, position = 'identity') +
  scale_fill_manual(values=c("#69b3a2", "#404080")) +
  theme_ipsum() +
  labs(fill="") #Virtually all cutblocks < 35 ha 

tiff('2_GIS outputs for ALCES Online/CC_BorealHardwoodTransition.tiff', units="in", width=12, height=8, res=300)
CC10 %>%
  filter(BCRNAME == "BOREAL HARDWOOD TRANSITION")%>%
  ggplot( aes(x=RecalcHa, fill=BCRNAME)) +
  geom_histogram( color="#e9ecef", alpha=0.6, position = 'identity') +
  scale_fill_manual(values=c("#69b3a2", "#404080")) +
  theme_ipsum() +
  labs(fill="")
dev.off()

p.bht35 <- CC10 %>%
  filter(BCRNAME == "BOREAL HARDWOOD TRANSITION")%>%
  filter(RecalcHa < 35)%>%
  ggplot( aes(x=RecalcHa, ..count../sum(..count..), fill=BCRNAME)) +
  geom_histogram( color="#e9ecef", alpha=0.6, position = 'identity', bins=4) +
  scale_fill_manual(values=c("#69b3a2", "#404080")) +
  theme_ipsum() +
  labs(fill="")

tiff('2_GIS outputs for ALCES Online/CC_BorealHardwoodTransition_35andbelow.tiff', units="in", width=12, height=8, res=300)
CC10 %>%
  filter(BCRNAME == "BOREAL HARDWOOD TRANSITION")%>%
  filter(RecalcHa < 35)%>%
  ggplot( aes(x=RecalcHa, ..count../sum(..count..), fill=BCRNAME)) +
  geom_histogram( color="#e9ecef", alpha=0.6, position = 'identity', bins=4) +
  scale_fill_manual(values=c("#69b3a2", "#404080")) +
  theme_ipsum() +
  labs(fill="")
dev.off()
#About 70 % of clearcuts are 0-5 ha (Use 2.5 ha for size class)
#About 20 % of clearcuts are 5-17.5 ha (Use 11 ha for size class)
#About 10 % of clearcuts are 17.5-35 ha (Use 26 ha for size class)

#There will a few larger than that since 
#the maximum allowable clearcut size is 260 ha
#but that's in exceptional cases

#In Boreal Softwood Shield BCR
p.bss <- CC10 %>%
  filter(BCRNAME == "BOREAL SOFTWOOD SHIELD")%>%
  ggplot( aes(x=RecalcHa, fill=BCRNAME)) +
  geom_histogram( color="#e9ecef", alpha=0.6, position = 'identity') +
  scale_fill_manual(values=c("#69b3a2", "#404080")) +
  theme_ipsum() +
  labs(fill="") #Virtually all cutblocks < 50 ha 

tiff('2_GIS outputs for ALCES Online/CC_BorealSoftwoodShield.tiff', units="in", width=12, height=8, res=300)
CC10 %>%
  filter(BCRNAME == "BOREAL SOFTWOOD SHIELD")%>%
  ggplot( aes(x=RecalcHa, fill=BCRNAME)) +
  geom_histogram( color="#e9ecef", alpha=0.6, position = 'identity') +
  scale_fill_manual(values=c("#69b3a2", "#404080")) +
  theme_ipsum() +
  labs(fill="") #Virtually all cutblocks < 50 ha 
dev.off()

p.bss50 <- CC10 %>%
  filter(BCRNAME == "BOREAL SOFTWOOD SHIELD")%>%
  filter(RecalcHa < 50)%>%
  ggplot( aes(x=RecalcHa, ..count../sum(..count..), fill=BCRNAME)) +
  geom_histogram( color="#e9ecef", alpha=0.6, position = 'identity', bins=4) +
  scale_fill_manual(values=c("#69b3a2", "#404080")) +
  theme_ipsum() +
  labs(fill="")

tiff('2_GIS outputs for ALCES Online/CC_BorealSoftwoodShield_50andbelow.tiff', units="in", width=12, height=8, res=300)
CC10 %>%
  filter(BCRNAME == "BOREAL SOFTWOOD SHIELD")%>%
  filter(RecalcHa < 50)%>%
  ggplot( aes(x=RecalcHa, ..count../sum(..count..), fill=BCRNAME)) +
  geom_histogram( color="#e9ecef", alpha=0.6, position = 'identity', bins=4) +
  scale_fill_manual(values=c("#69b3a2", "#404080")) +
  theme_ipsum() +
  labs(fill="") 
dev.off()

#About 76 % of clearcuts are 0-8 ha (Use 4 ha)
#About 19 % of clearcuts are 8-25 ha (Use 16.5 ha)
#About 4 % of clearcuts are 25-41 ha (Use 33 ha)
#About 1 % of clearcuts are 41-58 ha (Use 49.5 ha)

###############################################################################################
#                                                                                             #
#                                                                                             #
#                                SHELTERWOOD                                                  #
#                                                                                             #
###############################################################################################
str(SH)
nrow(SH)#34585
#In ArcGIS, shelterwood nearly all occurred in the Boreal Hardwood Transition BCR.
#Shelterwood would mostly be used in mixedwood and deciduous.
#So I'll generate summaries for each BCR. I am only interested in the 10 most recent years (2010-2019)
levels(as.factor(SH$AR_YEAR))
SH10<-SH[SH$AR_YEAR>2009,]
nrow(SH10)#17001

SH10summ<-SH10 %>%
  group_by(BCRNAME) %>%
  summarise(TotalArea=sum(RecalcHa), 
            MeanCutSize=mean(RecalcHa),
            MaxCutSize=max(RecalcHa))

#BCRNAME                               TotalArea     MeanCutSize MaxCutSize
#1 BOREAL HARDWOOD TRANSITION         101506.00          5.97     443.00  
#2 GREAT LAKES                            17.70          2.53      16.30 
#3 LOWER GREAT LAKES/ ST. LAWRENCE P~      3.31          1.65       2.72
library(hrbrthemes)
#in Boreal Hardwood Transition BCR
p.bht <- SH10 %>%
  filter(BCRNAME == "BOREAL HARDWOOD TRANSITION")%>%
  ggplot( aes(x=RecalcHa, fill=BCRNAME)) +
  geom_histogram( color="#e9ecef", alpha=0.6, position = 'identity') +
  scale_fill_manual(values=c("#69b3a2", "#404080")) +
  theme_ipsum() +
  labs(fill="") #Virtually all cutblocks < 100 ha 

tiff('2_GIS outputs for ALCES Online/SH_BorealHardwoodTransition.tiff', units="in", width=12, height=8, res=300)
SH10 %>%
  filter(BCRNAME == "BOREAL HARDWOOD TRANSITION")%>%
  ggplot( aes(x=RecalcHa, fill=BCRNAME)) +
  geom_histogram( color="#e9ecef", alpha=0.6, position = 'identity') +
  scale_fill_manual(values=c("#69b3a2", "#404080")) +
  theme_ipsum() +
  labs(fill="")
dev.off()

p.bht100 <- SH10 %>%
  filter(BCRNAME == "BOREAL HARDWOOD TRANSITION")%>%
  filter(RecalcHa < 100)%>%
  ggplot( aes(x=RecalcHa, ..count../sum(..count..), fill=BCRNAME)) +
  geom_histogram( color="#e9ecef", alpha=0.6, position = 'identity', bins=4) +
  scale_fill_manual(values=c("#69b3a2", "#404080")) +
  theme_ipsum() +
  labs(fill="")

tiff('2_GIS outputs for ALCES Online/SH_BorealHardwoodTransition_100andbelow.tiff', units="in", width=12, height=8, res=300)
SH10 %>%
  filter(BCRNAME == "BOREAL HARDWOOD TRANSITION")%>%
  filter(RecalcHa < 100)%>%
  ggplot( aes(x=RecalcHa, ..count../sum(..count..), fill=BCRNAME)) +
  geom_histogram( color="#e9ecef", alpha=0.6, position = 'identity', bins=4) +
  scale_fill_manual(values=c("#69b3a2", "#404080")) +
  theme_ipsum() +
  labs(fill="")
dev.off()

#About 90 % of shelterwood blocks are 0-15 ha (Use 7.5 ha)
#About 9 % of shelterwood blocks are 15-50 ha (Use 32.5)
#About 1 % of shelterwood blocks are 50-82.5 ha (Use 66.5)

###############################################################################################
#                                                                                             #
#                                                                                             #
#                                SELECTIVE LOGGING                                            #
#                                                                                             #
###############################################################################################
str(SEL)
nrow(SEL)#20956
#In ArcGIS, selective logging nearly all occurred in the Boreal Hardwood Transition BCR.
#Shelterwood would mostly be used in mixedwood and deciduous.
#So I'll generate summaries for each BCR. I am only interested in the 10 most recent years (2010-2019)
levels(as.factor(SEL$AR_YEAR))
SEL10<-SEL[SEL$AR_YEAR>2009,]
nrow(SEL10)#9964

SEL10summ<-SEL10 %>%
  group_by(BCRNAME) %>%
  summarise(TotalArea=sum(RecalcHa), 
            MeanCutSize=mean(RecalcHa),
            MaxCutSize=max(RecalcHa))

#BCRNAME                               TotalArea     MeanCutSize MaxCutSize
#1 BOREAL HARDWOOD TRANSITION            76468.00         7.68      491.00 
#2 LOWER GREAT LAKES/ ST. LAWRENCE PL~      27.10         9.04       20.20

library(hrbrthemes)
#in Boreal Hardwood Transition BCR
p.bht <- SEL10 %>%
  filter(BCRNAME == "BOREAL HARDWOOD TRANSITION")%>%
  ggplot( aes(x=RecalcHa, fill=BCRNAME)) +
  geom_histogram( color="#e9ecef", alpha=0.6, position = 'identity') +
  scale_fill_manual(values=c("#69b3a2", "#404080")) +
  theme_ipsum() +
  labs(fill="") #Virtually all cutblocks < 100 ha 

tiff('2_GIS outputs for ALCES Online/SEL_BorealHardwoodTransition.tiff', units="in", width=12, height=8, res=300)
SEL10 %>%
  filter(BCRNAME == "BOREAL HARDWOOD TRANSITION")%>%
  ggplot( aes(x=RecalcHa, fill=BCRNAME)) +
  geom_histogram( color="#e9ecef", alpha=0.6, position = 'identity') +
  scale_fill_manual(values=c("#69b3a2", "#404080")) +
  theme_ipsum() +
  labs(fill="")
dev.off()

p.bht100 <- SEL10 %>%
  filter(BCRNAME == "BOREAL HARDWOOD TRANSITION")%>%
  filter(RecalcHa < 100)%>%
  ggplot( aes(x=RecalcHa, ..count../sum(..count..), fill=BCRNAME)) +
  geom_histogram( color="#e9ecef", alpha=0.6, position = 'identity', bins=4) +
  scale_fill_manual(values=c("#69b3a2", "#404080")) +
  theme_ipsum() +
  labs(fill="")

tiff('2_GIS outputs for ALCES Online/SEL_BorealHardwoodTransition_100andbelow.tiff', units="in", width=12, height=8, res=300)
SEL10 %>%
  filter(BCRNAME == "BOREAL HARDWOOD TRANSITION")%>%
  filter(RecalcHa < 100)%>%
  ggplot( aes(x=RecalcHa, ..count../sum(..count..), fill=BCRNAME)) +
  geom_histogram( color="#e9ecef", alpha=0.6, position = 'identity', bins=4) +
  scale_fill_manual(values=c("#69b3a2", "#404080")) +
  theme_ipsum() +
  labs(fill="")
dev.off()

#About 87.5 % of selection blocks are 0-16 ha (Use 8 ha)
#About 10 % of selection blocks are 16-50 ha (Use 33 ha)
#About 2 % of selection blocks are 50-82.5 ha (Use 66.25 ha)
#About 0.5 % of selection blocks are 82.5-115 ha (Use 98.75 ha)

#Note: my original plan was to simulate future land use in ALCES 
#Online separately by Bird Conservation Regions, but these areas 
#were too large memory-wise to run simulations at 200-m resolution,
#only coarser resolutions like 500 m. So for most of the Wood Thrush
#range in Ontario, I switched to summarizing then simulating 
#disturbance separately by Forest Management Unit. It was only later
#in mid August that ALCES Online was tweaked to allow me to model
#Bird Conservation Region 13 (most of which occurs outside of FMU
#boundaries) at 200-m resolution.
