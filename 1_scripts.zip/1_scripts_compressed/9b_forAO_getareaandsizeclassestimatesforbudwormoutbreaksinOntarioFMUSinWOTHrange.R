#Note: This script is for estimating area and size class distributions
#of spruce budworm outbreak areas within Ontario Wood Thrush range. These layers aren't
#used as variables in the BRT or GLM models for ALCES Online scenarios
#but are necessary for modeling changes in forest age structure in the simulations.

#I am using GIS data updated as recently as 2020 by the Ontario Ministry of 
#Natural Resources' Forest Research Inventory. Insect outbreak polygons were intersected in
#ArcGIS with Forest Management Unit polygons, so that I can get separate area and
#size class distributions by FMU and see where budworm outbreaks are concentrated. There 
#are other forest insect pests in the database, but I am only measuring the areas of 
#budworm outbreaks severe enough to be forest mortality events.

#I will start by importing a csv files containing the areas of individual outbreak polygons
#limited to those within the updated Wood Thrush range in Ontario.

library(raster)
library(dismo)
library(rpart)
library(maptools)
library(data.table)
library(rgdal)
library(dplyr)
library(ggplot2)
library(spatial)
library(rasterVis)
library(RColorBrewer)

OUTB<-read.csv("2_GIS outputs for ALCES Online/Recent NonHarvest/InsectXYearXBCR/InsectXYearXBCRXFMU.csv")
FMUNAMES<-read.csv("2_GIS outputs for ALCES Online/Recent Harvest/Harvest X Year X BCR/FMUNAMES.csv")
FMUNAMES$MUNO<-FMUNAMES$Management.unit

###############################################################################################
#                                                                                             #
#                                                                                             #
#                                BUDWORM                                                   #
#                                                                                             #
###############################################################################################
str(OUTB)
nrow(OUTB)#503474

#So I'll generate summaries for each Forest Management Unit. 
#I am only interested in the 10 most recent years (2010-2019) 
#and only in budworm outbreaks that cause mortality, opening
#up the forest
levels(as.factor(OUTB$YEAR_OF_EV))
OUTB10<-OUTB[OUTB$YEAR_OF_EV>2010,]
nrow(OUTB10)#178293

OUTB10budwormsumm<-OUTB10 %>%
  filter(FOREST_INS=="Spruce Budworm")%>%
  group_by(FMU_NAME, FOREST_DAM) %>%
  summarise(TotalArea=sum(RecalcHa), 
            MeanCutSize=mean(RecalcHa),
            MaxCutSize=max(RecalcHa))

OUTB10budwormsummB<-data.frame(OUTB10budwormsumm)
write.csv(OUTB10budwormsummB, file="2_GIS outputs for ALCES Online/budworm.10.20xFMU.csv")
#No meaningful budworm outbreaks in Ottawa Valley Forest in last 10 years

library(hrbrthemes)
#in Nippissing FMU

tiff('2_GIS outputs for ALCES Online/BUDWORM_NippissingForest.tiff', units="in", width=12, height=8, res=300)
OUTB10 %>%
  filter(FOREST_INS=="Spruce Budworm")%>%
  filter(FMU_NAME == "Nipissing Forest")%>%
  filter(FOREST_DAM == "Mortality")%>%
  filter(RecalcHa<350)%>%
  ggplot( aes(x=RecalcHa, fill=FMU_NAME)) +
  geom_histogram(binwidth=50, boundary=0, color="#e9ecef", alpha=0.6, position = 'identity') +
  #scale_fill_manual(values=c("#69b3a2", "#404080", "red")) +
  theme_ipsum() +
  labs(fill="")
dev.off()


tiff('2_GIS outputs for ALCES Online/BUDWORM_NippissingForest_Proportions.tiff', units="in", width=12, height=8, res=300)
OUTB10 %>%
  filter(FOREST_INS=="Spruce Budworm")%>%
  filter(FMU_NAME == "Nipissing Forest")%>%
  filter(RecalcHa<350)%>%
  filter(FOREST_DAM == "Mortality")%>%
  ggplot( aes(x=RecalcHa, ..count../sum(..count..), fill=FMU_NAME)) +
  geom_histogram(binwidth=50, boundary=0,  color="#e9ecef", alpha=0.6, position = 'identity') +
  #scale_fill_manual(values=c("#69b3a2", "#404080", "red")) +
  theme_ipsum() +
  labs(fill="")
dev.off()

#About 90 % of mortal outbreaks are 0-50 ha (Use 25 ha for size class)
#About 7.5 % of mortal outbreaks are 50-150 ha (Use 125 ha for size class)
#About 2.5 % of mortal outbreaks are 150-250 ha (Use 200 ha for size class)

#Considering the large number of FMUs to generate histograms for and considering
#that some of the bins for different sizes may be arbitrary decisions, I think
#I will just use mean disturbance size for budworm outbreaks in each FMU rather
#than generate a separate size class distribution for each FMU. I will keep a 
#size class distribution when modelling budworm outbreaks in Bird Conservation Region
#13 though.