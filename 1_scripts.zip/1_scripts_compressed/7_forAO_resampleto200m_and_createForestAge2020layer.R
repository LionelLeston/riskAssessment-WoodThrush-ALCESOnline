#Note: This script is for clipping forest disturbance metrics (resampled to
#200 m) to Ontario Wood Thrush range. These layers aren't
#used as variables in the BRT or GLM models for ALCES Online scenarios
#but are necessary for modeling different types of disturbance as
#well as recalculating forest stand age prior to Year 0 of simulations.
#Harvest, fire, insect outbreak layers need to be added to ALCES Online.
library(raster)
library(dismo)
library(rpart)
library(maptools)
library(data.table)
library(rgdal)
library(dplyr)
library(ggplot2)
library(spatial)
library(rasterVis)
library(RColorBrewer)



####################################################################
#                                                                  #
#                                                                  #
#                                                                  #
#                   STEP ONE - CLIP NATIONAL LAYERS                #
#                        TO SMALLER AREA                           #
#                                                                  #
#                                                                  #
####################################################################


#First, we need a tif file of the Wood Thrush study area
library(sf)
lcc_crs <-"+proj=lcc +lat_1=49 +lat_2=77 +lat_0=0 +lon_0=-95 +x_0=0 +y_0=0
+datum=NAD83 +units=m +no_defs +ellps=GRS80 +towgs84=0,0,0"
lat_long <- "+proj=longlat +datum=WGS84 +ellps=WGS84 +towgs84=0,0,0"

prov <- st_read("0_data_for_BRT_models/raw/UpdatedRangeKD_JustOntario/UpdatedRangeKD_JustOntario.shp")
str(prov)
#on<-prov[prov$STATEABB=="CA-ON",]
#st_write(on, "0_data_for_BRT_models/raw/UpdatedCanadianRangeKernelDensity/UpdatedRangeKD_JustOntario.shp")

st_crs(prov)<-"+proj=longlat +datum=WGS84 +ellps=WGS84 +towgs84=0,0,0"
WOTHsf <- st_transform(prov, lcc_crs)
ggplot() + 
  geom_sf(data = WOTHsf, size = 0.5, color = "black", fill = "white") + 
  ggtitle("Wood Thrush study area") + 
  coord_sf()

extent(WOTHsf)
#e. Now use the raster package to convert to a raster and set its CRS
#r.0E = raster()#default
#extent(r.0E) = extent(bcsf)
#projection(r.0E) = CRS("+proj=lcc +lat_1=49 +lat_2=77 +lat_0=0 +lon_0=-95 +x_0=0 +y_0=0
#+datum=NAD83 +units=m +no_defs +ellps=GRS80 +towgs84=0,0,0")
#res(r.0E)<-250#set resolution to 250 m, same as Beaudoin
#rp <- rasterize(bcsf, r.0E, 'PRNAME')

#import Beaudoin Stand Age 2011 clipped and resampled to 200 m
beaudoinstandage2011<-raster("0_data_for_BRT_models/raw/Beaudoin/2011/Processed/Beaudoin 2011 TIFFs WOTHstudyarea/local_Structure_Stand_Age_v1.tif")
ras<-beaudoinstandage2011
#change resolution from 250x250 to 200x200
resampleFactor <- 200/250
inCols <- ncol(ras)
inRows <- nrow(ras)
resampledRaster <- raster(ncol=(inCols / resampleFactor), nrow=(inRows / resampleFactor))
extent(resampledRaster) <- extent(ras)
crs(resampledRaster) <-crs(ras)
res(resampledRaster)<-200#set to exactly 200 m before resampling occurs
resampledRaster <- resample(ras,resampledRaster,datatype="INT1U",method='bilinear')
names(resampledRaster)<-"BeaudoinStandAge2011local.200m"
writeRaster(resampledRaster, filename="0_data_for_BRT_models/raw/Beaudoin/2011/Processed/Beaudoin 2011 TIFFs WOTHstudyarea/local_Structure_Stand_Age_v1_200m.tif",overwrite=TRUE)

#clip resampled Beaudoin stand age to study area
Beaudoin.crop<-crop(resampledRaster, WOTHsf)
Beaudoin.mask<-crop(Beaudoin.crop, WOTHsf)
writeRaster(Beaudoin.mask, filename="0_data_for_BRT_models/raw/Beaudoin/2011/Processed/Beaudoin 2011 TIFFs WOTHstudyarea/local_Structure_Stand_Age_v1_200m_Ontario.tif",overwrite=TRUE)
plot(Beaudoin.mask)

#import forest layers for Ontario from 2020
#I will calculate total forest proportion, resample
#to 200 m, clip to study area

#Then once I am able to stack all files, stand 
#age in any pixel with zero forest will be set to 0.

#Deciduous
decid2020<-raster("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/150 m/on2020_decid.150m.tif")

#Coniferous
conif2020<-raster("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/150 m/on2020_conif.150m.tif")

#Mixedwood
mixed2020<-raster("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/150 m/on2020_mixed.150m.tif")

#Total
totalforest2020<-decid2020+conif2020+mixed2020
ras2<-totalforest2020
#change resolution from 250x250 to 200x200
resampleFactor <- 200/250
inCols2 <- ncol(ras2)
inRows2 <- nrow(ras2)
resampledRaster2 <- raster(ncol=(inCols2 / resampleFactor), nrow=(inRows2 / resampleFactor))
extent(resampledRaster2) <- extent(ras2)
crs(resampledRaster2) <-crs(ras2)
res(resampledRaster2)<-200#set to exactly 200 m before resampling occurs
resampledRaster2 <- resample(ras2,resampledRaster2,datatype="INT1U",method='bilinear')
names(resampledRaster2)<-"TotalForest2020local.200m"

#clip resampled Total Forest layer to study area
resampledRaster2<-projectRaster(resampledRaster2, crs=lcc_crs)

Totalforest.crop<-crop(resampledRaster2, WOTHsf)
Totalforest.mask<-crop(Totalforest.crop, WOTHsf)
plot(Totalforest.mask)

#import recent harvest year and clip to study area
#This layer was created from Ontario Ministry of Natural Resources FMU data in ArcGIS
#Data processing was done as follows in ArcGIS outside of this R project

#individual shapefiles were added to ArcGIS from the geodatabase AR_Master.gdb:
#HARVEST_Est_1990_03 (all harvest types from before 2003)
#HARVEST_CC02
#HARVEST_CC17
#HARVEST_SE02
#HARVEST_SE17
#HARVEST_SH02
#HARVEST_SH17

#These shapefiles were combined, then the 10 most recent years of harvest
#were exported to a new shapefile, from which individual rasters were used 
#to create a 200-m resolution provincial harvest year mask. These GIS 
#products are stored in the folder "2_GIS outputs for ALCES Online/Recent 
#Harvest" with the AR_Master geodatabase.

#The harvest year mask was clipped to the Wood
#Thrush range in Ontario and missing values in non-harvest pixels were converted to 0. 

hyear <- raster("2_GIS outputs for ALCES Online/Recent Harvest/HARVESTYEAR_11_19.tif")
hyearB<-projectRaster(hyear, crs=lcc_crs)
hyear.crop<-crop(hyearB, WOTHsf)
hyear.mask<-crop(hyear.crop, WOTHsf)
plot(hyear.mask)
hyear.mask[is.na(hyear.mask)]<-0
writeRaster(hyear.mask, filename="2_GIS outputs for ALCES Online/CreateForestAgeLayerForALCESOnline/HARVESTYEAR_11_19.Ontario.tif",overwrite=TRUE)

#import recent insect disturbance year and clip to study area
#This layer was created from the "Forest_Insect_Damage_Event.shp" shapefile in 
#the Ontario FRI data in ArcGIS.

#Outbreak polygons were selected if they were associated with severe outbreaks (classed 
#as "Mortality") of any insect species over the last 10 years, then results were
#were exported to a new shapefile, from which individual rasters were used 
#to create a 200-m resolution provincial insect outbreak year mask. These GIS 
#products are stored in the folder "2_GIS outputs for ALCES Online/Recent 
#NonHarvest/Ontario FRI".

#The insect outbreak year mask was clipped to the Wood
#Thrush range in Ontario and missing values in non-harvest pixels were converted to 0. 

iyear <- raster("2_GIS outputs for ALCES Online/Recent NonHarvest/mortoutbreakyear.tif")
iyearB<-projectRaster(iyear, crs=lcc_crs)
iyear.crop<-crop(iyearB, WOTHsf)
iyear.mask<-crop(iyear.crop, WOTHsf)
plot(iyear.mask)
iyear.mask[is.na(iyear.mask)]<-0
writeRaster(iyear.mask, filename="2_GIS outputs for ALCES Online/CreateForestAgeLayerForALCESOnline/mortoutbreakyear.Ontario.tif",overwrite=TRUE)

#import recent fire disturbance year and clip to study area
#This layer was downloaded from https://geohub.lio.gov.on.ca/datasets/lio::fire-disturbance-area/about
#at Ontario GeoHub.

#Fire polygons were selected if they were from the last 10 years, then results were
#were exported to a new shapefile, from which individual rasters were used 
#to create a 200-m resolution provincial fire year mask. These GIS 
#products are stored in the folder "2_GIS outputs for ALCES Online/Recent 
#Fire Disturbance Area".

#The fire year mask was clipped to the Wood
#Thrush range in Ontario and missing values in non-harvest pixels were converted to 0. 

fyear <- raster("2_GIS outputs for ALCES Online/Fire Disturbance Area/Fires_11_20_LCC.tif")
fyearB<-projectRaster(fyear, crs=lcc_crs)
fyear.crop<-crop(fyearB, WOTHsf)
fyear.mask<-crop(fyear.crop, WOTHsf)
plot(fyear.mask)
fyear.mask[is.na(fyear.mask)]<-0
writeRaster(fyear.mask, filename="2_GIS outputs for ALCES Online/CreateForestAgeLayerForALCESOnline/Fires_11_20_LCC.Ontario.tif",overwrite=TRUE)

#now stack layers so they can be related to one another
#Conversion of rasters into same extent (largest extent is for resampledRaster)
hyear_resampled <- resample(hyear.mask, Beaudoin.mask, method='bilinear')
iyear_resampled <- resample(iyear.mask, Beaudoin.mask, method='bilinear')
fyear_resampled <- resample(fyear.mask, Beaudoin.mask, method='bilinear')
totalforest_resampled <- resample(Totalforest.mask, Beaudoin.mask, method='bilinear')

#Stack the rasters
pred_ontario<-stack(Beaudoin.mask, totalforest_resampled, hyear_resampled, iyear_resampled, fyear_resampled, quick=TRUE)
names(pred_ontario)#shows that rasters are overlaid
age2020<-Beaudoin.mask+9#by default, stand age from Beaudoin layer + 9 years
recent<-max(hyear_resampled,iyear_resampled,fyear_resampled)
recent[is.na(recent)]<-0
age2020.b<-overlay(age2020, 
                 recent,
                 fun=function(age2020, 
                              recent){return(ifelse((recent>2010),
                                                             (2020-recent), age2020))})

plot(age2020.b)

totalforest_resampled[is.na(totalforest_resampled)]<-0
age2020.c<-overlay(age2020.b, 
                   totalforest_resampled,
                   fun=function(age2020.b, 
                                totalforest_resampled){return(ifelse((totalforest_resampled==0),
                                                      0, age2020.b))})

plot(age2020.c)


writeRaster(age2020.c, filename="2_GIS outputs for ALCES Online/CreateForestAgeLayerForALCESOnline/ForestAge2020.Ontario.tif",overwrite=TRUE)