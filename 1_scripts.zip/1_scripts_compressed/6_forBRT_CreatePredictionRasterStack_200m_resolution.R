memory.limit(size=56000)
# Load packages and data
library(data.table)
library(dismo)
library(dplyr)
library(ggplot2)
library(maptools)
library(raster)
library(rgeos)
library(rpart)
library(rgdal)
library(sf)
library(stars)

# Preparing data
# I have a single study area covering multiple provinces
# but for the ALCES models, I am really only interested in
# generating a prediction layer for Ontario.

# Load avian datasets, region raster(s), project and extract data for each province 
# The variables I need predictors for are stored within:
load("0_data_for_BRT_models/processed/pointswithdataApril5_C.RData")
# Variables in prediction stacks must have exactly the same names

###################################################################################
#                                                                                 #
#                                                                                 #
#                                                                                 #
#                                 ONTARIO PREDICTION STACK                        #
#                                                                                 #
#                                                                                 #
#                                                                                 #
###################################################################################

#Start with Ontario: use one of the Landsat annual cover (2020) layers from Ontario
ontario <- raster("E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 200 m/150 m/on2020_decid.150m.tif")
LAEA<-"+proj=aea +lat_0=40 +lon_0=-96 +lat_1=44.75 +lat_2=55.75 +x_0=0 +y_0=0 +a=6378137 +rf=298.257223999999 +units=m +no_defs"
latlong<-"+proj=longlat +datum=WGS84 +no_defs"
LCC <- "+proj=lcc +lat_1=49 +lat_2=77 +lat_0=0 +lon_0=-95 +x_0=0 +y_0=0 +datum=NAD83 +units=m +no_defs"
#I'm getting error messages when trying to define this raster's projection
#The CRS suggests lat long but extent values suggest something else
#The original rasters were in a LAEA projection
projection(ontario)<-LAEA
plot(ontario)
rs2020<-projectRaster(ontario, crs=LCC)
#for some reason, projecting from 200x200 in LAEA to LCC is 
#changing resolution from 200x200 to 203x202
#change resolution from 203x202 to 200x200
resampleFactor1 <- 200/203
resampleFactor2 <- 200/202
inCols <- ncol(rs2020)
inRows <- nrow(rs2020)
resampledRaster <- raster(ncol=(inCols / resampleFactor1), nrow=(inRows / resampleFactor2))
#rs2020's projection is LCC but new rasters are projected as lat-long by default
projection(resampledRaster)<-LCC#same as ontario
extent(resampledRaster) <- extent(ontario)
res(resampledRaster)<-200#set to exactly 200 m before resampling occurs
resampledRaster <- resample(ontario,resampledRaster,datatype="INT1U",method='bilinear')
plot(resampledRaster)

ontario<-resampledRaster

#Load Ontario 2020 Landsat Layers
#Landsat metrics 150-m scale
on2020 <- list.files("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 200 m/150 m/",pattern="^on2020")
setwd("0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 200 m/150 m/")
rs2020 <- stack(raster(on2020[1]))
projection(rs2020)<-LAEA#correct the projection: latlong is wrong
rs2020<-projectRaster(rs2020, crs=LCC)
rs2020[is.na(rs2020[])] <- 0
#We are only interested in one raster in this folder.

resampleFactor1 <- 200/203
resampleFactor2 <- 200/202
inCols <- ncol(rs2020)
inRows <- nrow(rs2020)
resampledRaster <- raster(ncol=(inCols / resampleFactor1), nrow=(inRows / resampleFactor2))
#rs2020's projection is LCC but new rasters are projected as lat-long by default
projection(resampledRaster)<-LCC#same as ontario
extent(resampledRaster) <- extent(ontario)
res(resampledRaster)<-200#set to exactly 200 m before resampling occurs
resampledRaster <- resample(ontario,resampledRaster,datatype="INT1U",method='bilinear')

rs2020<-resampledRaster

# for (i in 2:length(on2020)) {
#   ras<-raster(on2020[i])
#   projection(ras)<-LAEA
#   ras<-projectRaster(ras, crs=LCC)
#   ras[is.na(ras[])] <- 0
#   rs2020 <- addLayer(rs2020, ras)}
names(rs2020) <- gsub("on2020_","",names(rs2020))
preds2020 <- crop(rs2020,ontario)
preds2020 <- mask(preds2020,ontario)
writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/processed/prediction rasters/Ontario/on.Landsat2020_150m.grd", format="raster",overwrite=TRUE)

#Landsat metrics 250-m scale
# on2020 <- list.files("E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/250 m/on2020",pattern=".tif$")
# setwd("E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 250/250 m/on2020/")
# rs2020 <- stack(raster(on2020[1]))
# projection(rs2020)<-LAEA#correct the projection: latlong is wrong
# rs2020<-projectRaster(rs2020, crs=LCC)
# rs2020[is.na(rs2020[])] <- 0
# for (i in 2:length(on2020)) { 
#   ras<-raster(on2020[i])
#   projection(ras)<-LAEA
#   ras<-projectRaster(ras, crs=LCC)
#   ras[is.na(ras[])] <- 0
#   rs2020 <- addLayer(rs2020, ras)}
# names(rs2020) <- gsub("on2020_","",names(rs2020))
# preds2020 <- crop(rs2020,ontario)
# preds2020 <- mask(preds2020,ontario)
# writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/processed/prediction rasters/Ontario/on.Landsat2020_250m.grd", format="raster",overwrite=TRUE)

#Landsat metrics 1000-m scale
on2020 <- list.files("E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 200 m/1000 m/",pattern="^on2020")
setwd("E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 200 m/1000 m/")
rs2020 <- stack(raster(on2020[1]))
projection(rs2020)<-LAEA#correct the projection: latlong is wrong
rs2020<-projectRaster(rs2020, crs=LCC)
rs2020[is.na(rs2020[])] <- 0

resampleFactor1 <- 200/203
resampleFactor2 <- 200/202
inCols <- ncol(rs2020)
inRows <- nrow(rs2020)
resampledRaster <- raster(ncol=(inCols / resampleFactor1), nrow=(inRows / resampleFactor2))
#rs2020's projection is LCC but new rasters are projected as lat-long by default
projection(resampledRaster)<-LCC#same as ontario
extent(resampledRaster) <- extent(rs2020)
res(resampledRaster)<-200#set to exactly 200 m before resampling occurs
resampledRaster <- resample(rs2020,resampledRaster,datatype="INT1U",method='bilinear')

rs2020<-resampledRaster

for (i in 2:length(on2020)) { 
  ras<-raster(on2020[i])
  projection(ras)<-LAEA
  ras<-projectRaster(ras, crs=LCC)
  ras[is.na(ras[])] <- 0

  resampleFactor1 <- 200/203
  resampleFactor2 <- 200/202
  inCols <- ncol(ras)
  inRows <- nrow(ras)
  resampledRaster <- raster(ncol=(inCols / resampleFactor1), nrow=(inRows / resampleFactor2))
  #rs2020's projection is LCC but new rasters are projected as lat-long by default
  projection(resampledRaster)<-LCC#same as ontario
  extent(resampledRaster) <- extent(ras)
  res(resampledRaster)<-200#set to exactly 200 m before resampling occurs
  resampledRaster <- resample(ras,resampledRaster,datatype="INT1U",method='bilinear')
  
  ras<-resampledRaster
  rs2020 <- addLayer(rs2020, ras)}
names(rs2020) <- gsub("on2020_","",names(rs2020))
preds2020 <- crop(rs2020,ontario)
preds2020 <- mask(preds2020,ontario)
writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/processed/prediction rasters/Ontario/on.Landsat2020_1000m.grd", format="raster",overwrite=TRUE)

#Landsat metrics 2000-m scale
on2020 <- list.files("E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 200 m/2000 m/",pattern="^on2020")
setwd("E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/raw/Agriculture Canada Annual Layers/landscape rasters/resampled to 200 m/2000 m/")
rs2020 <- stack(raster(on2020[1]))
projection(rs2020)<-LAEA#correct the projection: latlong is wrong
rs2020<-projectRaster(rs2020, crs=LCC)
rs2020[is.na(rs2020[])] <- 0

resampleFactor1 <- 200/203
resampleFactor2 <- 200/202
inCols <- ncol(rs2020)
inRows <- nrow(rs2020)
resampledRaster <- raster(ncol=(inCols / resampleFactor1), nrow=(inRows / resampleFactor2))
#rs2020's projection is LCC but new rasters are projected as lat-long by default
projection(resampledRaster)<-LCC#same as ontario
extent(resampledRaster) <- extent(rs2020)
res(resampledRaster)<-200#set to exactly 200 m before resampling occurs
resampledRaster <- resample(rs2020,resampledRaster,datatype="INT1U",method='bilinear')

rs2020<-resampledRaster

for (i in 2:length(on2020)) { 
  ras<-raster(on2020[i])
  projection(ras)<-LAEA
  ras<-projectRaster(ras, crs=LCC)
  ras[is.na(ras[])] <- 0
  
  resampleFactor1 <- 200/203
  resampleFactor2 <- 200/202
  inCols <- ncol(ras)
  inRows <- nrow(ras)
  resampledRaster <- raster(ncol=(inCols / resampleFactor1), nrow=(inRows / resampleFactor2))
  #rs2020's projection is LCC but new rasters are projected as lat-long by default
  projection(resampledRaster)<-LCC#same as ontario
  extent(resampledRaster) <- extent(ras)
  res(resampledRaster)<-200#set to exactly 200 m before resampling occurs
  resampledRaster <- resample(ras,resampledRaster,datatype="INT1U",method='bilinear')
  
  ras<-resampledRaster
  rs2020 <- addLayer(rs2020, ras)}
names(rs2020) <- gsub("on2020_","",names(rs2020))
names(rs2020[[1]])<-"barren.2000m"
names(rs2020[[2]])<-"conif.2000m"
names(rs2020[[6]])<-"urban.2000m"
preds2020 <- crop(rs2020,ontario)
preds2020 <- mask(preds2020,ontario)
writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/processed/prediction rasters/Ontario/on.Landsat2020_2000m.grd", format="raster",overwrite=TRUE)

#Beaudoin metrics local scale
# on2020 <- list.files("E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/raw/Beaudoin/2011/Processed/Beaudoin 2011 TIFFs WOTHstudyarea",pattern="_v1.tif$")
# setwd("E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/raw/Beaudoin/2011/Processed/Beaudoin 2011 TIFFs WOTHstudyarea/")
# rs2020 <- stack(raster(on2020[1]))
# rs2020<-projectRaster(rs2020, crs=LCC)
# rs2020[is.na(rs2020[])] <- 0
# for (i in 2:length(on2020)) { 
#   ras<-raster(on2020[i])
#   ras<-projectRaster(ras, crs=LCC)
#   ras[is.na(ras[])] <- 0
#   rs2020 <- addLayer(rs2020, ras)}
# names(rs2020)<-gsub("local_","",names(rs2020))
# names(rs2020)<-gsub("_v1",".local",names(rs2020))
# rs2020.rp<-projectRaster(rs2020, ontario)
# preds2020 <- crop(rs2020.rp,ontario)
# preds2020 <- mask(preds2020,ontario)
# writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/processed/prediction rasters/Ontario/on.Beaudoin2011_local.grd", format="raster",overwrite=TRUE)

#Beaudoin metrics 250 m
# on2020 <- list.files("E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/raw/Beaudoin/2011/Processed/250 m",pattern="_250m.tif$")
# setwd("E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/raw/Beaudoin/2011/Processed/250 m/")
# rs2020 <- stack(raster(on2020[1]))
# rs2020<-projectRaster(rs2020, crs=LCC)
# rs2020[is.na(rs2020[])] <- 0
# for (i in 2:length(on2020)) { 
#   ras<-raster(on2020[i])
#   ras<-projectRaster(ras, crs=LCC)
#   ras[is.na(ras[])] <- 0
#   rs2020 <- addLayer(rs2020, ras)}
# names(rs2020)<-gsub("local_","",names(rs2020))
# names(rs2020)<-gsub("_250m",".250m",names(rs2020))
# rs2020.rp<-projectRaster(rs2020, ontario)
# preds2020 <- crop(rs2020.rp,ontario)
# preds2020 <- mask(preds2020,ontario)
# writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/processed/prediction rasters/Ontario/on.Beaudoin2011_250m.grd", format="raster",overwrite=TRUE)

#Beaudoin metrics 1000 m
# on2020 <- list.files("E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/raw/Beaudoin/2011/Processed/1000 m",pattern="_1000m.tif$")
# setwd("E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/raw/Beaudoin/2011/Processed/1000 m/")
# rs2020 <- stack(raster(on2020[1]))
# rs2020<-projectRaster(rs2020, crs=LCC)
# rs2020[is.na(rs2020[])] <- 0
# for (i in 2:length(on2020)) { 
#   ras<-raster(on2020[i])
#   ras<-projectRaster(ras, crs=LCC)
#   ras[is.na(ras[])] <- 0
#   rs2020 <- addLayer(rs2020, ras)}
# names(rs2020)<-gsub("local_","",names(rs2020))
# names(rs2020)<-gsub("_1000m",".1000m",names(rs2020))
# rs2020.rp<-projectRaster(rs2020, ontario)
# preds2020 <- crop(rs2020.rp,ontario)
# preds2020 <- mask(preds2020,ontario)
# writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/processed/prediction rasters/Ontario/on.Beaudoin2011_1000m.grd", format="raster",overwrite=TRUE)

#Beaudoin metrics 2000 m
on2020 <- list.files("E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/raw/Beaudoin/2011/Processed/2000 m/resampled to 200 m/",pattern="_2000m.tif$")
setwd("E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/raw/Beaudoin/2011/Processed/2000 m/resampled to 200 m/")
rs2020 <- stack(raster(on2020[1]))
projection(rs2020)<-LCC#correct the projection: latlong is wrong
#rs2020<-projectRaster(rs2020, crs=LCC)
rs2020[is.na(rs2020[])] <- 0
# for (i in 2:length(on2020)) { 
#   ras<-raster(on2020[i])
#   ras<-projectRaster(ras, crs=LCC)
#   ras[is.na(ras[])] <- 0
#   rs2020 <- addLayer(rs2020, ras)}
names(rs2020)<-gsub("local_","",names(rs2020))
names(rs2020)<-gsub("_2000m",".2000m",names(rs2020))
rs2020.rp<-projectRaster(rs2020, ontario)
preds2020 <- crop(rs2020.rp,ontario)
preds2020 <- mask(preds2020,ontario)
writeRaster(preds2020, filename="E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/processed/prediction rasters/Ontario/on.Beaudoin2011_2000m.grd", format="raster",overwrite=TRUE)

#Load swamp rasters
rlist <- list.files("E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/raw/Wetlands/resampled to 200 m/",pattern="OLC")
#OLC layer from which Ontario swamp layer is derived:
#+proj=lcc +lat_0=0 +lon_0=-85 +lat_1=44.5 +lat_2=53.5 +x_0=930000 +y_0=6430000 +datum=NAD83 +units=m +no_defs
for(i in rlist){
  rs2020<-raster(paste0("E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/raw/Wetlands/resampled to 200 m/",i))
  projection(rs2020)<-"+proj=lcc +lat_0=0 +lon_0=-85 +lat_1=44.5 +lat_2=53.5 +x_0=930000 +y_0=6430000 +datum=NAD83 +units=m +no_defs"#LAEA#set correct projection: latlong is wrong
  rs2020[is.na(rs2020[])] <- 0
  names(rs2020)<-gsub("OLC","",names(rs2020))
  #rs2020.rp<-resample(rs2020, ontario, method="bilinear")
  #extent(rs2020)<-extent(ontario)
  #for some reason the extents don't line up and I lose 
  #rs2020 values unless I change rs2020 extent before reprojecting
  rs2020.rp<-projectRaster(rs2020, ontario)
  preds2020 <- crop(rs2020.rp,ontario)#rs2020.rp
  preds2020 <- mask(preds2020,ontario)
  writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/processed/prediction rasters/Ontario/on.",names(rs2020),".grd"), format="raster",overwrite=TRUE)
}

#Load road data
#Major roads
rs2020<-raster("E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/raw/CanVec roads/AllMajorRoads_LCC150/AllMajorRoads_LCC150/AllMajorRoads_LCC150.tif")
rs2020[is.na(rs2020[])] <- 0
names(rs2020)<-"MajorRoad150"
#change resolution from 250x250 to 200x200
resampleFactor <- 200/250
inCols <- ncol(rs2020)
inRows <- nrow(rs2020)
resampledRaster <- raster(ncol=(inCols / resampleFactor), nrow=(inRows / resampleFactor))
#rs2020's projection is LCC but new rasters are projected as lat-long by default
projection(resampledRaster)<-LCC
extent(resampledRaster) <- extent(rs2020)
res(resampledRaster)<-200#set to exactly 200 m before resampling occurs
resampledRaster <- resample(rs2020,resampledRaster,datatype="INT1U",method='bilinear')
values(resampledRaster)<-ifelse(!values(resampledRaster)==1,0,values(resampledRaster))

#projection(resampledRaster)<-LCC#correct the projection: based on the extent, latlong is wrong

rs2020.rp<-projectRaster(resampledRaster, ontario)
#lost all my attributes>:(
preds2020 <- crop(rs2020.rp,ontario)
preds2020 <- mask(preds2020,ontario)
preds2020[is.na(preds2020[])] <- 0
#stuck using a 0-layer for predictions because the MajorRoad150
#layer loses attributes if I use projectRaster to align its extent
#with Ontario
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/processed/prediction rasters/Ontario/on.",names(rs2020),".grd"), format="raster",overwrite=TRUE)

#Any Roads
rs2020<-raster("E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/raw/roadonoff/roadonoff.WOTHstudyarea.tif")
rs2020[is.na(rs2020[])] <- 0
names(rs2020)<-"Roadside150"
#change resolution from 250x250 to 200x200
resampleFactor <- 200/250
inCols <- ncol(rs2020)
inRows <- nrow(rs2020)
resampledRaster <- raster(ncol=(inCols / resampleFactor), nrow=(inRows / resampleFactor))
#rs2020's projection is LCC but new rasters are projected as lat-long by default
projection(resampledRaster)<-LCC
extent(resampledRaster) <- extent(rs2020)
res(resampledRaster)<-200#set to exactly 200 m before resampling occurs
resampledRaster <- resample(rs2020,resampledRaster,datatype="INT1U",method='bilinear')

rs2020.rp<-projectRaster(resampledRaster, ontario)
preds2020 <- crop(rs2020.rp,ontario)
preds2020 <- mask(preds2020,ontario)
#values(preds2020)<-ifelse(!values(preds2020)==1,0,values(preds2020))
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/processed/prediction rasters/Ontario/on.",names(rs2020),".grd"), format="raster",overwrite=TRUE)
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/processed/prediction rasters/Ontario/on.",names(rs2020),".tif"),overwrite=TRUE)

#Elevation
rs2020<-raster("E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/raw/NA_Reference_files_ASCII/elevWOTHstudyarea.tif")
rs2020[is.na(rs2020[])] <- 0
names(rs2020)<-"elev"
#change resolution from 250x250 to 200x200
resampleFactor <- 200/250
inCols <- ncol(rs2020)
inRows <- nrow(rs2020)
resampledRaster <- raster(ncol=(inCols / resampleFactor), nrow=(inRows / resampleFactor))
#rs2020's projection is LCC but new rasters are projected as lat-long by default
projection(resampledRaster)<-LCC
extent(resampledRaster) <- extent(rs2020)
res(resampledRaster)<-200#set to exactly 200 m before resampling occurs
resampledRaster <- resample(rs2020,resampledRaster,datatype="INT1U",method='bilinear')

rs2020.rp<-projectRaster(resampledRaster, ontario)
preds2020 <- crop(rs2020.rp,ontario)#rs2020.rp
preds2020 <- mask(preds2020,ontario)
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/processed/prediction rasters/Ontario/on.",names(rs2020),".grd"), format="raster",overwrite=TRUE)

#Slope
rs2020<-raster("E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/raw/topo/slopeLCC.WOTHstudyarea.tif")
rs2020[is.na(rs2020[])] <- 0
names(rs2020)<-"slope"
#change resolution from 250x250 to 200x200
resampleFactor <- 200/250
inCols <- ncol(rs2020)
inRows <- nrow(rs2020)
resampledRaster <- raster(ncol=(inCols / resampleFactor), nrow=(inRows / resampleFactor))
#rs2020's projection is LCC but new rasters are projected as lat-long by default
projection(resampledRaster)<-LCC
extent(resampledRaster) <- extent(rs2020)
res(resampledRaster)<-200#set to exactly 200 m before resampling occurs
resampledRaster <- resample(rs2020,resampledRaster,datatype="INT1U",method='bilinear')

rs2020.rp<-projectRaster(resampledRaster, ontario)
preds2020 <- crop(rs2020.rp,ontario)#rs2020.rp
preds2020 <- mask(preds2020,ontario)
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/processed/prediction rasters/Ontario/on.",names(rs2020),".grd"), format="raster",overwrite=TRUE)

#Roughness: TPI
rs2020<-raster("E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/raw/topo/tpiLCC.WOTHstudyarea.tif")
rs2020[is.na(rs2020[])] <- 0
names(rs2020)<-"TPI"
#change resolution from 250x250 to 200x200
resampleFactor <- 200/250
inCols <- ncol(rs2020)
inRows <- nrow(rs2020)
resampledRaster <- raster(ncol=(inCols / resampleFactor), nrow=(inRows / resampleFactor))
#rs2020's projection is LCC but new rasters are projected as lat-long by default
projection(resampledRaster)<-LCC
extent(resampledRaster) <- extent(rs2020)
res(resampledRaster)<-200#set to exactly 200 m before resampling occurs
resampledRaster <- resample(rs2020,resampledRaster,datatype="INT1U",method='bilinear')

rs2020.rp<-projectRaster(resampledRaster, ontario)
preds2020 <- crop(rs2020.rp,ontario)#rs2020.rp
preds2020 <- mask(preds2020,ontario)
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/processed/prediction rasters/Ontario/on.",names(rs2020),".grd"), format="raster",overwrite=TRUE)

#Roughness: TRI
rs2020<-raster("E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/raw/topo/triLCC.WOTHstudyarea.tif")
rs2020[is.na(rs2020[])] <- 0
names(rs2020)<-"TRI"
#change resolution from 250x250 to 200x200
resampleFactor <- 200/250
inCols <- ncol(rs2020)
inRows <- nrow(rs2020)
resampledRaster <- raster(ncol=(inCols / resampleFactor), nrow=(inRows / resampleFactor))
#rs2020's projection is LCC but new rasters are projected as lat-long by default
projection(resampledRaster)<-LCC
extent(resampledRaster) <- extent(rs2020)
res(resampledRaster)<-200#set to exactly 200 m before resampling occurs
resampledRaster <- resample(rs2020,resampledRaster,datatype="INT1U",method='bilinear')

rs2020.rp<-projectRaster(resampledRaster, ontario)
preds2020 <- crop(rs2020.rp,ontario)#rs2020.rp
preds2020 <- mask(preds2020,ontario)
writeRaster(preds2020, filename=paste0("E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/processed/prediction rasters/Ontario/on.",names(rs2020),".grd"), format="raster",overwrite=TRUE)


landsat150<-stack("E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/processed/prediction rasters/Ontario/on.Landsat2020_150m.grd")
landsat1000<-stack("E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/processed/prediction rasters/Ontario/on.Landsat2020_1000m.grd")
landsat2000<-stack("E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/processed/prediction rasters/Ontario/on.Landsat2020_2000m.grd")
beaudoin2000<-stack("E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/processed/prediction rasters/Ontario/on.Beaudoin2011_2000m.grd")
elev<-stack("E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/processed/prediction rasters/Ontario/on.elev.grd")
MajorRoad150<-stack("E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/processed/prediction rasters/Ontario/on.MajorRoad150.grd")
Roadside150<-stack("E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/processed/prediction rasters/Ontario/on.Roadside150.grd")
slope<-stack("E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/processed/prediction rasters/Ontario/on.slope.grd")
swamp.150m<-stack("E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/processed/prediction rasters/Ontario/on.swamp.150m.grd")
TPI<-stack("E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/processed/prediction rasters/Ontario/on.TPI.grd")
TRI<-stack("E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/processed/prediction rasters/Ontario/on.TRI.grd")


pred_ontario<-stack(landsat150,landsat1000,landsat2000,beaudoin2000,MajorRoad150,Roadside150,elev,slope,swamp.150m,TPI,TRI,quick=TRUE)
names(pred_ontario)
#it looks like some layers were not successfully renamed. That could be why
#predictions were not generated for some layers. Need to figure out why
#naming wasn't successful for some variables.
names(pred_ontario[[13]])<-"MajorRoad150"
names(pred_ontario[[18]])<-"TPI"

writeRaster(pred_ontario, filename="E:/CWS Wood Thrush Contract/CHID-ALCES-Online-models/0_data_for_BRT_models/processed/prediction rasters/Ontario/pred_ontario.grd", format="raster",overwrite=TRUE)


